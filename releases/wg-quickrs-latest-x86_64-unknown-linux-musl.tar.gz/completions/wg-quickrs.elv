
use builtin;
use str;

set edit:completion:arg-completer[wg-quickrs] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'wg-quickrs'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'wg-quickrs'= {
            cand --wg-quickrs-config-folder 'wg-quickrs-config-folder'
            cand -v 'Increase verbosity level from Info to Debug'
            cand --verbose 'Increase verbosity level from Info to Debug'
            cand -h 'Print help'
            cand --help 'Print help'
            cand agent 'Run agent commands'
            cand config 'Edit agent configuration options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;agent'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand init 'Initialize the wg-quickrs agent. Configuration options can be filled either by prompts on screen (when no argument is provided) or specified as arguments to this command'
            cand run 'Run the wg-quickrs agent'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;agent;init'= {
            cand --network-name 'network-name'
            cand --network-subnet 'network-subnet'
            cand --agent-web-address 'agent-web-address'
            cand --agent-web-http-enabled 'agent-web-http-enabled'
            cand --agent-web-http-port 'agent-web-http-port'
            cand --agent-web-https-enabled 'agent-web-https-enabled'
            cand --agent-web-https-port 'agent-web-https-port'
            cand --agent-web-https-tls-cert 'agent-web-https-tls-cert'
            cand --agent-web-https-tls-key 'agent-web-https-tls-key'
            cand --agent-web-password-enabled 'agent-web-password-enabled'
            cand --agent-web-password 'agent-web-password'
            cand --agent-vpn-enabled 'agent-vpn-enabled'
            cand --agent-vpn-port 'agent-vpn-port'
            cand --agent-firewall-enabled 'agent-firewall-enabled'
            cand --agent-firewall-utility 'agent-firewall-utility'
            cand --agent-firewall-gateway 'agent-firewall-gateway'
            cand --agent-peer-name 'agent-peer-name'
            cand --agent-peer-vpn-internal-address 'agent-peer-vpn-internal-address'
            cand --agent-peer-vpn-endpoint 'agent-peer-vpn-endpoint'
            cand --agent-peer-kind 'agent-peer-kind'
            cand --agent-peer-icon-enabled 'agent-peer-icon-enabled'
            cand --agent-peer-icon-src 'agent-peer-icon-src'
            cand --agent-peer-dns-enabled 'agent-peer-dns-enabled'
            cand --agent-peer-dns-addresses 'agent-peer-dns-addresses'
            cand --agent-peer-mtu-enabled 'agent-peer-mtu-enabled'
            cand --agent-peer-mtu-value 'agent-peer-mtu-value'
            cand --agent-peer-script-pre-up-enabled 'agent-peer-script-pre-up-enabled'
            cand --agent-peer-script-pre-up-line 'agent-peer-script-pre-up-line'
            cand --agent-peer-script-post-up-enabled 'agent-peer-script-post-up-enabled'
            cand --agent-peer-script-post-up-line 'agent-peer-script-post-up-line'
            cand --agent-peer-script-pre-down-enabled 'agent-peer-script-pre-down-enabled'
            cand --agent-peer-script-pre-down-line 'agent-peer-script-pre-down-line'
            cand --agent-peer-script-post-down-enabled 'agent-peer-script-post-down-enabled'
            cand --agent-peer-script-post-down-line 'agent-peer-script-post-down-line'
            cand --default-peer-kind 'default-peer-kind'
            cand --default-peer-icon-enabled 'default-peer-icon-enabled'
            cand --default-peer-icon-src 'default-peer-icon-src'
            cand --default-peer-dns-enabled 'default-peer-dns-enabled'
            cand --default-peer-dns-addresses 'default-peer-dns-addresses'
            cand --default-peer-mtu-enabled 'default-peer-mtu-enabled'
            cand --default-peer-mtu-value 'default-peer-mtu-value'
            cand --default-peer-script-pre-up-enabled 'default-peer-script-pre-up-enabled'
            cand --default-peer-script-pre-up-line 'default-peer-script-pre-up-line'
            cand --default-peer-script-post-up-enabled 'default-peer-script-post-up-enabled'
            cand --default-peer-script-post-up-line 'default-peer-script-post-up-line'
            cand --default-peer-script-pre-down-enabled 'default-peer-script-pre-down-enabled'
            cand --default-peer-script-pre-down-line 'default-peer-script-pre-down-line'
            cand --default-peer-script-post-down-enabled 'default-peer-script-post-down-enabled'
            cand --default-peer-script-post-down-line 'default-peer-script-post-down-line'
            cand --default-connection-persistent-keepalive-enabled 'default-connection-persistent-keepalive-enabled'
            cand --default-connection-persistent-keepalive-period 'default-connection-persistent-keepalive-period'
            cand --no-prompt 'no-prompt'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'wg-quickrs;agent;run'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;agent;help'= {
            cand init 'Initialize the wg-quickrs agent. Configuration options can be filled either by prompts on screen (when no argument is provided) or specified as arguments to this command'
            cand run 'Run the wg-quickrs agent'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;agent;help;init'= {
        }
        &'wg-quickrs;agent;help;run'= {
        }
        &'wg-quickrs;agent;help;help'= {
        }
        &'wg-quickrs;config'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enable 'Enable a configuration option'
            cand disable 'Disable a configuration option'
            cand set 'Set a configuration value'
            cand reset 'Reset a configuration option'
            cand get 'Get a configuration value'
            cand list 'List network entities in human-readable format'
            cand remove 'Remove network entities'
            cand add 'Add network entities'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand agent 'Enable agent configuration options'
            cand network 'Enable network configuration options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;agent'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand web 'Enable web server options'
            cand vpn 'Enable VPN server'
            cand firewall 'Enable firewall configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;agent;web'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand http 'Enable HTTP on web server'
            cand https 'Enable HTTPS on web server'
            cand password 'Enable password authentication for web server'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;agent;web;http'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;agent;web;https'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;agent;web;password'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;agent;web;help'= {
            cand http 'Enable HTTP on web server'
            cand https 'Enable HTTPS on web server'
            cand password 'Enable password authentication for web server'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;agent;web;help;http'= {
        }
        &'wg-quickrs;config;enable;agent;web;help;https'= {
        }
        &'wg-quickrs;config;enable;agent;web;help;password'= {
        }
        &'wg-quickrs;config;enable;agent;web;help;help'= {
        }
        &'wg-quickrs;config;enable;agent;vpn'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;agent;firewall'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;agent;help'= {
            cand web 'Enable web server options'
            cand vpn 'Enable VPN server'
            cand firewall 'Enable firewall configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;agent;help;web'= {
            cand http 'Enable HTTP on web server'
            cand https 'Enable HTTPS on web server'
            cand password 'Enable password authentication for web server'
        }
        &'wg-quickrs;config;enable;agent;help;web;http'= {
        }
        &'wg-quickrs;config;enable;agent;help;web;https'= {
        }
        &'wg-quickrs;config;enable;agent;help;web;password'= {
        }
        &'wg-quickrs;config;enable;agent;help;vpn'= {
        }
        &'wg-quickrs;config;enable;agent;help;firewall'= {
        }
        &'wg-quickrs;config;enable;agent;help;help'= {
        }
        &'wg-quickrs;config;enable;network'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand peer 'Enable peer options'
            cand connection 'Enable connection'
            cand defaults 'Enable default configuration options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;network;peer'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand endpoint 'Enable peer endpoint'
            cand icon 'Enable peer icon'
            cand dns 'Enable peer DNS'
            cand mtu 'Enable peer MTU'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;network;peer;endpoint'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;network;peer;icon'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;network;peer;dns'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;network;peer;mtu'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;network;peer;help'= {
            cand endpoint 'Enable peer endpoint'
            cand icon 'Enable peer icon'
            cand dns 'Enable peer DNS'
            cand mtu 'Enable peer MTU'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;network;peer;help;endpoint'= {
        }
        &'wg-quickrs;config;enable;network;peer;help;icon'= {
        }
        &'wg-quickrs;config;enable;network;peer;help;dns'= {
        }
        &'wg-quickrs;config;enable;network;peer;help;mtu'= {
        }
        &'wg-quickrs;config;enable;network;peer;help;help'= {
        }
        &'wg-quickrs;config;enable;network;connection'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;network;defaults'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand peer 'Enable default peer options'
            cand connection 'Enable default connection options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;network;defaults;peer'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand icon 'Enable default peer icon'
            cand dns 'Enable default peer DNS'
            cand mtu 'Enable default peer MTU'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;network;defaults;peer;icon'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;network;defaults;peer;dns'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;network;defaults;peer;mtu'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;network;defaults;peer;help'= {
            cand icon 'Enable default peer icon'
            cand dns 'Enable default peer DNS'
            cand mtu 'Enable default peer MTU'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;network;defaults;peer;help;icon'= {
        }
        &'wg-quickrs;config;enable;network;defaults;peer;help;dns'= {
        }
        &'wg-quickrs;config;enable;network;defaults;peer;help;mtu'= {
        }
        &'wg-quickrs;config;enable;network;defaults;peer;help;help'= {
        }
        &'wg-quickrs;config;enable;network;defaults;connection'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand persistent-keepalive 'Enable default connection persistent keepalive'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;network;defaults;connection;persistent-keepalive'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;enable;network;defaults;connection;help'= {
            cand persistent-keepalive 'Enable default connection persistent keepalive'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;network;defaults;connection;help;persistent-keepalive'= {
        }
        &'wg-quickrs;config;enable;network;defaults;connection;help;help'= {
        }
        &'wg-quickrs;config;enable;network;defaults;help'= {
            cand peer 'Enable default peer options'
            cand connection 'Enable default connection options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;network;defaults;help;peer'= {
            cand icon 'Enable default peer icon'
            cand dns 'Enable default peer DNS'
            cand mtu 'Enable default peer MTU'
        }
        &'wg-quickrs;config;enable;network;defaults;help;peer;icon'= {
        }
        &'wg-quickrs;config;enable;network;defaults;help;peer;dns'= {
        }
        &'wg-quickrs;config;enable;network;defaults;help;peer;mtu'= {
        }
        &'wg-quickrs;config;enable;network;defaults;help;connection'= {
            cand persistent-keepalive 'Enable default connection persistent keepalive'
        }
        &'wg-quickrs;config;enable;network;defaults;help;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;enable;network;defaults;help;help'= {
        }
        &'wg-quickrs;config;enable;network;help'= {
            cand peer 'Enable peer options'
            cand connection 'Enable connection'
            cand defaults 'Enable default configuration options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;network;help;peer'= {
            cand endpoint 'Enable peer endpoint'
            cand icon 'Enable peer icon'
            cand dns 'Enable peer DNS'
            cand mtu 'Enable peer MTU'
        }
        &'wg-quickrs;config;enable;network;help;peer;endpoint'= {
        }
        &'wg-quickrs;config;enable;network;help;peer;icon'= {
        }
        &'wg-quickrs;config;enable;network;help;peer;dns'= {
        }
        &'wg-quickrs;config;enable;network;help;peer;mtu'= {
        }
        &'wg-quickrs;config;enable;network;help;connection'= {
        }
        &'wg-quickrs;config;enable;network;help;defaults'= {
            cand peer 'Enable default peer options'
            cand connection 'Enable default connection options'
        }
        &'wg-quickrs;config;enable;network;help;defaults;peer'= {
            cand icon 'Enable default peer icon'
            cand dns 'Enable default peer DNS'
            cand mtu 'Enable default peer MTU'
        }
        &'wg-quickrs;config;enable;network;help;defaults;peer;icon'= {
        }
        &'wg-quickrs;config;enable;network;help;defaults;peer;dns'= {
        }
        &'wg-quickrs;config;enable;network;help;defaults;peer;mtu'= {
        }
        &'wg-quickrs;config;enable;network;help;defaults;connection'= {
            cand persistent-keepalive 'Enable default connection persistent keepalive'
        }
        &'wg-quickrs;config;enable;network;help;defaults;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;enable;network;help;help'= {
        }
        &'wg-quickrs;config;enable;help'= {
            cand agent 'Enable agent configuration options'
            cand network 'Enable network configuration options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;enable;help;agent'= {
            cand web 'Enable web server options'
            cand vpn 'Enable VPN server'
            cand firewall 'Enable firewall configuration'
        }
        &'wg-quickrs;config;enable;help;agent;web'= {
            cand http 'Enable HTTP on web server'
            cand https 'Enable HTTPS on web server'
            cand password 'Enable password authentication for web server'
        }
        &'wg-quickrs;config;enable;help;agent;web;http'= {
        }
        &'wg-quickrs;config;enable;help;agent;web;https'= {
        }
        &'wg-quickrs;config;enable;help;agent;web;password'= {
        }
        &'wg-quickrs;config;enable;help;agent;vpn'= {
        }
        &'wg-quickrs;config;enable;help;agent;firewall'= {
        }
        &'wg-quickrs;config;enable;help;network'= {
            cand peer 'Enable peer options'
            cand connection 'Enable connection'
            cand defaults 'Enable default configuration options'
        }
        &'wg-quickrs;config;enable;help;network;peer'= {
            cand endpoint 'Enable peer endpoint'
            cand icon 'Enable peer icon'
            cand dns 'Enable peer DNS'
            cand mtu 'Enable peer MTU'
        }
        &'wg-quickrs;config;enable;help;network;peer;endpoint'= {
        }
        &'wg-quickrs;config;enable;help;network;peer;icon'= {
        }
        &'wg-quickrs;config;enable;help;network;peer;dns'= {
        }
        &'wg-quickrs;config;enable;help;network;peer;mtu'= {
        }
        &'wg-quickrs;config;enable;help;network;connection'= {
        }
        &'wg-quickrs;config;enable;help;network;defaults'= {
            cand peer 'Enable default peer options'
            cand connection 'Enable default connection options'
        }
        &'wg-quickrs;config;enable;help;network;defaults;peer'= {
            cand icon 'Enable default peer icon'
            cand dns 'Enable default peer DNS'
            cand mtu 'Enable default peer MTU'
        }
        &'wg-quickrs;config;enable;help;network;defaults;peer;icon'= {
        }
        &'wg-quickrs;config;enable;help;network;defaults;peer;dns'= {
        }
        &'wg-quickrs;config;enable;help;network;defaults;peer;mtu'= {
        }
        &'wg-quickrs;config;enable;help;network;defaults;connection'= {
            cand persistent-keepalive 'Enable default connection persistent keepalive'
        }
        &'wg-quickrs;config;enable;help;network;defaults;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;enable;help;help'= {
        }
        &'wg-quickrs;config;disable'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand agent 'Disable agent configuration options'
            cand network 'Disable network configuration options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;agent'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand web 'Disable web server options'
            cand vpn 'Disable VPN server'
            cand firewall 'Disable firewall configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;agent;web'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand http 'Disable HTTP on web server'
            cand https 'Disable HTTPS on web server'
            cand password 'Disable password authentication for web server'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;agent;web;http'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;agent;web;https'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;agent;web;password'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;agent;web;help'= {
            cand http 'Disable HTTP on web server'
            cand https 'Disable HTTPS on web server'
            cand password 'Disable password authentication for web server'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;agent;web;help;http'= {
        }
        &'wg-quickrs;config;disable;agent;web;help;https'= {
        }
        &'wg-quickrs;config;disable;agent;web;help;password'= {
        }
        &'wg-quickrs;config;disable;agent;web;help;help'= {
        }
        &'wg-quickrs;config;disable;agent;vpn'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;agent;firewall'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;agent;help'= {
            cand web 'Disable web server options'
            cand vpn 'Disable VPN server'
            cand firewall 'Disable firewall configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;agent;help;web'= {
            cand http 'Disable HTTP on web server'
            cand https 'Disable HTTPS on web server'
            cand password 'Disable password authentication for web server'
        }
        &'wg-quickrs;config;disable;agent;help;web;http'= {
        }
        &'wg-quickrs;config;disable;agent;help;web;https'= {
        }
        &'wg-quickrs;config;disable;agent;help;web;password'= {
        }
        &'wg-quickrs;config;disable;agent;help;vpn'= {
        }
        &'wg-quickrs;config;disable;agent;help;firewall'= {
        }
        &'wg-quickrs;config;disable;agent;help;help'= {
        }
        &'wg-quickrs;config;disable;network'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand peer 'Disable peer options'
            cand connection 'Disable connection'
            cand defaults 'Disable default configuration options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;network;peer'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand endpoint 'Disable peer endpoint'
            cand icon 'Disable peer icon'
            cand dns 'Disable peer DNS'
            cand mtu 'Disable peer MTU'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;network;peer;endpoint'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;network;peer;icon'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;network;peer;dns'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;network;peer;mtu'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;network;peer;help'= {
            cand endpoint 'Disable peer endpoint'
            cand icon 'Disable peer icon'
            cand dns 'Disable peer DNS'
            cand mtu 'Disable peer MTU'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;network;peer;help;endpoint'= {
        }
        &'wg-quickrs;config;disable;network;peer;help;icon'= {
        }
        &'wg-quickrs;config;disable;network;peer;help;dns'= {
        }
        &'wg-quickrs;config;disable;network;peer;help;mtu'= {
        }
        &'wg-quickrs;config;disable;network;peer;help;help'= {
        }
        &'wg-quickrs;config;disable;network;connection'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;network;defaults'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand peer 'Disable default peer options'
            cand connection 'Disable default connection options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;network;defaults;peer'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand icon 'Disable default peer icon'
            cand dns 'Disable default peer DNS'
            cand mtu 'Disable default peer MTU'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;network;defaults;peer;icon'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;network;defaults;peer;dns'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;network;defaults;peer;mtu'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;network;defaults;peer;help'= {
            cand icon 'Disable default peer icon'
            cand dns 'Disable default peer DNS'
            cand mtu 'Disable default peer MTU'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;network;defaults;peer;help;icon'= {
        }
        &'wg-quickrs;config;disable;network;defaults;peer;help;dns'= {
        }
        &'wg-quickrs;config;disable;network;defaults;peer;help;mtu'= {
        }
        &'wg-quickrs;config;disable;network;defaults;peer;help;help'= {
        }
        &'wg-quickrs;config;disable;network;defaults;connection'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand persistent-keepalive 'Disable default connection persistent keepalive'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;network;defaults;connection;persistent-keepalive'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;disable;network;defaults;connection;help'= {
            cand persistent-keepalive 'Disable default connection persistent keepalive'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;network;defaults;connection;help;persistent-keepalive'= {
        }
        &'wg-quickrs;config;disable;network;defaults;connection;help;help'= {
        }
        &'wg-quickrs;config;disable;network;defaults;help'= {
            cand peer 'Disable default peer options'
            cand connection 'Disable default connection options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;network;defaults;help;peer'= {
            cand icon 'Disable default peer icon'
            cand dns 'Disable default peer DNS'
            cand mtu 'Disable default peer MTU'
        }
        &'wg-quickrs;config;disable;network;defaults;help;peer;icon'= {
        }
        &'wg-quickrs;config;disable;network;defaults;help;peer;dns'= {
        }
        &'wg-quickrs;config;disable;network;defaults;help;peer;mtu'= {
        }
        &'wg-quickrs;config;disable;network;defaults;help;connection'= {
            cand persistent-keepalive 'Disable default connection persistent keepalive'
        }
        &'wg-quickrs;config;disable;network;defaults;help;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;disable;network;defaults;help;help'= {
        }
        &'wg-quickrs;config;disable;network;help'= {
            cand peer 'Disable peer options'
            cand connection 'Disable connection'
            cand defaults 'Disable default configuration options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;network;help;peer'= {
            cand endpoint 'Disable peer endpoint'
            cand icon 'Disable peer icon'
            cand dns 'Disable peer DNS'
            cand mtu 'Disable peer MTU'
        }
        &'wg-quickrs;config;disable;network;help;peer;endpoint'= {
        }
        &'wg-quickrs;config;disable;network;help;peer;icon'= {
        }
        &'wg-quickrs;config;disable;network;help;peer;dns'= {
        }
        &'wg-quickrs;config;disable;network;help;peer;mtu'= {
        }
        &'wg-quickrs;config;disable;network;help;connection'= {
        }
        &'wg-quickrs;config;disable;network;help;defaults'= {
            cand peer 'Disable default peer options'
            cand connection 'Disable default connection options'
        }
        &'wg-quickrs;config;disable;network;help;defaults;peer'= {
            cand icon 'Disable default peer icon'
            cand dns 'Disable default peer DNS'
            cand mtu 'Disable default peer MTU'
        }
        &'wg-quickrs;config;disable;network;help;defaults;peer;icon'= {
        }
        &'wg-quickrs;config;disable;network;help;defaults;peer;dns'= {
        }
        &'wg-quickrs;config;disable;network;help;defaults;peer;mtu'= {
        }
        &'wg-quickrs;config;disable;network;help;defaults;connection'= {
            cand persistent-keepalive 'Disable default connection persistent keepalive'
        }
        &'wg-quickrs;config;disable;network;help;defaults;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;disable;network;help;help'= {
        }
        &'wg-quickrs;config;disable;help'= {
            cand agent 'Disable agent configuration options'
            cand network 'Disable network configuration options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;disable;help;agent'= {
            cand web 'Disable web server options'
            cand vpn 'Disable VPN server'
            cand firewall 'Disable firewall configuration'
        }
        &'wg-quickrs;config;disable;help;agent;web'= {
            cand http 'Disable HTTP on web server'
            cand https 'Disable HTTPS on web server'
            cand password 'Disable password authentication for web server'
        }
        &'wg-quickrs;config;disable;help;agent;web;http'= {
        }
        &'wg-quickrs;config;disable;help;agent;web;https'= {
        }
        &'wg-quickrs;config;disable;help;agent;web;password'= {
        }
        &'wg-quickrs;config;disable;help;agent;vpn'= {
        }
        &'wg-quickrs;config;disable;help;agent;firewall'= {
        }
        &'wg-quickrs;config;disable;help;network'= {
            cand peer 'Disable peer options'
            cand connection 'Disable connection'
            cand defaults 'Disable default configuration options'
        }
        &'wg-quickrs;config;disable;help;network;peer'= {
            cand endpoint 'Disable peer endpoint'
            cand icon 'Disable peer icon'
            cand dns 'Disable peer DNS'
            cand mtu 'Disable peer MTU'
        }
        &'wg-quickrs;config;disable;help;network;peer;endpoint'= {
        }
        &'wg-quickrs;config;disable;help;network;peer;icon'= {
        }
        &'wg-quickrs;config;disable;help;network;peer;dns'= {
        }
        &'wg-quickrs;config;disable;help;network;peer;mtu'= {
        }
        &'wg-quickrs;config;disable;help;network;connection'= {
        }
        &'wg-quickrs;config;disable;help;network;defaults'= {
            cand peer 'Disable default peer options'
            cand connection 'Disable default connection options'
        }
        &'wg-quickrs;config;disable;help;network;defaults;peer'= {
            cand icon 'Disable default peer icon'
            cand dns 'Disable default peer DNS'
            cand mtu 'Disable default peer MTU'
        }
        &'wg-quickrs;config;disable;help;network;defaults;peer;icon'= {
        }
        &'wg-quickrs;config;disable;help;network;defaults;peer;dns'= {
        }
        &'wg-quickrs;config;disable;help;network;defaults;peer;mtu'= {
        }
        &'wg-quickrs;config;disable;help;network;defaults;connection'= {
            cand persistent-keepalive 'Disable default connection persistent keepalive'
        }
        &'wg-quickrs;config;disable;help;network;defaults;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;disable;help;help'= {
        }
        &'wg-quickrs;config;set'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand agent 'Set agent configuration values'
            cand network 'Set network configuration values'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand web 'Set web server configuration'
            cand vpn 'Set VPN configuration'
            cand firewall 'Set firewall configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent;web'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand address 'Set agent web server bind IPv4 address'
            cand http 'Set HTTP configuration'
            cand https 'Set HTTPS configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent;web;address'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;agent;web;http'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand port 'Set web server HTTP port'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent;web;http;port'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;agent;web;http;help'= {
            cand port 'Set web server HTTP port'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent;web;http;help;port'= {
        }
        &'wg-quickrs;config;set;agent;web;http;help;help'= {
        }
        &'wg-quickrs;config;set;agent;web;https'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand port 'Set web server HTTPS port'
            cand tls-cert 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS'
            cand tls-key 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent;web;https;port'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;agent;web;https;tls-cert'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;agent;web;https;tls-key'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;agent;web;https;help'= {
            cand port 'Set web server HTTPS port'
            cand tls-cert 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS'
            cand tls-key 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent;web;https;help;port'= {
        }
        &'wg-quickrs;config;set;agent;web;https;help;tls-cert'= {
        }
        &'wg-quickrs;config;set;agent;web;https;help;tls-key'= {
        }
        &'wg-quickrs;config;set;agent;web;https;help;help'= {
        }
        &'wg-quickrs;config;set;agent;web;help'= {
            cand address 'Set agent web server bind IPv4 address'
            cand http 'Set HTTP configuration'
            cand https 'Set HTTPS configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent;web;help;address'= {
        }
        &'wg-quickrs;config;set;agent;web;help;http'= {
            cand port 'Set web server HTTP port'
        }
        &'wg-quickrs;config;set;agent;web;help;http;port'= {
        }
        &'wg-quickrs;config;set;agent;web;help;https'= {
            cand port 'Set web server HTTPS port'
            cand tls-cert 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS'
            cand tls-key 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS'
        }
        &'wg-quickrs;config;set;agent;web;help;https;port'= {
        }
        &'wg-quickrs;config;set;agent;web;help;https;tls-cert'= {
        }
        &'wg-quickrs;config;set;agent;web;help;https;tls-key'= {
        }
        &'wg-quickrs;config;set;agent;web;help;help'= {
        }
        &'wg-quickrs;config;set;agent;vpn'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand port 'Set VPN server listening port'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent;vpn;port'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;agent;vpn;help'= {
            cand port 'Set VPN server listening port'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent;vpn;help;port'= {
        }
        &'wg-quickrs;config;set;agent;vpn;help;help'= {
        }
        &'wg-quickrs;config;set;agent;firewall'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand utility 'Set the utility used to configure firewall NAT and input rules (e.g. iptables, pfctl, etc.)'
            cand gateway 'Set the gateway used to configure firewall NAT and input rules (e.g. en0, eth0, etc.)'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent;firewall;utility'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;agent;firewall;gateway'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;agent;firewall;help'= {
            cand utility 'Set the utility used to configure firewall NAT and input rules (e.g. iptables, pfctl, etc.)'
            cand gateway 'Set the gateway used to configure firewall NAT and input rules (e.g. en0, eth0, etc.)'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent;firewall;help;utility'= {
        }
        &'wg-quickrs;config;set;agent;firewall;help;gateway'= {
        }
        &'wg-quickrs;config;set;agent;firewall;help;help'= {
        }
        &'wg-quickrs;config;set;agent;help'= {
            cand web 'Set web server configuration'
            cand vpn 'Set VPN configuration'
            cand firewall 'Set firewall configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;agent;help;web'= {
            cand address 'Set agent web server bind IPv4 address'
            cand http 'Set HTTP configuration'
            cand https 'Set HTTPS configuration'
        }
        &'wg-quickrs;config;set;agent;help;web;address'= {
        }
        &'wg-quickrs;config;set;agent;help;web;http'= {
            cand port 'Set web server HTTP port'
        }
        &'wg-quickrs;config;set;agent;help;web;http;port'= {
        }
        &'wg-quickrs;config;set;agent;help;web;https'= {
            cand port 'Set web server HTTPS port'
            cand tls-cert 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS'
            cand tls-key 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS'
        }
        &'wg-quickrs;config;set;agent;help;web;https;port'= {
        }
        &'wg-quickrs;config;set;agent;help;web;https;tls-cert'= {
        }
        &'wg-quickrs;config;set;agent;help;web;https;tls-key'= {
        }
        &'wg-quickrs;config;set;agent;help;vpn'= {
            cand port 'Set VPN server listening port'
        }
        &'wg-quickrs;config;set;agent;help;vpn;port'= {
        }
        &'wg-quickrs;config;set;agent;help;firewall'= {
            cand utility 'Set the utility used to configure firewall NAT and input rules (e.g. iptables, pfctl, etc.)'
            cand gateway 'Set the gateway used to configure firewall NAT and input rules (e.g. en0, eth0, etc.)'
        }
        &'wg-quickrs;config;set;agent;help;firewall;utility'= {
        }
        &'wg-quickrs;config;set;agent;help;firewall;gateway'= {
        }
        &'wg-quickrs;config;set;agent;help;help'= {
        }
        &'wg-quickrs;config;set;network'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand name 'Set network name'
            cand subnet 'Set network subnet'
            cand peer 'Set peer configuration'
            cand connection 'Set connection configuration'
            cand defaults 'Set default configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;network;name'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;subnet'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;peer'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand name 'Set peer name'
            cand address 'Set peer address'
            cand endpoint 'Set peer endpoint address'
            cand kind 'Set peer kind'
            cand icon 'Set peer icon source'
            cand dns 'Set peer DNS addresses'
            cand mtu 'Set peer MTU value'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;network;peer;name'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;peer;address'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;peer;endpoint'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;peer;kind'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;peer;icon'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;peer;dns'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;peer;mtu'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;peer;help'= {
            cand name 'Set peer name'
            cand address 'Set peer address'
            cand endpoint 'Set peer endpoint address'
            cand kind 'Set peer kind'
            cand icon 'Set peer icon source'
            cand dns 'Set peer DNS addresses'
            cand mtu 'Set peer MTU value'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;network;peer;help;name'= {
        }
        &'wg-quickrs;config;set;network;peer;help;address'= {
        }
        &'wg-quickrs;config;set;network;peer;help;endpoint'= {
        }
        &'wg-quickrs;config;set;network;peer;help;kind'= {
        }
        &'wg-quickrs;config;set;network;peer;help;icon'= {
        }
        &'wg-quickrs;config;set;network;peer;help;dns'= {
        }
        &'wg-quickrs;config;set;network;peer;help;mtu'= {
        }
        &'wg-quickrs;config;set;network;peer;help;help'= {
        }
        &'wg-quickrs;config;set;network;connection'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand allowed-ips-a-to-b 'Set allowed IPs from peer A to peer B'
            cand allowed-ips-b-to-a 'Set allowed IPs from peer B to peer A'
            cand persistent-keepalive 'Set persistent keepalive period'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;network;connection;allowed-ips-a-to-b'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;connection;allowed-ips-b-to-a'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;connection;persistent-keepalive'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;connection;help'= {
            cand allowed-ips-a-to-b 'Set allowed IPs from peer A to peer B'
            cand allowed-ips-b-to-a 'Set allowed IPs from peer B to peer A'
            cand persistent-keepalive 'Set persistent keepalive period'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;network;connection;help;allowed-ips-a-to-b'= {
        }
        &'wg-quickrs;config;set;network;connection;help;allowed-ips-b-to-a'= {
        }
        &'wg-quickrs;config;set;network;connection;help;persistent-keepalive'= {
        }
        &'wg-quickrs;config;set;network;connection;help;help'= {
        }
        &'wg-quickrs;config;set;network;defaults'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand peer 'Set default peer configuration'
            cand connection 'Set default connection configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;network;defaults;peer'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand kind 'Set default peer kind'
            cand icon 'Set default peer icon source'
            cand dns 'Set default peer DNS addresses'
            cand mtu 'Set default peer MTU value'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;network;defaults;peer;kind'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;defaults;peer;icon'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;defaults;peer;dns'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;defaults;peer;mtu'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;defaults;peer;help'= {
            cand kind 'Set default peer kind'
            cand icon 'Set default peer icon source'
            cand dns 'Set default peer DNS addresses'
            cand mtu 'Set default peer MTU value'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;network;defaults;peer;help;kind'= {
        }
        &'wg-quickrs;config;set;network;defaults;peer;help;icon'= {
        }
        &'wg-quickrs;config;set;network;defaults;peer;help;dns'= {
        }
        &'wg-quickrs;config;set;network;defaults;peer;help;mtu'= {
        }
        &'wg-quickrs;config;set;network;defaults;peer;help;help'= {
        }
        &'wg-quickrs;config;set;network;defaults;connection'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand persistent-keepalive 'Set default connection persistent keepalive period'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;network;defaults;connection;persistent-keepalive'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;set;network;defaults;connection;help'= {
            cand persistent-keepalive 'Set default connection persistent keepalive period'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;network;defaults;connection;help;persistent-keepalive'= {
        }
        &'wg-quickrs;config;set;network;defaults;connection;help;help'= {
        }
        &'wg-quickrs;config;set;network;defaults;help'= {
            cand peer 'Set default peer configuration'
            cand connection 'Set default connection configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;network;defaults;help;peer'= {
            cand kind 'Set default peer kind'
            cand icon 'Set default peer icon source'
            cand dns 'Set default peer DNS addresses'
            cand mtu 'Set default peer MTU value'
        }
        &'wg-quickrs;config;set;network;defaults;help;peer;kind'= {
        }
        &'wg-quickrs;config;set;network;defaults;help;peer;icon'= {
        }
        &'wg-quickrs;config;set;network;defaults;help;peer;dns'= {
        }
        &'wg-quickrs;config;set;network;defaults;help;peer;mtu'= {
        }
        &'wg-quickrs;config;set;network;defaults;help;connection'= {
            cand persistent-keepalive 'Set default connection persistent keepalive period'
        }
        &'wg-quickrs;config;set;network;defaults;help;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;set;network;defaults;help;help'= {
        }
        &'wg-quickrs;config;set;network;help'= {
            cand name 'Set network name'
            cand subnet 'Set network subnet'
            cand peer 'Set peer configuration'
            cand connection 'Set connection configuration'
            cand defaults 'Set default configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;network;help;name'= {
        }
        &'wg-quickrs;config;set;network;help;subnet'= {
        }
        &'wg-quickrs;config;set;network;help;peer'= {
            cand name 'Set peer name'
            cand address 'Set peer address'
            cand endpoint 'Set peer endpoint address'
            cand kind 'Set peer kind'
            cand icon 'Set peer icon source'
            cand dns 'Set peer DNS addresses'
            cand mtu 'Set peer MTU value'
        }
        &'wg-quickrs;config;set;network;help;peer;name'= {
        }
        &'wg-quickrs;config;set;network;help;peer;address'= {
        }
        &'wg-quickrs;config;set;network;help;peer;endpoint'= {
        }
        &'wg-quickrs;config;set;network;help;peer;kind'= {
        }
        &'wg-quickrs;config;set;network;help;peer;icon'= {
        }
        &'wg-quickrs;config;set;network;help;peer;dns'= {
        }
        &'wg-quickrs;config;set;network;help;peer;mtu'= {
        }
        &'wg-quickrs;config;set;network;help;connection'= {
            cand allowed-ips-a-to-b 'Set allowed IPs from peer A to peer B'
            cand allowed-ips-b-to-a 'Set allowed IPs from peer B to peer A'
            cand persistent-keepalive 'Set persistent keepalive period'
        }
        &'wg-quickrs;config;set;network;help;connection;allowed-ips-a-to-b'= {
        }
        &'wg-quickrs;config;set;network;help;connection;allowed-ips-b-to-a'= {
        }
        &'wg-quickrs;config;set;network;help;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;set;network;help;defaults'= {
            cand peer 'Set default peer configuration'
            cand connection 'Set default connection configuration'
        }
        &'wg-quickrs;config;set;network;help;defaults;peer'= {
            cand kind 'Set default peer kind'
            cand icon 'Set default peer icon source'
            cand dns 'Set default peer DNS addresses'
            cand mtu 'Set default peer MTU value'
        }
        &'wg-quickrs;config;set;network;help;defaults;peer;kind'= {
        }
        &'wg-quickrs;config;set;network;help;defaults;peer;icon'= {
        }
        &'wg-quickrs;config;set;network;help;defaults;peer;dns'= {
        }
        &'wg-quickrs;config;set;network;help;defaults;peer;mtu'= {
        }
        &'wg-quickrs;config;set;network;help;defaults;connection'= {
            cand persistent-keepalive 'Set default connection persistent keepalive period'
        }
        &'wg-quickrs;config;set;network;help;defaults;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;set;network;help;help'= {
        }
        &'wg-quickrs;config;set;help'= {
            cand agent 'Set agent configuration values'
            cand network 'Set network configuration values'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;set;help;agent'= {
            cand web 'Set web server configuration'
            cand vpn 'Set VPN configuration'
            cand firewall 'Set firewall configuration'
        }
        &'wg-quickrs;config;set;help;agent;web'= {
            cand address 'Set agent web server bind IPv4 address'
            cand http 'Set HTTP configuration'
            cand https 'Set HTTPS configuration'
        }
        &'wg-quickrs;config;set;help;agent;web;address'= {
        }
        &'wg-quickrs;config;set;help;agent;web;http'= {
            cand port 'Set web server HTTP port'
        }
        &'wg-quickrs;config;set;help;agent;web;http;port'= {
        }
        &'wg-quickrs;config;set;help;agent;web;https'= {
            cand port 'Set web server HTTPS port'
            cand tls-cert 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS'
            cand tls-key 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS'
        }
        &'wg-quickrs;config;set;help;agent;web;https;port'= {
        }
        &'wg-quickrs;config;set;help;agent;web;https;tls-cert'= {
        }
        &'wg-quickrs;config;set;help;agent;web;https;tls-key'= {
        }
        &'wg-quickrs;config;set;help;agent;vpn'= {
            cand port 'Set VPN server listening port'
        }
        &'wg-quickrs;config;set;help;agent;vpn;port'= {
        }
        &'wg-quickrs;config;set;help;agent;firewall'= {
            cand utility 'Set the utility used to configure firewall NAT and input rules (e.g. iptables, pfctl, etc.)'
            cand gateway 'Set the gateway used to configure firewall NAT and input rules (e.g. en0, eth0, etc.)'
        }
        &'wg-quickrs;config;set;help;agent;firewall;utility'= {
        }
        &'wg-quickrs;config;set;help;agent;firewall;gateway'= {
        }
        &'wg-quickrs;config;set;help;network'= {
            cand name 'Set network name'
            cand subnet 'Set network subnet'
            cand peer 'Set peer configuration'
            cand connection 'Set connection configuration'
            cand defaults 'Set default configuration'
        }
        &'wg-quickrs;config;set;help;network;name'= {
        }
        &'wg-quickrs;config;set;help;network;subnet'= {
        }
        &'wg-quickrs;config;set;help;network;peer'= {
            cand name 'Set peer name'
            cand address 'Set peer address'
            cand endpoint 'Set peer endpoint address'
            cand kind 'Set peer kind'
            cand icon 'Set peer icon source'
            cand dns 'Set peer DNS addresses'
            cand mtu 'Set peer MTU value'
        }
        &'wg-quickrs;config;set;help;network;peer;name'= {
        }
        &'wg-quickrs;config;set;help;network;peer;address'= {
        }
        &'wg-quickrs;config;set;help;network;peer;endpoint'= {
        }
        &'wg-quickrs;config;set;help;network;peer;kind'= {
        }
        &'wg-quickrs;config;set;help;network;peer;icon'= {
        }
        &'wg-quickrs;config;set;help;network;peer;dns'= {
        }
        &'wg-quickrs;config;set;help;network;peer;mtu'= {
        }
        &'wg-quickrs;config;set;help;network;connection'= {
            cand allowed-ips-a-to-b 'Set allowed IPs from peer A to peer B'
            cand allowed-ips-b-to-a 'Set allowed IPs from peer B to peer A'
            cand persistent-keepalive 'Set persistent keepalive period'
        }
        &'wg-quickrs;config;set;help;network;connection;allowed-ips-a-to-b'= {
        }
        &'wg-quickrs;config;set;help;network;connection;allowed-ips-b-to-a'= {
        }
        &'wg-quickrs;config;set;help;network;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;set;help;network;defaults'= {
            cand peer 'Set default peer configuration'
            cand connection 'Set default connection configuration'
        }
        &'wg-quickrs;config;set;help;network;defaults;peer'= {
            cand kind 'Set default peer kind'
            cand icon 'Set default peer icon source'
            cand dns 'Set default peer DNS addresses'
            cand mtu 'Set default peer MTU value'
        }
        &'wg-quickrs;config;set;help;network;defaults;peer;kind'= {
        }
        &'wg-quickrs;config;set;help;network;defaults;peer;icon'= {
        }
        &'wg-quickrs;config;set;help;network;defaults;peer;dns'= {
        }
        &'wg-quickrs;config;set;help;network;defaults;peer;mtu'= {
        }
        &'wg-quickrs;config;set;help;network;defaults;connection'= {
            cand persistent-keepalive 'Set default connection persistent keepalive period'
        }
        &'wg-quickrs;config;set;help;network;defaults;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;set;help;help'= {
        }
        &'wg-quickrs;config;reset'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand agent 'Reset agent configuration options'
            cand network 'Reset network configuration options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;reset;agent'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand web 'Reset web server configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;reset;agent;web'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand password 'Reset password for web server access'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;reset;agent;web;password'= {
            cand --password 'The use of this option is HIGHLY DISCOURAGED because the plaintext password might show up in the shell history! THIS IS HIGHLY INSECURE! Please set the password without the --password flag, and the script will prompt for the password.'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;reset;agent;web;help'= {
            cand password 'Reset password for web server access'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;reset;agent;web;help;password'= {
        }
        &'wg-quickrs;config;reset;agent;web;help;help'= {
        }
        &'wg-quickrs;config;reset;agent;help'= {
            cand web 'Reset web server configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;reset;agent;help;web'= {
            cand password 'Reset password for web server access'
        }
        &'wg-quickrs;config;reset;agent;help;web;password'= {
        }
        &'wg-quickrs;config;reset;agent;help;help'= {
        }
        &'wg-quickrs;config;reset;network'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand peer 'Reset peer options'
            cand connection 'Reset connection options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;reset;network;peer'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand private-key 'Reset peer private key (generates new WireGuard key)'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;reset;network;peer;private-key'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;reset;network;peer;help'= {
            cand private-key 'Reset peer private key (generates new WireGuard key)'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;reset;network;peer;help;private-key'= {
        }
        &'wg-quickrs;config;reset;network;peer;help;help'= {
        }
        &'wg-quickrs;config;reset;network;connection'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand pre-shared-key 'Reset connection pre-shared key (generates new WireGuard key)'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;reset;network;connection;pre-shared-key'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;reset;network;connection;help'= {
            cand pre-shared-key 'Reset connection pre-shared key (generates new WireGuard key)'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;reset;network;connection;help;pre-shared-key'= {
        }
        &'wg-quickrs;config;reset;network;connection;help;help'= {
        }
        &'wg-quickrs;config;reset;network;help'= {
            cand peer 'Reset peer options'
            cand connection 'Reset connection options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;reset;network;help;peer'= {
            cand private-key 'Reset peer private key (generates new WireGuard key)'
        }
        &'wg-quickrs;config;reset;network;help;peer;private-key'= {
        }
        &'wg-quickrs;config;reset;network;help;connection'= {
            cand pre-shared-key 'Reset connection pre-shared key (generates new WireGuard key)'
        }
        &'wg-quickrs;config;reset;network;help;connection;pre-shared-key'= {
        }
        &'wg-quickrs;config;reset;network;help;help'= {
        }
        &'wg-quickrs;config;reset;help'= {
            cand agent 'Reset agent configuration options'
            cand network 'Reset network configuration options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;reset;help;agent'= {
            cand web 'Reset web server configuration'
        }
        &'wg-quickrs;config;reset;help;agent;web'= {
            cand password 'Reset password for web server access'
        }
        &'wg-quickrs;config;reset;help;agent;web;password'= {
        }
        &'wg-quickrs;config;reset;help;network'= {
            cand peer 'Reset peer options'
            cand connection 'Reset connection options'
        }
        &'wg-quickrs;config;reset;help;network;peer'= {
            cand private-key 'Reset peer private key (generates new WireGuard key)'
        }
        &'wg-quickrs;config;reset;help;network;peer;private-key'= {
        }
        &'wg-quickrs;config;reset;help;network;connection'= {
            cand pre-shared-key 'Reset connection pre-shared key (generates new WireGuard key)'
        }
        &'wg-quickrs;config;reset;help;network;connection;pre-shared-key'= {
        }
        &'wg-quickrs;config;reset;help;help'= {
        }
        &'wg-quickrs;config;get'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand agent 'Get agent configuration values'
            cand network 'Get network configuration values'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand web 'Get web server configuration'
            cand vpn 'Get VPN configuration'
            cand firewall 'Get firewall configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;web'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand address 'Get agent web server bind IPv4 address'
            cand http 'Get HTTP configuration'
            cand https 'Get HTTPS configuration'
            cand password 'Get password authentication configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;web;address'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;web;http'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether HTTP is enabled'
            cand port 'Get web server HTTP port'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;web;http;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;web;http;port'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;web;http;help'= {
            cand enabled 'Get whether HTTP is enabled'
            cand port 'Get web server HTTP port'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;web;http;help;enabled'= {
        }
        &'wg-quickrs;config;get;agent;web;http;help;port'= {
        }
        &'wg-quickrs;config;get;agent;web;http;help;help'= {
        }
        &'wg-quickrs;config;get;agent;web;https'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether HTTPS is enabled'
            cand port 'Get web server HTTPS port'
            cand tls-cert 'Get path to TLS certificate file for HTTPS'
            cand tls-key 'Get path to TLS private key file for HTTPS'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;web;https;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;web;https;port'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;web;https;tls-cert'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;web;https;tls-key'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;web;https;help'= {
            cand enabled 'Get whether HTTPS is enabled'
            cand port 'Get web server HTTPS port'
            cand tls-cert 'Get path to TLS certificate file for HTTPS'
            cand tls-key 'Get path to TLS private key file for HTTPS'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;web;https;help;enabled'= {
        }
        &'wg-quickrs;config;get;agent;web;https;help;port'= {
        }
        &'wg-quickrs;config;get;agent;web;https;help;tls-cert'= {
        }
        &'wg-quickrs;config;get;agent;web;https;help;tls-key'= {
        }
        &'wg-quickrs;config;get;agent;web;https;help;help'= {
        }
        &'wg-quickrs;config;get;agent;web;password'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether password authentication is enabled'
            cand hash 'Get password hash'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;web;password;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;web;password;hash'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;web;password;help'= {
            cand enabled 'Get whether password authentication is enabled'
            cand hash 'Get password hash'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;web;password;help;enabled'= {
        }
        &'wg-quickrs;config;get;agent;web;password;help;hash'= {
        }
        &'wg-quickrs;config;get;agent;web;password;help;help'= {
        }
        &'wg-quickrs;config;get;agent;web;help'= {
            cand address 'Get agent web server bind IPv4 address'
            cand http 'Get HTTP configuration'
            cand https 'Get HTTPS configuration'
            cand password 'Get password authentication configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;web;help;address'= {
        }
        &'wg-quickrs;config;get;agent;web;help;http'= {
            cand enabled 'Get whether HTTP is enabled'
            cand port 'Get web server HTTP port'
        }
        &'wg-quickrs;config;get;agent;web;help;http;enabled'= {
        }
        &'wg-quickrs;config;get;agent;web;help;http;port'= {
        }
        &'wg-quickrs;config;get;agent;web;help;https'= {
            cand enabled 'Get whether HTTPS is enabled'
            cand port 'Get web server HTTPS port'
            cand tls-cert 'Get path to TLS certificate file for HTTPS'
            cand tls-key 'Get path to TLS private key file for HTTPS'
        }
        &'wg-quickrs;config;get;agent;web;help;https;enabled'= {
        }
        &'wg-quickrs;config;get;agent;web;help;https;port'= {
        }
        &'wg-quickrs;config;get;agent;web;help;https;tls-cert'= {
        }
        &'wg-quickrs;config;get;agent;web;help;https;tls-key'= {
        }
        &'wg-quickrs;config;get;agent;web;help;password'= {
            cand enabled 'Get whether password authentication is enabled'
            cand hash 'Get password hash'
        }
        &'wg-quickrs;config;get;agent;web;help;password;enabled'= {
        }
        &'wg-quickrs;config;get;agent;web;help;password;hash'= {
        }
        &'wg-quickrs;config;get;agent;web;help;help'= {
        }
        &'wg-quickrs;config;get;agent;vpn'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether VPN server is enabled'
            cand port 'Get VPN server listening port'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;vpn;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;vpn;port'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;vpn;help'= {
            cand enabled 'Get whether VPN server is enabled'
            cand port 'Get VPN server listening port'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;vpn;help;enabled'= {
        }
        &'wg-quickrs;config;get;agent;vpn;help;port'= {
        }
        &'wg-quickrs;config;get;agent;vpn;help;help'= {
        }
        &'wg-quickrs;config;get;agent;firewall'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether firewall configuration is enabled'
            cand utility 'Get the utility used to configure firewall NAT and input rules'
            cand gateway 'Get the gateway used to configure firewall NAT and input rules'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;firewall;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;firewall;utility'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;firewall;gateway'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;agent;firewall;help'= {
            cand enabled 'Get whether firewall configuration is enabled'
            cand utility 'Get the utility used to configure firewall NAT and input rules'
            cand gateway 'Get the gateway used to configure firewall NAT and input rules'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;firewall;help;enabled'= {
        }
        &'wg-quickrs;config;get;agent;firewall;help;utility'= {
        }
        &'wg-quickrs;config;get;agent;firewall;help;gateway'= {
        }
        &'wg-quickrs;config;get;agent;firewall;help;help'= {
        }
        &'wg-quickrs;config;get;agent;help'= {
            cand web 'Get web server configuration'
            cand vpn 'Get VPN configuration'
            cand firewall 'Get firewall configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;agent;help;web'= {
            cand address 'Get agent web server bind IPv4 address'
            cand http 'Get HTTP configuration'
            cand https 'Get HTTPS configuration'
            cand password 'Get password authentication configuration'
        }
        &'wg-quickrs;config;get;agent;help;web;address'= {
        }
        &'wg-quickrs;config;get;agent;help;web;http'= {
            cand enabled 'Get whether HTTP is enabled'
            cand port 'Get web server HTTP port'
        }
        &'wg-quickrs;config;get;agent;help;web;http;enabled'= {
        }
        &'wg-quickrs;config;get;agent;help;web;http;port'= {
        }
        &'wg-quickrs;config;get;agent;help;web;https'= {
            cand enabled 'Get whether HTTPS is enabled'
            cand port 'Get web server HTTPS port'
            cand tls-cert 'Get path to TLS certificate file for HTTPS'
            cand tls-key 'Get path to TLS private key file for HTTPS'
        }
        &'wg-quickrs;config;get;agent;help;web;https;enabled'= {
        }
        &'wg-quickrs;config;get;agent;help;web;https;port'= {
        }
        &'wg-quickrs;config;get;agent;help;web;https;tls-cert'= {
        }
        &'wg-quickrs;config;get;agent;help;web;https;tls-key'= {
        }
        &'wg-quickrs;config;get;agent;help;web;password'= {
            cand enabled 'Get whether password authentication is enabled'
            cand hash 'Get password hash'
        }
        &'wg-quickrs;config;get;agent;help;web;password;enabled'= {
        }
        &'wg-quickrs;config;get;agent;help;web;password;hash'= {
        }
        &'wg-quickrs;config;get;agent;help;vpn'= {
            cand enabled 'Get whether VPN server is enabled'
            cand port 'Get VPN server listening port'
        }
        &'wg-quickrs;config;get;agent;help;vpn;enabled'= {
        }
        &'wg-quickrs;config;get;agent;help;vpn;port'= {
        }
        &'wg-quickrs;config;get;agent;help;firewall'= {
            cand enabled 'Get whether firewall configuration is enabled'
            cand utility 'Get the utility used to configure firewall NAT and input rules'
            cand gateway 'Get the gateway used to configure firewall NAT and input rules'
        }
        &'wg-quickrs;config;get;agent;help;firewall;enabled'= {
        }
        &'wg-quickrs;config;get;agent;help;firewall;utility'= {
        }
        &'wg-quickrs;config;get;agent;help;firewall;gateway'= {
        }
        &'wg-quickrs;config;get;agent;help;help'= {
        }
        &'wg-quickrs;config;get;network'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand name 'Get network name'
            cand subnet 'Get network subnet'
            cand this-peer 'Get this peer''s UUID'
            cand peers 'Get network peers'
            cand connections 'Get network connections'
            cand defaults 'Get network defaults'
            cand reservations 'Get network reservations'
            cand updated-at 'Get network last updated timestamp'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;name'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;subnet'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;this-peer'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand name 'Get peer name'
            cand address 'Get peer IP address'
            cand endpoint 'Get peer endpoint'
            cand kind 'Get peer kind'
            cand icon 'Get peer icon'
            cand dns 'Get peer DNS'
            cand mtu 'Get peer MTU'
            cand scripts 'Get peer scripts'
            cand private-key 'Get peer private key'
            cand created-at 'Get peer creation timestamp'
            cand updated-at 'Get peer last updated timestamp'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;peers;name'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;address'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;endpoint'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether endpoint is enabled'
            cand address 'Get endpoint address'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;peers;endpoint;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;endpoint;address'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;endpoint;help'= {
            cand enabled 'Get whether endpoint is enabled'
            cand address 'Get endpoint address'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;peers;endpoint;help;enabled'= {
        }
        &'wg-quickrs;config;get;network;peers;endpoint;help;address'= {
        }
        &'wg-quickrs;config;get;network;peers;endpoint;help;help'= {
        }
        &'wg-quickrs;config;get;network;peers;kind'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;icon'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;peers;icon;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;icon;src'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;icon;help'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;peers;icon;help;enabled'= {
        }
        &'wg-quickrs;config;get;network;peers;icon;help;src'= {
        }
        &'wg-quickrs;config;get;network;peers;icon;help;help'= {
        }
        &'wg-quickrs;config;get;network;peers;dns'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;peers;dns;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;dns;addresses'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;dns;help'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;peers;dns;help;enabled'= {
        }
        &'wg-quickrs;config;get;network;peers;dns;help;addresses'= {
        }
        &'wg-quickrs;config;get;network;peers;dns;help;help'= {
        }
        &'wg-quickrs;config;get;network;peers;mtu'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;peers;mtu;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;mtu;value'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;mtu;help'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;peers;mtu;help;enabled'= {
        }
        &'wg-quickrs;config;get;network;peers;mtu;help;value'= {
        }
        &'wg-quickrs;config;get;network;peers;mtu;help;help'= {
        }
        &'wg-quickrs;config;get;network;peers;scripts'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;private-key'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;created-at'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;updated-at'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;peers;help'= {
            cand name 'Get peer name'
            cand address 'Get peer IP address'
            cand endpoint 'Get peer endpoint'
            cand kind 'Get peer kind'
            cand icon 'Get peer icon'
            cand dns 'Get peer DNS'
            cand mtu 'Get peer MTU'
            cand scripts 'Get peer scripts'
            cand private-key 'Get peer private key'
            cand created-at 'Get peer creation timestamp'
            cand updated-at 'Get peer last updated timestamp'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;peers;help;name'= {
        }
        &'wg-quickrs;config;get;network;peers;help;address'= {
        }
        &'wg-quickrs;config;get;network;peers;help;endpoint'= {
            cand enabled 'Get whether endpoint is enabled'
            cand address 'Get endpoint address'
        }
        &'wg-quickrs;config;get;network;peers;help;endpoint;enabled'= {
        }
        &'wg-quickrs;config;get;network;peers;help;endpoint;address'= {
        }
        &'wg-quickrs;config;get;network;peers;help;kind'= {
        }
        &'wg-quickrs;config;get;network;peers;help;icon'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
        }
        &'wg-quickrs;config;get;network;peers;help;icon;enabled'= {
        }
        &'wg-quickrs;config;get;network;peers;help;icon;src'= {
        }
        &'wg-quickrs;config;get;network;peers;help;dns'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
        }
        &'wg-quickrs;config;get;network;peers;help;dns;enabled'= {
        }
        &'wg-quickrs;config;get;network;peers;help;dns;addresses'= {
        }
        &'wg-quickrs;config;get;network;peers;help;mtu'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
        }
        &'wg-quickrs;config;get;network;peers;help;mtu;enabled'= {
        }
        &'wg-quickrs;config;get;network;peers;help;mtu;value'= {
        }
        &'wg-quickrs;config;get;network;peers;help;scripts'= {
        }
        &'wg-quickrs;config;get;network;peers;help;private-key'= {
        }
        &'wg-quickrs;config;get;network;peers;help;created-at'= {
        }
        &'wg-quickrs;config;get;network;peers;help;updated-at'= {
        }
        &'wg-quickrs;config;get;network;peers;help;help'= {
        }
        &'wg-quickrs;config;get;network;connections'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether connection is enabled'
            cand pre-shared-key 'Get connection pre-shared key'
            cand persistent-keepalive 'Get connection persistent keepalive'
            cand allowed-ips-a-to-b 'Get allowed IPs from A to B'
            cand allowed-ips-b-to-a 'Get allowed IPs from B to A'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;connections;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;connections;pre-shared-key'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;connections;persistent-keepalive'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;connections;persistent-keepalive;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;connections;persistent-keepalive;period'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;connections;persistent-keepalive;help'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;connections;persistent-keepalive;help;enabled'= {
        }
        &'wg-quickrs;config;get;network;connections;persistent-keepalive;help;period'= {
        }
        &'wg-quickrs;config;get;network;connections;persistent-keepalive;help;help'= {
        }
        &'wg-quickrs;config;get;network;connections;allowed-ips-a-to-b'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;connections;allowed-ips-b-to-a'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;connections;help'= {
            cand enabled 'Get whether connection is enabled'
            cand pre-shared-key 'Get connection pre-shared key'
            cand persistent-keepalive 'Get connection persistent keepalive'
            cand allowed-ips-a-to-b 'Get allowed IPs from A to B'
            cand allowed-ips-b-to-a 'Get allowed IPs from B to A'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;connections;help;enabled'= {
        }
        &'wg-quickrs;config;get;network;connections;help;pre-shared-key'= {
        }
        &'wg-quickrs;config;get;network;connections;help;persistent-keepalive'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
        }
        &'wg-quickrs;config;get;network;connections;help;persistent-keepalive;enabled'= {
        }
        &'wg-quickrs;config;get;network;connections;help;persistent-keepalive;period'= {
        }
        &'wg-quickrs;config;get;network;connections;help;allowed-ips-a-to-b'= {
        }
        &'wg-quickrs;config;get;network;connections;help;allowed-ips-b-to-a'= {
        }
        &'wg-quickrs;config;get;network;connections;help;help'= {
        }
        &'wg-quickrs;config;get;network;defaults'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand peer 'Get default peer configuration'
            cand connection 'Get default connection configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;peer'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand kind 'Get default peer kind'
            cand icon 'Get default peer icon'
            cand dns 'Get default peer DNS'
            cand mtu 'Get default peer MTU'
            cand scripts 'Get default peer scripts'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;peer;kind'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;defaults;peer;icon'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;peer;icon;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;defaults;peer;icon;src'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;defaults;peer;icon;help'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;peer;icon;help;enabled'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;icon;help;src'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;icon;help;help'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;dns'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;peer;dns;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;defaults;peer;dns;addresses'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;defaults;peer;dns;help'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;peer;dns;help;enabled'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;dns;help;addresses'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;dns;help;help'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;mtu'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;peer;mtu;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;defaults;peer;mtu;value'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;defaults;peer;mtu;help'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;peer;mtu;help;enabled'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;mtu;help;value'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;mtu;help;help'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;scripts'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;defaults;peer;help'= {
            cand kind 'Get default peer kind'
            cand icon 'Get default peer icon'
            cand dns 'Get default peer DNS'
            cand mtu 'Get default peer MTU'
            cand scripts 'Get default peer scripts'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;peer;help;kind'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;help;icon'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
        }
        &'wg-quickrs;config;get;network;defaults;peer;help;icon;enabled'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;help;icon;src'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;help;dns'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
        }
        &'wg-quickrs;config;get;network;defaults;peer;help;dns;enabled'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;help;dns;addresses'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;help;mtu'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
        }
        &'wg-quickrs;config;get;network;defaults;peer;help;mtu;enabled'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;help;mtu;value'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;help;scripts'= {
        }
        &'wg-quickrs;config;get;network;defaults;peer;help;help'= {
        }
        &'wg-quickrs;config;get;network;defaults;connection'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand persistent-keepalive 'Get default connection persistent keepalive'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive;enabled'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive;period'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive;help'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive;help;enabled'= {
        }
        &'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive;help;period'= {
        }
        &'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive;help;help'= {
        }
        &'wg-quickrs;config;get;network;defaults;connection;help'= {
            cand persistent-keepalive 'Get default connection persistent keepalive'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;connection;help;persistent-keepalive'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
        }
        &'wg-quickrs;config;get;network;defaults;connection;help;persistent-keepalive;enabled'= {
        }
        &'wg-quickrs;config;get;network;defaults;connection;help;persistent-keepalive;period'= {
        }
        &'wg-quickrs;config;get;network;defaults;connection;help;help'= {
        }
        &'wg-quickrs;config;get;network;defaults;help'= {
            cand peer 'Get default peer configuration'
            cand connection 'Get default connection configuration'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;defaults;help;peer'= {
            cand kind 'Get default peer kind'
            cand icon 'Get default peer icon'
            cand dns 'Get default peer DNS'
            cand mtu 'Get default peer MTU'
            cand scripts 'Get default peer scripts'
        }
        &'wg-quickrs;config;get;network;defaults;help;peer;kind'= {
        }
        &'wg-quickrs;config;get;network;defaults;help;peer;icon'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
        }
        &'wg-quickrs;config;get;network;defaults;help;peer;icon;enabled'= {
        }
        &'wg-quickrs;config;get;network;defaults;help;peer;icon;src'= {
        }
        &'wg-quickrs;config;get;network;defaults;help;peer;dns'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
        }
        &'wg-quickrs;config;get;network;defaults;help;peer;dns;enabled'= {
        }
        &'wg-quickrs;config;get;network;defaults;help;peer;dns;addresses'= {
        }
        &'wg-quickrs;config;get;network;defaults;help;peer;mtu'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
        }
        &'wg-quickrs;config;get;network;defaults;help;peer;mtu;enabled'= {
        }
        &'wg-quickrs;config;get;network;defaults;help;peer;mtu;value'= {
        }
        &'wg-quickrs;config;get;network;defaults;help;peer;scripts'= {
        }
        &'wg-quickrs;config;get;network;defaults;help;connection'= {
            cand persistent-keepalive 'Get default connection persistent keepalive'
        }
        &'wg-quickrs;config;get;network;defaults;help;connection;persistent-keepalive'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
        }
        &'wg-quickrs;config;get;network;defaults;help;connection;persistent-keepalive;enabled'= {
        }
        &'wg-quickrs;config;get;network;defaults;help;connection;persistent-keepalive;period'= {
        }
        &'wg-quickrs;config;get;network;defaults;help;help'= {
        }
        &'wg-quickrs;config;get;network;reservations'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand peer-id 'Get reservation peer ID'
            cand valid-until 'Get reservation validity timestamp'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;reservations;peer-id'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;reservations;valid-until'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;reservations;help'= {
            cand peer-id 'Get reservation peer ID'
            cand valid-until 'Get reservation validity timestamp'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;reservations;help;peer-id'= {
        }
        &'wg-quickrs;config;get;network;reservations;help;valid-until'= {
        }
        &'wg-quickrs;config;get;network;reservations;help;help'= {
        }
        &'wg-quickrs;config;get;network;updated-at'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;get;network;help'= {
            cand name 'Get network name'
            cand subnet 'Get network subnet'
            cand this-peer 'Get this peer''s UUID'
            cand peers 'Get network peers'
            cand connections 'Get network connections'
            cand defaults 'Get network defaults'
            cand reservations 'Get network reservations'
            cand updated-at 'Get network last updated timestamp'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;network;help;name'= {
        }
        &'wg-quickrs;config;get;network;help;subnet'= {
        }
        &'wg-quickrs;config;get;network;help;this-peer'= {
        }
        &'wg-quickrs;config;get;network;help;peers'= {
            cand name 'Get peer name'
            cand address 'Get peer IP address'
            cand endpoint 'Get peer endpoint'
            cand kind 'Get peer kind'
            cand icon 'Get peer icon'
            cand dns 'Get peer DNS'
            cand mtu 'Get peer MTU'
            cand scripts 'Get peer scripts'
            cand private-key 'Get peer private key'
            cand created-at 'Get peer creation timestamp'
            cand updated-at 'Get peer last updated timestamp'
        }
        &'wg-quickrs;config;get;network;help;peers;name'= {
        }
        &'wg-quickrs;config;get;network;help;peers;address'= {
        }
        &'wg-quickrs;config;get;network;help;peers;endpoint'= {
            cand enabled 'Get whether endpoint is enabled'
            cand address 'Get endpoint address'
        }
        &'wg-quickrs;config;get;network;help;peers;endpoint;enabled'= {
        }
        &'wg-quickrs;config;get;network;help;peers;endpoint;address'= {
        }
        &'wg-quickrs;config;get;network;help;peers;kind'= {
        }
        &'wg-quickrs;config;get;network;help;peers;icon'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
        }
        &'wg-quickrs;config;get;network;help;peers;icon;enabled'= {
        }
        &'wg-quickrs;config;get;network;help;peers;icon;src'= {
        }
        &'wg-quickrs;config;get;network;help;peers;dns'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
        }
        &'wg-quickrs;config;get;network;help;peers;dns;enabled'= {
        }
        &'wg-quickrs;config;get;network;help;peers;dns;addresses'= {
        }
        &'wg-quickrs;config;get;network;help;peers;mtu'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
        }
        &'wg-quickrs;config;get;network;help;peers;mtu;enabled'= {
        }
        &'wg-quickrs;config;get;network;help;peers;mtu;value'= {
        }
        &'wg-quickrs;config;get;network;help;peers;scripts'= {
        }
        &'wg-quickrs;config;get;network;help;peers;private-key'= {
        }
        &'wg-quickrs;config;get;network;help;peers;created-at'= {
        }
        &'wg-quickrs;config;get;network;help;peers;updated-at'= {
        }
        &'wg-quickrs;config;get;network;help;connections'= {
            cand enabled 'Get whether connection is enabled'
            cand pre-shared-key 'Get connection pre-shared key'
            cand persistent-keepalive 'Get connection persistent keepalive'
            cand allowed-ips-a-to-b 'Get allowed IPs from A to B'
            cand allowed-ips-b-to-a 'Get allowed IPs from B to A'
        }
        &'wg-quickrs;config;get;network;help;connections;enabled'= {
        }
        &'wg-quickrs;config;get;network;help;connections;pre-shared-key'= {
        }
        &'wg-quickrs;config;get;network;help;connections;persistent-keepalive'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
        }
        &'wg-quickrs;config;get;network;help;connections;persistent-keepalive;enabled'= {
        }
        &'wg-quickrs;config;get;network;help;connections;persistent-keepalive;period'= {
        }
        &'wg-quickrs;config;get;network;help;connections;allowed-ips-a-to-b'= {
        }
        &'wg-quickrs;config;get;network;help;connections;allowed-ips-b-to-a'= {
        }
        &'wg-quickrs;config;get;network;help;defaults'= {
            cand peer 'Get default peer configuration'
            cand connection 'Get default connection configuration'
        }
        &'wg-quickrs;config;get;network;help;defaults;peer'= {
            cand kind 'Get default peer kind'
            cand icon 'Get default peer icon'
            cand dns 'Get default peer DNS'
            cand mtu 'Get default peer MTU'
            cand scripts 'Get default peer scripts'
        }
        &'wg-quickrs;config;get;network;help;defaults;peer;kind'= {
        }
        &'wg-quickrs;config;get;network;help;defaults;peer;icon'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
        }
        &'wg-quickrs;config;get;network;help;defaults;peer;icon;enabled'= {
        }
        &'wg-quickrs;config;get;network;help;defaults;peer;icon;src'= {
        }
        &'wg-quickrs;config;get;network;help;defaults;peer;dns'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
        }
        &'wg-quickrs;config;get;network;help;defaults;peer;dns;enabled'= {
        }
        &'wg-quickrs;config;get;network;help;defaults;peer;dns;addresses'= {
        }
        &'wg-quickrs;config;get;network;help;defaults;peer;mtu'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
        }
        &'wg-quickrs;config;get;network;help;defaults;peer;mtu;enabled'= {
        }
        &'wg-quickrs;config;get;network;help;defaults;peer;mtu;value'= {
        }
        &'wg-quickrs;config;get;network;help;defaults;peer;scripts'= {
        }
        &'wg-quickrs;config;get;network;help;defaults;connection'= {
            cand persistent-keepalive 'Get default connection persistent keepalive'
        }
        &'wg-quickrs;config;get;network;help;defaults;connection;persistent-keepalive'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
        }
        &'wg-quickrs;config;get;network;help;defaults;connection;persistent-keepalive;enabled'= {
        }
        &'wg-quickrs;config;get;network;help;defaults;connection;persistent-keepalive;period'= {
        }
        &'wg-quickrs;config;get;network;help;reservations'= {
            cand peer-id 'Get reservation peer ID'
            cand valid-until 'Get reservation validity timestamp'
        }
        &'wg-quickrs;config;get;network;help;reservations;peer-id'= {
        }
        &'wg-quickrs;config;get;network;help;reservations;valid-until'= {
        }
        &'wg-quickrs;config;get;network;help;updated-at'= {
        }
        &'wg-quickrs;config;get;network;help;help'= {
        }
        &'wg-quickrs;config;get;help'= {
            cand agent 'Get agent configuration values'
            cand network 'Get network configuration values'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;get;help;agent'= {
            cand web 'Get web server configuration'
            cand vpn 'Get VPN configuration'
            cand firewall 'Get firewall configuration'
        }
        &'wg-quickrs;config;get;help;agent;web'= {
            cand address 'Get agent web server bind IPv4 address'
            cand http 'Get HTTP configuration'
            cand https 'Get HTTPS configuration'
            cand password 'Get password authentication configuration'
        }
        &'wg-quickrs;config;get;help;agent;web;address'= {
        }
        &'wg-quickrs;config;get;help;agent;web;http'= {
            cand enabled 'Get whether HTTP is enabled'
            cand port 'Get web server HTTP port'
        }
        &'wg-quickrs;config;get;help;agent;web;http;enabled'= {
        }
        &'wg-quickrs;config;get;help;agent;web;http;port'= {
        }
        &'wg-quickrs;config;get;help;agent;web;https'= {
            cand enabled 'Get whether HTTPS is enabled'
            cand port 'Get web server HTTPS port'
            cand tls-cert 'Get path to TLS certificate file for HTTPS'
            cand tls-key 'Get path to TLS private key file for HTTPS'
        }
        &'wg-quickrs;config;get;help;agent;web;https;enabled'= {
        }
        &'wg-quickrs;config;get;help;agent;web;https;port'= {
        }
        &'wg-quickrs;config;get;help;agent;web;https;tls-cert'= {
        }
        &'wg-quickrs;config;get;help;agent;web;https;tls-key'= {
        }
        &'wg-quickrs;config;get;help;agent;web;password'= {
            cand enabled 'Get whether password authentication is enabled'
            cand hash 'Get password hash'
        }
        &'wg-quickrs;config;get;help;agent;web;password;enabled'= {
        }
        &'wg-quickrs;config;get;help;agent;web;password;hash'= {
        }
        &'wg-quickrs;config;get;help;agent;vpn'= {
            cand enabled 'Get whether VPN server is enabled'
            cand port 'Get VPN server listening port'
        }
        &'wg-quickrs;config;get;help;agent;vpn;enabled'= {
        }
        &'wg-quickrs;config;get;help;agent;vpn;port'= {
        }
        &'wg-quickrs;config;get;help;agent;firewall'= {
            cand enabled 'Get whether firewall configuration is enabled'
            cand utility 'Get the utility used to configure firewall NAT and input rules'
            cand gateway 'Get the gateway used to configure firewall NAT and input rules'
        }
        &'wg-quickrs;config;get;help;agent;firewall;enabled'= {
        }
        &'wg-quickrs;config;get;help;agent;firewall;utility'= {
        }
        &'wg-quickrs;config;get;help;agent;firewall;gateway'= {
        }
        &'wg-quickrs;config;get;help;network'= {
            cand name 'Get network name'
            cand subnet 'Get network subnet'
            cand this-peer 'Get this peer''s UUID'
            cand peers 'Get network peers'
            cand connections 'Get network connections'
            cand defaults 'Get network defaults'
            cand reservations 'Get network reservations'
            cand updated-at 'Get network last updated timestamp'
        }
        &'wg-quickrs;config;get;help;network;name'= {
        }
        &'wg-quickrs;config;get;help;network;subnet'= {
        }
        &'wg-quickrs;config;get;help;network;this-peer'= {
        }
        &'wg-quickrs;config;get;help;network;peers'= {
            cand name 'Get peer name'
            cand address 'Get peer IP address'
            cand endpoint 'Get peer endpoint'
            cand kind 'Get peer kind'
            cand icon 'Get peer icon'
            cand dns 'Get peer DNS'
            cand mtu 'Get peer MTU'
            cand scripts 'Get peer scripts'
            cand private-key 'Get peer private key'
            cand created-at 'Get peer creation timestamp'
            cand updated-at 'Get peer last updated timestamp'
        }
        &'wg-quickrs;config;get;help;network;peers;name'= {
        }
        &'wg-quickrs;config;get;help;network;peers;address'= {
        }
        &'wg-quickrs;config;get;help;network;peers;endpoint'= {
            cand enabled 'Get whether endpoint is enabled'
            cand address 'Get endpoint address'
        }
        &'wg-quickrs;config;get;help;network;peers;endpoint;enabled'= {
        }
        &'wg-quickrs;config;get;help;network;peers;endpoint;address'= {
        }
        &'wg-quickrs;config;get;help;network;peers;kind'= {
        }
        &'wg-quickrs;config;get;help;network;peers;icon'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
        }
        &'wg-quickrs;config;get;help;network;peers;icon;enabled'= {
        }
        &'wg-quickrs;config;get;help;network;peers;icon;src'= {
        }
        &'wg-quickrs;config;get;help;network;peers;dns'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
        }
        &'wg-quickrs;config;get;help;network;peers;dns;enabled'= {
        }
        &'wg-quickrs;config;get;help;network;peers;dns;addresses'= {
        }
        &'wg-quickrs;config;get;help;network;peers;mtu'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
        }
        &'wg-quickrs;config;get;help;network;peers;mtu;enabled'= {
        }
        &'wg-quickrs;config;get;help;network;peers;mtu;value'= {
        }
        &'wg-quickrs;config;get;help;network;peers;scripts'= {
        }
        &'wg-quickrs;config;get;help;network;peers;private-key'= {
        }
        &'wg-quickrs;config;get;help;network;peers;created-at'= {
        }
        &'wg-quickrs;config;get;help;network;peers;updated-at'= {
        }
        &'wg-quickrs;config;get;help;network;connections'= {
            cand enabled 'Get whether connection is enabled'
            cand pre-shared-key 'Get connection pre-shared key'
            cand persistent-keepalive 'Get connection persistent keepalive'
            cand allowed-ips-a-to-b 'Get allowed IPs from A to B'
            cand allowed-ips-b-to-a 'Get allowed IPs from B to A'
        }
        &'wg-quickrs;config;get;help;network;connections;enabled'= {
        }
        &'wg-quickrs;config;get;help;network;connections;pre-shared-key'= {
        }
        &'wg-quickrs;config;get;help;network;connections;persistent-keepalive'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
        }
        &'wg-quickrs;config;get;help;network;connections;persistent-keepalive;enabled'= {
        }
        &'wg-quickrs;config;get;help;network;connections;persistent-keepalive;period'= {
        }
        &'wg-quickrs;config;get;help;network;connections;allowed-ips-a-to-b'= {
        }
        &'wg-quickrs;config;get;help;network;connections;allowed-ips-b-to-a'= {
        }
        &'wg-quickrs;config;get;help;network;defaults'= {
            cand peer 'Get default peer configuration'
            cand connection 'Get default connection configuration'
        }
        &'wg-quickrs;config;get;help;network;defaults;peer'= {
            cand kind 'Get default peer kind'
            cand icon 'Get default peer icon'
            cand dns 'Get default peer DNS'
            cand mtu 'Get default peer MTU'
            cand scripts 'Get default peer scripts'
        }
        &'wg-quickrs;config;get;help;network;defaults;peer;kind'= {
        }
        &'wg-quickrs;config;get;help;network;defaults;peer;icon'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
        }
        &'wg-quickrs;config;get;help;network;defaults;peer;icon;enabled'= {
        }
        &'wg-quickrs;config;get;help;network;defaults;peer;icon;src'= {
        }
        &'wg-quickrs;config;get;help;network;defaults;peer;dns'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
        }
        &'wg-quickrs;config;get;help;network;defaults;peer;dns;enabled'= {
        }
        &'wg-quickrs;config;get;help;network;defaults;peer;dns;addresses'= {
        }
        &'wg-quickrs;config;get;help;network;defaults;peer;mtu'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
        }
        &'wg-quickrs;config;get;help;network;defaults;peer;mtu;enabled'= {
        }
        &'wg-quickrs;config;get;help;network;defaults;peer;mtu;value'= {
        }
        &'wg-quickrs;config;get;help;network;defaults;peer;scripts'= {
        }
        &'wg-quickrs;config;get;help;network;defaults;connection'= {
            cand persistent-keepalive 'Get default connection persistent keepalive'
        }
        &'wg-quickrs;config;get;help;network;defaults;connection;persistent-keepalive'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
        }
        &'wg-quickrs;config;get;help;network;defaults;connection;persistent-keepalive;enabled'= {
        }
        &'wg-quickrs;config;get;help;network;defaults;connection;persistent-keepalive;period'= {
        }
        &'wg-quickrs;config;get;help;network;reservations'= {
            cand peer-id 'Get reservation peer ID'
            cand valid-until 'Get reservation validity timestamp'
        }
        &'wg-quickrs;config;get;help;network;reservations;peer-id'= {
        }
        &'wg-quickrs;config;get;help;network;reservations;valid-until'= {
        }
        &'wg-quickrs;config;get;help;network;updated-at'= {
        }
        &'wg-quickrs;config;get;help;help'= {
        }
        &'wg-quickrs;config;list'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand peers 'List all peers in human-readable format'
            cand connections 'List all connections in human-readable format'
            cand reservations 'List all reservations in human-readable format'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;list;peers'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;list;connections'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;list;reservations'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;list;help'= {
            cand peers 'List all peers in human-readable format'
            cand connections 'List all connections in human-readable format'
            cand reservations 'List all reservations in human-readable format'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;list;help;peers'= {
        }
        &'wg-quickrs;config;list;help;connections'= {
        }
        &'wg-quickrs;config;list;help;reservations'= {
        }
        &'wg-quickrs;config;list;help;help'= {
        }
        &'wg-quickrs;config;remove'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand peer 'Remove a peer by UUID'
            cand connection 'Remove a connection by connection ID'
            cand reservation 'Remove a reservation by IPv4 address'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;remove;peer'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;remove;connection'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;remove;reservation'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'wg-quickrs;config;remove;help'= {
            cand peer 'Remove a peer by UUID'
            cand connection 'Remove a connection by connection ID'
            cand reservation 'Remove a reservation by IPv4 address'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;remove;help;peer'= {
        }
        &'wg-quickrs;config;remove;help;connection'= {
        }
        &'wg-quickrs;config;remove;help;reservation'= {
        }
        &'wg-quickrs;config;remove;help;help'= {
        }
        &'wg-quickrs;config;add'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand peer 'Add a peer to the network'
            cand connection 'Add a connection between two peers'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;add;peer'= {
            cand --no-prompt 'no-prompt'
            cand --name 'name'
            cand --address 'address'
            cand --endpoint-enabled 'endpoint-enabled'
            cand --endpoint-address 'endpoint-address'
            cand --kind 'kind'
            cand --icon-enabled 'icon-enabled'
            cand --icon-src 'icon-src'
            cand --dns-enabled 'dns-enabled'
            cand --dns-addresses 'dns-addresses'
            cand --mtu-enabled 'mtu-enabled'
            cand --mtu-value 'mtu-value'
            cand --script-pre-up-enabled 'script-pre-up-enabled'
            cand --script-pre-up-line 'script-pre-up-line'
            cand --script-post-up-enabled 'script-post-up-enabled'
            cand --script-post-up-line 'script-post-up-line'
            cand --script-pre-down-enabled 'script-pre-down-enabled'
            cand --script-pre-down-line 'script-pre-down-line'
            cand --script-post-down-enabled 'script-post-down-enabled'
            cand --script-post-down-line 'script-post-down-line'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'wg-quickrs;config;add;connection'= {
            cand --no-prompt 'no-prompt'
            cand --first-peer 'first-peer'
            cand --second-peer 'second-peer'
            cand --persistent-keepalive-enabled 'persistent-keepalive-enabled'
            cand --persistent-keepalive-period 'persistent-keepalive-period'
            cand --allowed-ips-first-to-second 'allowed-ips-first-to-second'
            cand --allowed-ips-second-to-first 'allowed-ips-second-to-first'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'wg-quickrs;config;add;help'= {
            cand peer 'Add a peer to the network'
            cand connection 'Add a connection between two peers'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;add;help;peer'= {
        }
        &'wg-quickrs;config;add;help;connection'= {
        }
        &'wg-quickrs;config;add;help;help'= {
        }
        &'wg-quickrs;config;help'= {
            cand enable 'Enable a configuration option'
            cand disable 'Disable a configuration option'
            cand set 'Set a configuration value'
            cand reset 'Reset a configuration option'
            cand get 'Get a configuration value'
            cand list 'List network entities in human-readable format'
            cand remove 'Remove network entities'
            cand add 'Add network entities'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;config;help;enable'= {
            cand agent 'Enable agent configuration options'
            cand network 'Enable network configuration options'
        }
        &'wg-quickrs;config;help;enable;agent'= {
            cand web 'Enable web server options'
            cand vpn 'Enable VPN server'
            cand firewall 'Enable firewall configuration'
        }
        &'wg-quickrs;config;help;enable;agent;web'= {
            cand http 'Enable HTTP on web server'
            cand https 'Enable HTTPS on web server'
            cand password 'Enable password authentication for web server'
        }
        &'wg-quickrs;config;help;enable;agent;web;http'= {
        }
        &'wg-quickrs;config;help;enable;agent;web;https'= {
        }
        &'wg-quickrs;config;help;enable;agent;web;password'= {
        }
        &'wg-quickrs;config;help;enable;agent;vpn'= {
        }
        &'wg-quickrs;config;help;enable;agent;firewall'= {
        }
        &'wg-quickrs;config;help;enable;network'= {
            cand peer 'Enable peer options'
            cand connection 'Enable connection'
            cand defaults 'Enable default configuration options'
        }
        &'wg-quickrs;config;help;enable;network;peer'= {
            cand endpoint 'Enable peer endpoint'
            cand icon 'Enable peer icon'
            cand dns 'Enable peer DNS'
            cand mtu 'Enable peer MTU'
        }
        &'wg-quickrs;config;help;enable;network;peer;endpoint'= {
        }
        &'wg-quickrs;config;help;enable;network;peer;icon'= {
        }
        &'wg-quickrs;config;help;enable;network;peer;dns'= {
        }
        &'wg-quickrs;config;help;enable;network;peer;mtu'= {
        }
        &'wg-quickrs;config;help;enable;network;connection'= {
        }
        &'wg-quickrs;config;help;enable;network;defaults'= {
            cand peer 'Enable default peer options'
            cand connection 'Enable default connection options'
        }
        &'wg-quickrs;config;help;enable;network;defaults;peer'= {
            cand icon 'Enable default peer icon'
            cand dns 'Enable default peer DNS'
            cand mtu 'Enable default peer MTU'
        }
        &'wg-quickrs;config;help;enable;network;defaults;peer;icon'= {
        }
        &'wg-quickrs;config;help;enable;network;defaults;peer;dns'= {
        }
        &'wg-quickrs;config;help;enable;network;defaults;peer;mtu'= {
        }
        &'wg-quickrs;config;help;enable;network;defaults;connection'= {
            cand persistent-keepalive 'Enable default connection persistent keepalive'
        }
        &'wg-quickrs;config;help;enable;network;defaults;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;help;disable'= {
            cand agent 'Disable agent configuration options'
            cand network 'Disable network configuration options'
        }
        &'wg-quickrs;config;help;disable;agent'= {
            cand web 'Disable web server options'
            cand vpn 'Disable VPN server'
            cand firewall 'Disable firewall configuration'
        }
        &'wg-quickrs;config;help;disable;agent;web'= {
            cand http 'Disable HTTP on web server'
            cand https 'Disable HTTPS on web server'
            cand password 'Disable password authentication for web server'
        }
        &'wg-quickrs;config;help;disable;agent;web;http'= {
        }
        &'wg-quickrs;config;help;disable;agent;web;https'= {
        }
        &'wg-quickrs;config;help;disable;agent;web;password'= {
        }
        &'wg-quickrs;config;help;disable;agent;vpn'= {
        }
        &'wg-quickrs;config;help;disable;agent;firewall'= {
        }
        &'wg-quickrs;config;help;disable;network'= {
            cand peer 'Disable peer options'
            cand connection 'Disable connection'
            cand defaults 'Disable default configuration options'
        }
        &'wg-quickrs;config;help;disable;network;peer'= {
            cand endpoint 'Disable peer endpoint'
            cand icon 'Disable peer icon'
            cand dns 'Disable peer DNS'
            cand mtu 'Disable peer MTU'
        }
        &'wg-quickrs;config;help;disable;network;peer;endpoint'= {
        }
        &'wg-quickrs;config;help;disable;network;peer;icon'= {
        }
        &'wg-quickrs;config;help;disable;network;peer;dns'= {
        }
        &'wg-quickrs;config;help;disable;network;peer;mtu'= {
        }
        &'wg-quickrs;config;help;disable;network;connection'= {
        }
        &'wg-quickrs;config;help;disable;network;defaults'= {
            cand peer 'Disable default peer options'
            cand connection 'Disable default connection options'
        }
        &'wg-quickrs;config;help;disable;network;defaults;peer'= {
            cand icon 'Disable default peer icon'
            cand dns 'Disable default peer DNS'
            cand mtu 'Disable default peer MTU'
        }
        &'wg-quickrs;config;help;disable;network;defaults;peer;icon'= {
        }
        &'wg-quickrs;config;help;disable;network;defaults;peer;dns'= {
        }
        &'wg-quickrs;config;help;disable;network;defaults;peer;mtu'= {
        }
        &'wg-quickrs;config;help;disable;network;defaults;connection'= {
            cand persistent-keepalive 'Disable default connection persistent keepalive'
        }
        &'wg-quickrs;config;help;disable;network;defaults;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;help;set'= {
            cand agent 'Set agent configuration values'
            cand network 'Set network configuration values'
        }
        &'wg-quickrs;config;help;set;agent'= {
            cand web 'Set web server configuration'
            cand vpn 'Set VPN configuration'
            cand firewall 'Set firewall configuration'
        }
        &'wg-quickrs;config;help;set;agent;web'= {
            cand address 'Set agent web server bind IPv4 address'
            cand http 'Set HTTP configuration'
            cand https 'Set HTTPS configuration'
        }
        &'wg-quickrs;config;help;set;agent;web;address'= {
        }
        &'wg-quickrs;config;help;set;agent;web;http'= {
            cand port 'Set web server HTTP port'
        }
        &'wg-quickrs;config;help;set;agent;web;http;port'= {
        }
        &'wg-quickrs;config;help;set;agent;web;https'= {
            cand port 'Set web server HTTPS port'
            cand tls-cert 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS'
            cand tls-key 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS'
        }
        &'wg-quickrs;config;help;set;agent;web;https;port'= {
        }
        &'wg-quickrs;config;help;set;agent;web;https;tls-cert'= {
        }
        &'wg-quickrs;config;help;set;agent;web;https;tls-key'= {
        }
        &'wg-quickrs;config;help;set;agent;vpn'= {
            cand port 'Set VPN server listening port'
        }
        &'wg-quickrs;config;help;set;agent;vpn;port'= {
        }
        &'wg-quickrs;config;help;set;agent;firewall'= {
            cand utility 'Set the utility used to configure firewall NAT and input rules (e.g. iptables, pfctl, etc.)'
            cand gateway 'Set the gateway used to configure firewall NAT and input rules (e.g. en0, eth0, etc.)'
        }
        &'wg-quickrs;config;help;set;agent;firewall;utility'= {
        }
        &'wg-quickrs;config;help;set;agent;firewall;gateway'= {
        }
        &'wg-quickrs;config;help;set;network'= {
            cand name 'Set network name'
            cand subnet 'Set network subnet'
            cand peer 'Set peer configuration'
            cand connection 'Set connection configuration'
            cand defaults 'Set default configuration'
        }
        &'wg-quickrs;config;help;set;network;name'= {
        }
        &'wg-quickrs;config;help;set;network;subnet'= {
        }
        &'wg-quickrs;config;help;set;network;peer'= {
            cand name 'Set peer name'
            cand address 'Set peer address'
            cand endpoint 'Set peer endpoint address'
            cand kind 'Set peer kind'
            cand icon 'Set peer icon source'
            cand dns 'Set peer DNS addresses'
            cand mtu 'Set peer MTU value'
        }
        &'wg-quickrs;config;help;set;network;peer;name'= {
        }
        &'wg-quickrs;config;help;set;network;peer;address'= {
        }
        &'wg-quickrs;config;help;set;network;peer;endpoint'= {
        }
        &'wg-quickrs;config;help;set;network;peer;kind'= {
        }
        &'wg-quickrs;config;help;set;network;peer;icon'= {
        }
        &'wg-quickrs;config;help;set;network;peer;dns'= {
        }
        &'wg-quickrs;config;help;set;network;peer;mtu'= {
        }
        &'wg-quickrs;config;help;set;network;connection'= {
            cand allowed-ips-a-to-b 'Set allowed IPs from peer A to peer B'
            cand allowed-ips-b-to-a 'Set allowed IPs from peer B to peer A'
            cand persistent-keepalive 'Set persistent keepalive period'
        }
        &'wg-quickrs;config;help;set;network;connection;allowed-ips-a-to-b'= {
        }
        &'wg-quickrs;config;help;set;network;connection;allowed-ips-b-to-a'= {
        }
        &'wg-quickrs;config;help;set;network;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;help;set;network;defaults'= {
            cand peer 'Set default peer configuration'
            cand connection 'Set default connection configuration'
        }
        &'wg-quickrs;config;help;set;network;defaults;peer'= {
            cand kind 'Set default peer kind'
            cand icon 'Set default peer icon source'
            cand dns 'Set default peer DNS addresses'
            cand mtu 'Set default peer MTU value'
        }
        &'wg-quickrs;config;help;set;network;defaults;peer;kind'= {
        }
        &'wg-quickrs;config;help;set;network;defaults;peer;icon'= {
        }
        &'wg-quickrs;config;help;set;network;defaults;peer;dns'= {
        }
        &'wg-quickrs;config;help;set;network;defaults;peer;mtu'= {
        }
        &'wg-quickrs;config;help;set;network;defaults;connection'= {
            cand persistent-keepalive 'Set default connection persistent keepalive period'
        }
        &'wg-quickrs;config;help;set;network;defaults;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;config;help;reset'= {
            cand agent 'Reset agent configuration options'
            cand network 'Reset network configuration options'
        }
        &'wg-quickrs;config;help;reset;agent'= {
            cand web 'Reset web server configuration'
        }
        &'wg-quickrs;config;help;reset;agent;web'= {
            cand password 'Reset password for web server access'
        }
        &'wg-quickrs;config;help;reset;agent;web;password'= {
        }
        &'wg-quickrs;config;help;reset;network'= {
            cand peer 'Reset peer options'
            cand connection 'Reset connection options'
        }
        &'wg-quickrs;config;help;reset;network;peer'= {
            cand private-key 'Reset peer private key (generates new WireGuard key)'
        }
        &'wg-quickrs;config;help;reset;network;peer;private-key'= {
        }
        &'wg-quickrs;config;help;reset;network;connection'= {
            cand pre-shared-key 'Reset connection pre-shared key (generates new WireGuard key)'
        }
        &'wg-quickrs;config;help;reset;network;connection;pre-shared-key'= {
        }
        &'wg-quickrs;config;help;get'= {
            cand agent 'Get agent configuration values'
            cand network 'Get network configuration values'
        }
        &'wg-quickrs;config;help;get;agent'= {
            cand web 'Get web server configuration'
            cand vpn 'Get VPN configuration'
            cand firewall 'Get firewall configuration'
        }
        &'wg-quickrs;config;help;get;agent;web'= {
            cand address 'Get agent web server bind IPv4 address'
            cand http 'Get HTTP configuration'
            cand https 'Get HTTPS configuration'
            cand password 'Get password authentication configuration'
        }
        &'wg-quickrs;config;help;get;agent;web;address'= {
        }
        &'wg-quickrs;config;help;get;agent;web;http'= {
            cand enabled 'Get whether HTTP is enabled'
            cand port 'Get web server HTTP port'
        }
        &'wg-quickrs;config;help;get;agent;web;http;enabled'= {
        }
        &'wg-quickrs;config;help;get;agent;web;http;port'= {
        }
        &'wg-quickrs;config;help;get;agent;web;https'= {
            cand enabled 'Get whether HTTPS is enabled'
            cand port 'Get web server HTTPS port'
            cand tls-cert 'Get path to TLS certificate file for HTTPS'
            cand tls-key 'Get path to TLS private key file for HTTPS'
        }
        &'wg-quickrs;config;help;get;agent;web;https;enabled'= {
        }
        &'wg-quickrs;config;help;get;agent;web;https;port'= {
        }
        &'wg-quickrs;config;help;get;agent;web;https;tls-cert'= {
        }
        &'wg-quickrs;config;help;get;agent;web;https;tls-key'= {
        }
        &'wg-quickrs;config;help;get;agent;web;password'= {
            cand enabled 'Get whether password authentication is enabled'
            cand hash 'Get password hash'
        }
        &'wg-quickrs;config;help;get;agent;web;password;enabled'= {
        }
        &'wg-quickrs;config;help;get;agent;web;password;hash'= {
        }
        &'wg-quickrs;config;help;get;agent;vpn'= {
            cand enabled 'Get whether VPN server is enabled'
            cand port 'Get VPN server listening port'
        }
        &'wg-quickrs;config;help;get;agent;vpn;enabled'= {
        }
        &'wg-quickrs;config;help;get;agent;vpn;port'= {
        }
        &'wg-quickrs;config;help;get;agent;firewall'= {
            cand enabled 'Get whether firewall configuration is enabled'
            cand utility 'Get the utility used to configure firewall NAT and input rules'
            cand gateway 'Get the gateway used to configure firewall NAT and input rules'
        }
        &'wg-quickrs;config;help;get;agent;firewall;enabled'= {
        }
        &'wg-quickrs;config;help;get;agent;firewall;utility'= {
        }
        &'wg-quickrs;config;help;get;agent;firewall;gateway'= {
        }
        &'wg-quickrs;config;help;get;network'= {
            cand name 'Get network name'
            cand subnet 'Get network subnet'
            cand this-peer 'Get this peer''s UUID'
            cand peers 'Get network peers'
            cand connections 'Get network connections'
            cand defaults 'Get network defaults'
            cand reservations 'Get network reservations'
            cand updated-at 'Get network last updated timestamp'
        }
        &'wg-quickrs;config;help;get;network;name'= {
        }
        &'wg-quickrs;config;help;get;network;subnet'= {
        }
        &'wg-quickrs;config;help;get;network;this-peer'= {
        }
        &'wg-quickrs;config;help;get;network;peers'= {
            cand name 'Get peer name'
            cand address 'Get peer IP address'
            cand endpoint 'Get peer endpoint'
            cand kind 'Get peer kind'
            cand icon 'Get peer icon'
            cand dns 'Get peer DNS'
            cand mtu 'Get peer MTU'
            cand scripts 'Get peer scripts'
            cand private-key 'Get peer private key'
            cand created-at 'Get peer creation timestamp'
            cand updated-at 'Get peer last updated timestamp'
        }
        &'wg-quickrs;config;help;get;network;peers;name'= {
        }
        &'wg-quickrs;config;help;get;network;peers;address'= {
        }
        &'wg-quickrs;config;help;get;network;peers;endpoint'= {
            cand enabled 'Get whether endpoint is enabled'
            cand address 'Get endpoint address'
        }
        &'wg-quickrs;config;help;get;network;peers;endpoint;enabled'= {
        }
        &'wg-quickrs;config;help;get;network;peers;endpoint;address'= {
        }
        &'wg-quickrs;config;help;get;network;peers;kind'= {
        }
        &'wg-quickrs;config;help;get;network;peers;icon'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
        }
        &'wg-quickrs;config;help;get;network;peers;icon;enabled'= {
        }
        &'wg-quickrs;config;help;get;network;peers;icon;src'= {
        }
        &'wg-quickrs;config;help;get;network;peers;dns'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
        }
        &'wg-quickrs;config;help;get;network;peers;dns;enabled'= {
        }
        &'wg-quickrs;config;help;get;network;peers;dns;addresses'= {
        }
        &'wg-quickrs;config;help;get;network;peers;mtu'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
        }
        &'wg-quickrs;config;help;get;network;peers;mtu;enabled'= {
        }
        &'wg-quickrs;config;help;get;network;peers;mtu;value'= {
        }
        &'wg-quickrs;config;help;get;network;peers;scripts'= {
        }
        &'wg-quickrs;config;help;get;network;peers;private-key'= {
        }
        &'wg-quickrs;config;help;get;network;peers;created-at'= {
        }
        &'wg-quickrs;config;help;get;network;peers;updated-at'= {
        }
        &'wg-quickrs;config;help;get;network;connections'= {
            cand enabled 'Get whether connection is enabled'
            cand pre-shared-key 'Get connection pre-shared key'
            cand persistent-keepalive 'Get connection persistent keepalive'
            cand allowed-ips-a-to-b 'Get allowed IPs from A to B'
            cand allowed-ips-b-to-a 'Get allowed IPs from B to A'
        }
        &'wg-quickrs;config;help;get;network;connections;enabled'= {
        }
        &'wg-quickrs;config;help;get;network;connections;pre-shared-key'= {
        }
        &'wg-quickrs;config;help;get;network;connections;persistent-keepalive'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
        }
        &'wg-quickrs;config;help;get;network;connections;persistent-keepalive;enabled'= {
        }
        &'wg-quickrs;config;help;get;network;connections;persistent-keepalive;period'= {
        }
        &'wg-quickrs;config;help;get;network;connections;allowed-ips-a-to-b'= {
        }
        &'wg-quickrs;config;help;get;network;connections;allowed-ips-b-to-a'= {
        }
        &'wg-quickrs;config;help;get;network;defaults'= {
            cand peer 'Get default peer configuration'
            cand connection 'Get default connection configuration'
        }
        &'wg-quickrs;config;help;get;network;defaults;peer'= {
            cand kind 'Get default peer kind'
            cand icon 'Get default peer icon'
            cand dns 'Get default peer DNS'
            cand mtu 'Get default peer MTU'
            cand scripts 'Get default peer scripts'
        }
        &'wg-quickrs;config;help;get;network;defaults;peer;kind'= {
        }
        &'wg-quickrs;config;help;get;network;defaults;peer;icon'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
        }
        &'wg-quickrs;config;help;get;network;defaults;peer;icon;enabled'= {
        }
        &'wg-quickrs;config;help;get;network;defaults;peer;icon;src'= {
        }
        &'wg-quickrs;config;help;get;network;defaults;peer;dns'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
        }
        &'wg-quickrs;config;help;get;network;defaults;peer;dns;enabled'= {
        }
        &'wg-quickrs;config;help;get;network;defaults;peer;dns;addresses'= {
        }
        &'wg-quickrs;config;help;get;network;defaults;peer;mtu'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
        }
        &'wg-quickrs;config;help;get;network;defaults;peer;mtu;enabled'= {
        }
        &'wg-quickrs;config;help;get;network;defaults;peer;mtu;value'= {
        }
        &'wg-quickrs;config;help;get;network;defaults;peer;scripts'= {
        }
        &'wg-quickrs;config;help;get;network;defaults;connection'= {
            cand persistent-keepalive 'Get default connection persistent keepalive'
        }
        &'wg-quickrs;config;help;get;network;defaults;connection;persistent-keepalive'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
        }
        &'wg-quickrs;config;help;get;network;defaults;connection;persistent-keepalive;enabled'= {
        }
        &'wg-quickrs;config;help;get;network;defaults;connection;persistent-keepalive;period'= {
        }
        &'wg-quickrs;config;help;get;network;reservations'= {
            cand peer-id 'Get reservation peer ID'
            cand valid-until 'Get reservation validity timestamp'
        }
        &'wg-quickrs;config;help;get;network;reservations;peer-id'= {
        }
        &'wg-quickrs;config;help;get;network;reservations;valid-until'= {
        }
        &'wg-quickrs;config;help;get;network;updated-at'= {
        }
        &'wg-quickrs;config;help;list'= {
            cand peers 'List all peers in human-readable format'
            cand connections 'List all connections in human-readable format'
            cand reservations 'List all reservations in human-readable format'
        }
        &'wg-quickrs;config;help;list;peers'= {
        }
        &'wg-quickrs;config;help;list;connections'= {
        }
        &'wg-quickrs;config;help;list;reservations'= {
        }
        &'wg-quickrs;config;help;remove'= {
            cand peer 'Remove a peer by UUID'
            cand connection 'Remove a connection by connection ID'
            cand reservation 'Remove a reservation by IPv4 address'
        }
        &'wg-quickrs;config;help;remove;peer'= {
        }
        &'wg-quickrs;config;help;remove;connection'= {
        }
        &'wg-quickrs;config;help;remove;reservation'= {
        }
        &'wg-quickrs;config;help;add'= {
            cand peer 'Add a peer to the network'
            cand connection 'Add a connection between two peers'
        }
        &'wg-quickrs;config;help;add;peer'= {
        }
        &'wg-quickrs;config;help;add;connection'= {
        }
        &'wg-quickrs;config;help;help'= {
        }
        &'wg-quickrs;help'= {
            cand agent 'Run agent commands'
            cand config 'Edit agent configuration options'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'wg-quickrs;help;agent'= {
            cand init 'Initialize the wg-quickrs agent. Configuration options can be filled either by prompts on screen (when no argument is provided) or specified as arguments to this command'
            cand run 'Run the wg-quickrs agent'
        }
        &'wg-quickrs;help;agent;init'= {
        }
        &'wg-quickrs;help;agent;run'= {
        }
        &'wg-quickrs;help;config'= {
            cand enable 'Enable a configuration option'
            cand disable 'Disable a configuration option'
            cand set 'Set a configuration value'
            cand reset 'Reset a configuration option'
            cand get 'Get a configuration value'
            cand list 'List network entities in human-readable format'
            cand remove 'Remove network entities'
            cand add 'Add network entities'
        }
        &'wg-quickrs;help;config;enable'= {
            cand agent 'Enable agent configuration options'
            cand network 'Enable network configuration options'
        }
        &'wg-quickrs;help;config;enable;agent'= {
            cand web 'Enable web server options'
            cand vpn 'Enable VPN server'
            cand firewall 'Enable firewall configuration'
        }
        &'wg-quickrs;help;config;enable;agent;web'= {
            cand http 'Enable HTTP on web server'
            cand https 'Enable HTTPS on web server'
            cand password 'Enable password authentication for web server'
        }
        &'wg-quickrs;help;config;enable;agent;web;http'= {
        }
        &'wg-quickrs;help;config;enable;agent;web;https'= {
        }
        &'wg-quickrs;help;config;enable;agent;web;password'= {
        }
        &'wg-quickrs;help;config;enable;agent;vpn'= {
        }
        &'wg-quickrs;help;config;enable;agent;firewall'= {
        }
        &'wg-quickrs;help;config;enable;network'= {
            cand peer 'Enable peer options'
            cand connection 'Enable connection'
            cand defaults 'Enable default configuration options'
        }
        &'wg-quickrs;help;config;enable;network;peer'= {
            cand endpoint 'Enable peer endpoint'
            cand icon 'Enable peer icon'
            cand dns 'Enable peer DNS'
            cand mtu 'Enable peer MTU'
        }
        &'wg-quickrs;help;config;enable;network;peer;endpoint'= {
        }
        &'wg-quickrs;help;config;enable;network;peer;icon'= {
        }
        &'wg-quickrs;help;config;enable;network;peer;dns'= {
        }
        &'wg-quickrs;help;config;enable;network;peer;mtu'= {
        }
        &'wg-quickrs;help;config;enable;network;connection'= {
        }
        &'wg-quickrs;help;config;enable;network;defaults'= {
            cand peer 'Enable default peer options'
            cand connection 'Enable default connection options'
        }
        &'wg-quickrs;help;config;enable;network;defaults;peer'= {
            cand icon 'Enable default peer icon'
            cand dns 'Enable default peer DNS'
            cand mtu 'Enable default peer MTU'
        }
        &'wg-quickrs;help;config;enable;network;defaults;peer;icon'= {
        }
        &'wg-quickrs;help;config;enable;network;defaults;peer;dns'= {
        }
        &'wg-quickrs;help;config;enable;network;defaults;peer;mtu'= {
        }
        &'wg-quickrs;help;config;enable;network;defaults;connection'= {
            cand persistent-keepalive 'Enable default connection persistent keepalive'
        }
        &'wg-quickrs;help;config;enable;network;defaults;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;help;config;disable'= {
            cand agent 'Disable agent configuration options'
            cand network 'Disable network configuration options'
        }
        &'wg-quickrs;help;config;disable;agent'= {
            cand web 'Disable web server options'
            cand vpn 'Disable VPN server'
            cand firewall 'Disable firewall configuration'
        }
        &'wg-quickrs;help;config;disable;agent;web'= {
            cand http 'Disable HTTP on web server'
            cand https 'Disable HTTPS on web server'
            cand password 'Disable password authentication for web server'
        }
        &'wg-quickrs;help;config;disable;agent;web;http'= {
        }
        &'wg-quickrs;help;config;disable;agent;web;https'= {
        }
        &'wg-quickrs;help;config;disable;agent;web;password'= {
        }
        &'wg-quickrs;help;config;disable;agent;vpn'= {
        }
        &'wg-quickrs;help;config;disable;agent;firewall'= {
        }
        &'wg-quickrs;help;config;disable;network'= {
            cand peer 'Disable peer options'
            cand connection 'Disable connection'
            cand defaults 'Disable default configuration options'
        }
        &'wg-quickrs;help;config;disable;network;peer'= {
            cand endpoint 'Disable peer endpoint'
            cand icon 'Disable peer icon'
            cand dns 'Disable peer DNS'
            cand mtu 'Disable peer MTU'
        }
        &'wg-quickrs;help;config;disable;network;peer;endpoint'= {
        }
        &'wg-quickrs;help;config;disable;network;peer;icon'= {
        }
        &'wg-quickrs;help;config;disable;network;peer;dns'= {
        }
        &'wg-quickrs;help;config;disable;network;peer;mtu'= {
        }
        &'wg-quickrs;help;config;disable;network;connection'= {
        }
        &'wg-quickrs;help;config;disable;network;defaults'= {
            cand peer 'Disable default peer options'
            cand connection 'Disable default connection options'
        }
        &'wg-quickrs;help;config;disable;network;defaults;peer'= {
            cand icon 'Disable default peer icon'
            cand dns 'Disable default peer DNS'
            cand mtu 'Disable default peer MTU'
        }
        &'wg-quickrs;help;config;disable;network;defaults;peer;icon'= {
        }
        &'wg-quickrs;help;config;disable;network;defaults;peer;dns'= {
        }
        &'wg-quickrs;help;config;disable;network;defaults;peer;mtu'= {
        }
        &'wg-quickrs;help;config;disable;network;defaults;connection'= {
            cand persistent-keepalive 'Disable default connection persistent keepalive'
        }
        &'wg-quickrs;help;config;disable;network;defaults;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;help;config;set'= {
            cand agent 'Set agent configuration values'
            cand network 'Set network configuration values'
        }
        &'wg-quickrs;help;config;set;agent'= {
            cand web 'Set web server configuration'
            cand vpn 'Set VPN configuration'
            cand firewall 'Set firewall configuration'
        }
        &'wg-quickrs;help;config;set;agent;web'= {
            cand address 'Set agent web server bind IPv4 address'
            cand http 'Set HTTP configuration'
            cand https 'Set HTTPS configuration'
        }
        &'wg-quickrs;help;config;set;agent;web;address'= {
        }
        &'wg-quickrs;help;config;set;agent;web;http'= {
            cand port 'Set web server HTTP port'
        }
        &'wg-quickrs;help;config;set;agent;web;http;port'= {
        }
        &'wg-quickrs;help;config;set;agent;web;https'= {
            cand port 'Set web server HTTPS port'
            cand tls-cert 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS'
            cand tls-key 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS'
        }
        &'wg-quickrs;help;config;set;agent;web;https;port'= {
        }
        &'wg-quickrs;help;config;set;agent;web;https;tls-cert'= {
        }
        &'wg-quickrs;help;config;set;agent;web;https;tls-key'= {
        }
        &'wg-quickrs;help;config;set;agent;vpn'= {
            cand port 'Set VPN server listening port'
        }
        &'wg-quickrs;help;config;set;agent;vpn;port'= {
        }
        &'wg-quickrs;help;config;set;agent;firewall'= {
            cand utility 'Set the utility used to configure firewall NAT and input rules (e.g. iptables, pfctl, etc.)'
            cand gateway 'Set the gateway used to configure firewall NAT and input rules (e.g. en0, eth0, etc.)'
        }
        &'wg-quickrs;help;config;set;agent;firewall;utility'= {
        }
        &'wg-quickrs;help;config;set;agent;firewall;gateway'= {
        }
        &'wg-quickrs;help;config;set;network'= {
            cand name 'Set network name'
            cand subnet 'Set network subnet'
            cand peer 'Set peer configuration'
            cand connection 'Set connection configuration'
            cand defaults 'Set default configuration'
        }
        &'wg-quickrs;help;config;set;network;name'= {
        }
        &'wg-quickrs;help;config;set;network;subnet'= {
        }
        &'wg-quickrs;help;config;set;network;peer'= {
            cand name 'Set peer name'
            cand address 'Set peer address'
            cand endpoint 'Set peer endpoint address'
            cand kind 'Set peer kind'
            cand icon 'Set peer icon source'
            cand dns 'Set peer DNS addresses'
            cand mtu 'Set peer MTU value'
        }
        &'wg-quickrs;help;config;set;network;peer;name'= {
        }
        &'wg-quickrs;help;config;set;network;peer;address'= {
        }
        &'wg-quickrs;help;config;set;network;peer;endpoint'= {
        }
        &'wg-quickrs;help;config;set;network;peer;kind'= {
        }
        &'wg-quickrs;help;config;set;network;peer;icon'= {
        }
        &'wg-quickrs;help;config;set;network;peer;dns'= {
        }
        &'wg-quickrs;help;config;set;network;peer;mtu'= {
        }
        &'wg-quickrs;help;config;set;network;connection'= {
            cand allowed-ips-a-to-b 'Set allowed IPs from peer A to peer B'
            cand allowed-ips-b-to-a 'Set allowed IPs from peer B to peer A'
            cand persistent-keepalive 'Set persistent keepalive period'
        }
        &'wg-quickrs;help;config;set;network;connection;allowed-ips-a-to-b'= {
        }
        &'wg-quickrs;help;config;set;network;connection;allowed-ips-b-to-a'= {
        }
        &'wg-quickrs;help;config;set;network;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;help;config;set;network;defaults'= {
            cand peer 'Set default peer configuration'
            cand connection 'Set default connection configuration'
        }
        &'wg-quickrs;help;config;set;network;defaults;peer'= {
            cand kind 'Set default peer kind'
            cand icon 'Set default peer icon source'
            cand dns 'Set default peer DNS addresses'
            cand mtu 'Set default peer MTU value'
        }
        &'wg-quickrs;help;config;set;network;defaults;peer;kind'= {
        }
        &'wg-quickrs;help;config;set;network;defaults;peer;icon'= {
        }
        &'wg-quickrs;help;config;set;network;defaults;peer;dns'= {
        }
        &'wg-quickrs;help;config;set;network;defaults;peer;mtu'= {
        }
        &'wg-quickrs;help;config;set;network;defaults;connection'= {
            cand persistent-keepalive 'Set default connection persistent keepalive period'
        }
        &'wg-quickrs;help;config;set;network;defaults;connection;persistent-keepalive'= {
        }
        &'wg-quickrs;help;config;reset'= {
            cand agent 'Reset agent configuration options'
            cand network 'Reset network configuration options'
        }
        &'wg-quickrs;help;config;reset;agent'= {
            cand web 'Reset web server configuration'
        }
        &'wg-quickrs;help;config;reset;agent;web'= {
            cand password 'Reset password for web server access'
        }
        &'wg-quickrs;help;config;reset;agent;web;password'= {
        }
        &'wg-quickrs;help;config;reset;network'= {
            cand peer 'Reset peer options'
            cand connection 'Reset connection options'
        }
        &'wg-quickrs;help;config;reset;network;peer'= {
            cand private-key 'Reset peer private key (generates new WireGuard key)'
        }
        &'wg-quickrs;help;config;reset;network;peer;private-key'= {
        }
        &'wg-quickrs;help;config;reset;network;connection'= {
            cand pre-shared-key 'Reset connection pre-shared key (generates new WireGuard key)'
        }
        &'wg-quickrs;help;config;reset;network;connection;pre-shared-key'= {
        }
        &'wg-quickrs;help;config;get'= {
            cand agent 'Get agent configuration values'
            cand network 'Get network configuration values'
        }
        &'wg-quickrs;help;config;get;agent'= {
            cand web 'Get web server configuration'
            cand vpn 'Get VPN configuration'
            cand firewall 'Get firewall configuration'
        }
        &'wg-quickrs;help;config;get;agent;web'= {
            cand address 'Get agent web server bind IPv4 address'
            cand http 'Get HTTP configuration'
            cand https 'Get HTTPS configuration'
            cand password 'Get password authentication configuration'
        }
        &'wg-quickrs;help;config;get;agent;web;address'= {
        }
        &'wg-quickrs;help;config;get;agent;web;http'= {
            cand enabled 'Get whether HTTP is enabled'
            cand port 'Get web server HTTP port'
        }
        &'wg-quickrs;help;config;get;agent;web;http;enabled'= {
        }
        &'wg-quickrs;help;config;get;agent;web;http;port'= {
        }
        &'wg-quickrs;help;config;get;agent;web;https'= {
            cand enabled 'Get whether HTTPS is enabled'
            cand port 'Get web server HTTPS port'
            cand tls-cert 'Get path to TLS certificate file for HTTPS'
            cand tls-key 'Get path to TLS private key file for HTTPS'
        }
        &'wg-quickrs;help;config;get;agent;web;https;enabled'= {
        }
        &'wg-quickrs;help;config;get;agent;web;https;port'= {
        }
        &'wg-quickrs;help;config;get;agent;web;https;tls-cert'= {
        }
        &'wg-quickrs;help;config;get;agent;web;https;tls-key'= {
        }
        &'wg-quickrs;help;config;get;agent;web;password'= {
            cand enabled 'Get whether password authentication is enabled'
            cand hash 'Get password hash'
        }
        &'wg-quickrs;help;config;get;agent;web;password;enabled'= {
        }
        &'wg-quickrs;help;config;get;agent;web;password;hash'= {
        }
        &'wg-quickrs;help;config;get;agent;vpn'= {
            cand enabled 'Get whether VPN server is enabled'
            cand port 'Get VPN server listening port'
        }
        &'wg-quickrs;help;config;get;agent;vpn;enabled'= {
        }
        &'wg-quickrs;help;config;get;agent;vpn;port'= {
        }
        &'wg-quickrs;help;config;get;agent;firewall'= {
            cand enabled 'Get whether firewall configuration is enabled'
            cand utility 'Get the utility used to configure firewall NAT and input rules'
            cand gateway 'Get the gateway used to configure firewall NAT and input rules'
        }
        &'wg-quickrs;help;config;get;agent;firewall;enabled'= {
        }
        &'wg-quickrs;help;config;get;agent;firewall;utility'= {
        }
        &'wg-quickrs;help;config;get;agent;firewall;gateway'= {
        }
        &'wg-quickrs;help;config;get;network'= {
            cand name 'Get network name'
            cand subnet 'Get network subnet'
            cand this-peer 'Get this peer''s UUID'
            cand peers 'Get network peers'
            cand connections 'Get network connections'
            cand defaults 'Get network defaults'
            cand reservations 'Get network reservations'
            cand updated-at 'Get network last updated timestamp'
        }
        &'wg-quickrs;help;config;get;network;name'= {
        }
        &'wg-quickrs;help;config;get;network;subnet'= {
        }
        &'wg-quickrs;help;config;get;network;this-peer'= {
        }
        &'wg-quickrs;help;config;get;network;peers'= {
            cand name 'Get peer name'
            cand address 'Get peer IP address'
            cand endpoint 'Get peer endpoint'
            cand kind 'Get peer kind'
            cand icon 'Get peer icon'
            cand dns 'Get peer DNS'
            cand mtu 'Get peer MTU'
            cand scripts 'Get peer scripts'
            cand private-key 'Get peer private key'
            cand created-at 'Get peer creation timestamp'
            cand updated-at 'Get peer last updated timestamp'
        }
        &'wg-quickrs;help;config;get;network;peers;name'= {
        }
        &'wg-quickrs;help;config;get;network;peers;address'= {
        }
        &'wg-quickrs;help;config;get;network;peers;endpoint'= {
            cand enabled 'Get whether endpoint is enabled'
            cand address 'Get endpoint address'
        }
        &'wg-quickrs;help;config;get;network;peers;endpoint;enabled'= {
        }
        &'wg-quickrs;help;config;get;network;peers;endpoint;address'= {
        }
        &'wg-quickrs;help;config;get;network;peers;kind'= {
        }
        &'wg-quickrs;help;config;get;network;peers;icon'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
        }
        &'wg-quickrs;help;config;get;network;peers;icon;enabled'= {
        }
        &'wg-quickrs;help;config;get;network;peers;icon;src'= {
        }
        &'wg-quickrs;help;config;get;network;peers;dns'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
        }
        &'wg-quickrs;help;config;get;network;peers;dns;enabled'= {
        }
        &'wg-quickrs;help;config;get;network;peers;dns;addresses'= {
        }
        &'wg-quickrs;help;config;get;network;peers;mtu'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
        }
        &'wg-quickrs;help;config;get;network;peers;mtu;enabled'= {
        }
        &'wg-quickrs;help;config;get;network;peers;mtu;value'= {
        }
        &'wg-quickrs;help;config;get;network;peers;scripts'= {
        }
        &'wg-quickrs;help;config;get;network;peers;private-key'= {
        }
        &'wg-quickrs;help;config;get;network;peers;created-at'= {
        }
        &'wg-quickrs;help;config;get;network;peers;updated-at'= {
        }
        &'wg-quickrs;help;config;get;network;connections'= {
            cand enabled 'Get whether connection is enabled'
            cand pre-shared-key 'Get connection pre-shared key'
            cand persistent-keepalive 'Get connection persistent keepalive'
            cand allowed-ips-a-to-b 'Get allowed IPs from A to B'
            cand allowed-ips-b-to-a 'Get allowed IPs from B to A'
        }
        &'wg-quickrs;help;config;get;network;connections;enabled'= {
        }
        &'wg-quickrs;help;config;get;network;connections;pre-shared-key'= {
        }
        &'wg-quickrs;help;config;get;network;connections;persistent-keepalive'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
        }
        &'wg-quickrs;help;config;get;network;connections;persistent-keepalive;enabled'= {
        }
        &'wg-quickrs;help;config;get;network;connections;persistent-keepalive;period'= {
        }
        &'wg-quickrs;help;config;get;network;connections;allowed-ips-a-to-b'= {
        }
        &'wg-quickrs;help;config;get;network;connections;allowed-ips-b-to-a'= {
        }
        &'wg-quickrs;help;config;get;network;defaults'= {
            cand peer 'Get default peer configuration'
            cand connection 'Get default connection configuration'
        }
        &'wg-quickrs;help;config;get;network;defaults;peer'= {
            cand kind 'Get default peer kind'
            cand icon 'Get default peer icon'
            cand dns 'Get default peer DNS'
            cand mtu 'Get default peer MTU'
            cand scripts 'Get default peer scripts'
        }
        &'wg-quickrs;help;config;get;network;defaults;peer;kind'= {
        }
        &'wg-quickrs;help;config;get;network;defaults;peer;icon'= {
            cand enabled 'Get whether icon is enabled'
            cand src 'Get icon source'
        }
        &'wg-quickrs;help;config;get;network;defaults;peer;icon;enabled'= {
        }
        &'wg-quickrs;help;config;get;network;defaults;peer;icon;src'= {
        }
        &'wg-quickrs;help;config;get;network;defaults;peer;dns'= {
            cand enabled 'Get whether DNS is enabled'
            cand addresses 'Get DNS addresses'
        }
        &'wg-quickrs;help;config;get;network;defaults;peer;dns;enabled'= {
        }
        &'wg-quickrs;help;config;get;network;defaults;peer;dns;addresses'= {
        }
        &'wg-quickrs;help;config;get;network;defaults;peer;mtu'= {
            cand enabled 'Get whether MTU is enabled'
            cand value 'Get MTU value'
        }
        &'wg-quickrs;help;config;get;network;defaults;peer;mtu;enabled'= {
        }
        &'wg-quickrs;help;config;get;network;defaults;peer;mtu;value'= {
        }
        &'wg-quickrs;help;config;get;network;defaults;peer;scripts'= {
        }
        &'wg-quickrs;help;config;get;network;defaults;connection'= {
            cand persistent-keepalive 'Get default connection persistent keepalive'
        }
        &'wg-quickrs;help;config;get;network;defaults;connection;persistent-keepalive'= {
            cand enabled 'Get whether persistent keepalive is enabled'
            cand period 'Get persistent keepalive period'
        }
        &'wg-quickrs;help;config;get;network;defaults;connection;persistent-keepalive;enabled'= {
        }
        &'wg-quickrs;help;config;get;network;defaults;connection;persistent-keepalive;period'= {
        }
        &'wg-quickrs;help;config;get;network;reservations'= {
            cand peer-id 'Get reservation peer ID'
            cand valid-until 'Get reservation validity timestamp'
        }
        &'wg-quickrs;help;config;get;network;reservations;peer-id'= {
        }
        &'wg-quickrs;help;config;get;network;reservations;valid-until'= {
        }
        &'wg-quickrs;help;config;get;network;updated-at'= {
        }
        &'wg-quickrs;help;config;list'= {
            cand peers 'List all peers in human-readable format'
            cand connections 'List all connections in human-readable format'
            cand reservations 'List all reservations in human-readable format'
        }
        &'wg-quickrs;help;config;list;peers'= {
        }
        &'wg-quickrs;help;config;list;connections'= {
        }
        &'wg-quickrs;help;config;list;reservations'= {
        }
        &'wg-quickrs;help;config;remove'= {
            cand peer 'Remove a peer by UUID'
            cand connection 'Remove a connection by connection ID'
            cand reservation 'Remove a reservation by IPv4 address'
        }
        &'wg-quickrs;help;config;remove;peer'= {
        }
        &'wg-quickrs;help;config;remove;connection'= {
        }
        &'wg-quickrs;help;config;remove;reservation'= {
        }
        &'wg-quickrs;help;config;add'= {
            cand peer 'Add a peer to the network'
            cand connection 'Add a connection between two peers'
        }
        &'wg-quickrs;help;config;add;peer'= {
        }
        &'wg-quickrs;help;config;add;connection'= {
        }
        &'wg-quickrs;help;help'= {
        }
    ]
    $completions[$command]
}
