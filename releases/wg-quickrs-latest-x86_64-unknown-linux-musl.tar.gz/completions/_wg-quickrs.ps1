
using namespace System.Management.Automation
using namespace System.Management.Automation.Language

Register-ArgumentCompleter -Native -CommandName 'wg-quickrs' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $commandElements = $commandAst.CommandElements
    $command = @(
        'wg-quickrs'
        for ($i = 1; $i -lt $commandElements.Count; $i++) {
            $element = $commandElements[$i]
            if ($element -isnot [StringConstantExpressionAst] -or
                $element.StringConstantType -ne [StringConstantType]::BareWord -or
                $element.Value.StartsWith('-') -or
                $element.Value -eq $wordToComplete) {
                break
        }
        $element.Value
    }) -join ';'

    $completions = @(switch ($command) {
        'wg-quickrs' {
            [CompletionResult]::new('--wg-quickrs-config-folder', '--wg-quickrs-config-folder', [CompletionResultType]::ParameterName, 'wg-quickrs-config-folder')
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Increase verbosity level from Info to Debug')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Increase verbosity level from Info to Debug')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Run agent commands')
            [CompletionResult]::new('config', 'config', [CompletionResultType]::ParameterValue, 'Edit agent configuration options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;agent' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('init', 'init', [CompletionResultType]::ParameterValue, 'Initialize the wg-quickrs agent. Configuration options can be filled either by prompts on screen (when no argument is provided) or specified as arguments to this command')
            [CompletionResult]::new('run', 'run', [CompletionResultType]::ParameterValue, 'Run the wg-quickrs agent')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;agent;init' {
            [CompletionResult]::new('--network-name', '--network-name', [CompletionResultType]::ParameterName, 'network-name')
            [CompletionResult]::new('--network-subnet', '--network-subnet', [CompletionResultType]::ParameterName, 'network-subnet')
            [CompletionResult]::new('--agent-web-address', '--agent-web-address', [CompletionResultType]::ParameterName, 'agent-web-address')
            [CompletionResult]::new('--agent-web-http-enabled', '--agent-web-http-enabled', [CompletionResultType]::ParameterName, 'agent-web-http-enabled')
            [CompletionResult]::new('--agent-web-http-port', '--agent-web-http-port', [CompletionResultType]::ParameterName, 'agent-web-http-port')
            [CompletionResult]::new('--agent-web-https-enabled', '--agent-web-https-enabled', [CompletionResultType]::ParameterName, 'agent-web-https-enabled')
            [CompletionResult]::new('--agent-web-https-port', '--agent-web-https-port', [CompletionResultType]::ParameterName, 'agent-web-https-port')
            [CompletionResult]::new('--agent-web-https-tls-cert', '--agent-web-https-tls-cert', [CompletionResultType]::ParameterName, 'agent-web-https-tls-cert')
            [CompletionResult]::new('--agent-web-https-tls-key', '--agent-web-https-tls-key', [CompletionResultType]::ParameterName, 'agent-web-https-tls-key')
            [CompletionResult]::new('--agent-web-password-enabled', '--agent-web-password-enabled', [CompletionResultType]::ParameterName, 'agent-web-password-enabled')
            [CompletionResult]::new('--agent-web-password', '--agent-web-password', [CompletionResultType]::ParameterName, 'agent-web-password')
            [CompletionResult]::new('--agent-vpn-enabled', '--agent-vpn-enabled', [CompletionResultType]::ParameterName, 'agent-vpn-enabled')
            [CompletionResult]::new('--agent-vpn-port', '--agent-vpn-port', [CompletionResultType]::ParameterName, 'agent-vpn-port')
            [CompletionResult]::new('--agent-firewall-enabled', '--agent-firewall-enabled', [CompletionResultType]::ParameterName, 'agent-firewall-enabled')
            [CompletionResult]::new('--agent-firewall-utility', '--agent-firewall-utility', [CompletionResultType]::ParameterName, 'agent-firewall-utility')
            [CompletionResult]::new('--agent-firewall-gateway', '--agent-firewall-gateway', [CompletionResultType]::ParameterName, 'agent-firewall-gateway')
            [CompletionResult]::new('--agent-peer-name', '--agent-peer-name', [CompletionResultType]::ParameterName, 'agent-peer-name')
            [CompletionResult]::new('--agent-peer-vpn-internal-address', '--agent-peer-vpn-internal-address', [CompletionResultType]::ParameterName, 'agent-peer-vpn-internal-address')
            [CompletionResult]::new('--agent-peer-vpn-endpoint', '--agent-peer-vpn-endpoint', [CompletionResultType]::ParameterName, 'agent-peer-vpn-endpoint')
            [CompletionResult]::new('--agent-peer-kind', '--agent-peer-kind', [CompletionResultType]::ParameterName, 'agent-peer-kind')
            [CompletionResult]::new('--agent-peer-icon-enabled', '--agent-peer-icon-enabled', [CompletionResultType]::ParameterName, 'agent-peer-icon-enabled')
            [CompletionResult]::new('--agent-peer-icon-src', '--agent-peer-icon-src', [CompletionResultType]::ParameterName, 'agent-peer-icon-src')
            [CompletionResult]::new('--agent-peer-dns-enabled', '--agent-peer-dns-enabled', [CompletionResultType]::ParameterName, 'agent-peer-dns-enabled')
            [CompletionResult]::new('--agent-peer-dns-addresses', '--agent-peer-dns-addresses', [CompletionResultType]::ParameterName, 'agent-peer-dns-addresses')
            [CompletionResult]::new('--agent-peer-mtu-enabled', '--agent-peer-mtu-enabled', [CompletionResultType]::ParameterName, 'agent-peer-mtu-enabled')
            [CompletionResult]::new('--agent-peer-mtu-value', '--agent-peer-mtu-value', [CompletionResultType]::ParameterName, 'agent-peer-mtu-value')
            [CompletionResult]::new('--agent-peer-script-pre-up-enabled', '--agent-peer-script-pre-up-enabled', [CompletionResultType]::ParameterName, 'agent-peer-script-pre-up-enabled')
            [CompletionResult]::new('--agent-peer-script-pre-up-line', '--agent-peer-script-pre-up-line', [CompletionResultType]::ParameterName, 'agent-peer-script-pre-up-line')
            [CompletionResult]::new('--agent-peer-script-post-up-enabled', '--agent-peer-script-post-up-enabled', [CompletionResultType]::ParameterName, 'agent-peer-script-post-up-enabled')
            [CompletionResult]::new('--agent-peer-script-post-up-line', '--agent-peer-script-post-up-line', [CompletionResultType]::ParameterName, 'agent-peer-script-post-up-line')
            [CompletionResult]::new('--agent-peer-script-pre-down-enabled', '--agent-peer-script-pre-down-enabled', [CompletionResultType]::ParameterName, 'agent-peer-script-pre-down-enabled')
            [CompletionResult]::new('--agent-peer-script-pre-down-line', '--agent-peer-script-pre-down-line', [CompletionResultType]::ParameterName, 'agent-peer-script-pre-down-line')
            [CompletionResult]::new('--agent-peer-script-post-down-enabled', '--agent-peer-script-post-down-enabled', [CompletionResultType]::ParameterName, 'agent-peer-script-post-down-enabled')
            [CompletionResult]::new('--agent-peer-script-post-down-line', '--agent-peer-script-post-down-line', [CompletionResultType]::ParameterName, 'agent-peer-script-post-down-line')
            [CompletionResult]::new('--default-peer-kind', '--default-peer-kind', [CompletionResultType]::ParameterName, 'default-peer-kind')
            [CompletionResult]::new('--default-peer-icon-enabled', '--default-peer-icon-enabled', [CompletionResultType]::ParameterName, 'default-peer-icon-enabled')
            [CompletionResult]::new('--default-peer-icon-src', '--default-peer-icon-src', [CompletionResultType]::ParameterName, 'default-peer-icon-src')
            [CompletionResult]::new('--default-peer-dns-enabled', '--default-peer-dns-enabled', [CompletionResultType]::ParameterName, 'default-peer-dns-enabled')
            [CompletionResult]::new('--default-peer-dns-addresses', '--default-peer-dns-addresses', [CompletionResultType]::ParameterName, 'default-peer-dns-addresses')
            [CompletionResult]::new('--default-peer-mtu-enabled', '--default-peer-mtu-enabled', [CompletionResultType]::ParameterName, 'default-peer-mtu-enabled')
            [CompletionResult]::new('--default-peer-mtu-value', '--default-peer-mtu-value', [CompletionResultType]::ParameterName, 'default-peer-mtu-value')
            [CompletionResult]::new('--default-peer-script-pre-up-enabled', '--default-peer-script-pre-up-enabled', [CompletionResultType]::ParameterName, 'default-peer-script-pre-up-enabled')
            [CompletionResult]::new('--default-peer-script-pre-up-line', '--default-peer-script-pre-up-line', [CompletionResultType]::ParameterName, 'default-peer-script-pre-up-line')
            [CompletionResult]::new('--default-peer-script-post-up-enabled', '--default-peer-script-post-up-enabled', [CompletionResultType]::ParameterName, 'default-peer-script-post-up-enabled')
            [CompletionResult]::new('--default-peer-script-post-up-line', '--default-peer-script-post-up-line', [CompletionResultType]::ParameterName, 'default-peer-script-post-up-line')
            [CompletionResult]::new('--default-peer-script-pre-down-enabled', '--default-peer-script-pre-down-enabled', [CompletionResultType]::ParameterName, 'default-peer-script-pre-down-enabled')
            [CompletionResult]::new('--default-peer-script-pre-down-line', '--default-peer-script-pre-down-line', [CompletionResultType]::ParameterName, 'default-peer-script-pre-down-line')
            [CompletionResult]::new('--default-peer-script-post-down-enabled', '--default-peer-script-post-down-enabled', [CompletionResultType]::ParameterName, 'default-peer-script-post-down-enabled')
            [CompletionResult]::new('--default-peer-script-post-down-line', '--default-peer-script-post-down-line', [CompletionResultType]::ParameterName, 'default-peer-script-post-down-line')
            [CompletionResult]::new('--default-connection-persistent-keepalive-enabled', '--default-connection-persistent-keepalive-enabled', [CompletionResultType]::ParameterName, 'default-connection-persistent-keepalive-enabled')
            [CompletionResult]::new('--default-connection-persistent-keepalive-period', '--default-connection-persistent-keepalive-period', [CompletionResultType]::ParameterName, 'default-connection-persistent-keepalive-period')
            [CompletionResult]::new('--no-prompt', '--no-prompt', [CompletionResultType]::ParameterName, 'no-prompt')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help (see more with ''--help'')')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help (see more with ''--help'')')
            break
        }
        'wg-quickrs;agent;run' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;agent;help' {
            [CompletionResult]::new('init', 'init', [CompletionResultType]::ParameterValue, 'Initialize the wg-quickrs agent. Configuration options can be filled either by prompts on screen (when no argument is provided) or specified as arguments to this command')
            [CompletionResult]::new('run', 'run', [CompletionResultType]::ParameterValue, 'Run the wg-quickrs agent')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;agent;help;init' {
            break
        }
        'wg-quickrs;agent;help;run' {
            break
        }
        'wg-quickrs;agent;help;help' {
            break
        }
        'wg-quickrs;config' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enable', 'enable', [CompletionResultType]::ParameterValue, 'Enable a configuration option')
            [CompletionResult]::new('disable', 'disable', [CompletionResultType]::ParameterValue, 'Disable a configuration option')
            [CompletionResult]::new('set', 'set', [CompletionResultType]::ParameterValue, 'Set a configuration value')
            [CompletionResult]::new('reset', 'reset', [CompletionResultType]::ParameterValue, 'Reset a configuration option')
            [CompletionResult]::new('get', 'get', [CompletionResultType]::ParameterValue, 'Get a configuration value')
            [CompletionResult]::new('list', 'list', [CompletionResultType]::ParameterValue, 'List network entities in human-readable format')
            [CompletionResult]::new('remove', 'remove', [CompletionResultType]::ParameterValue, 'Remove network entities')
            [CompletionResult]::new('add', 'add', [CompletionResultType]::ParameterValue, 'Add network entities')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Enable agent configuration options')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Enable network configuration options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;agent' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Enable web server options')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Enable VPN server')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Enable firewall configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;agent;web' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Enable HTTP on web server')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Enable HTTPS on web server')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Enable password authentication for web server')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;agent;web;http' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;agent;web;https' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;agent;web;password' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;agent;web;help' {
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Enable HTTP on web server')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Enable HTTPS on web server')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Enable password authentication for web server')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;agent;web;help;http' {
            break
        }
        'wg-quickrs;config;enable;agent;web;help;https' {
            break
        }
        'wg-quickrs;config;enable;agent;web;help;password' {
            break
        }
        'wg-quickrs;config;enable;agent;web;help;help' {
            break
        }
        'wg-quickrs;config;enable;agent;vpn' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;agent;firewall' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;agent;help' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Enable web server options')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Enable VPN server')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Enable firewall configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;agent;help;web' {
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Enable HTTP on web server')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Enable HTTPS on web server')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Enable password authentication for web server')
            break
        }
        'wg-quickrs;config;enable;agent;help;web;http' {
            break
        }
        'wg-quickrs;config;enable;agent;help;web;https' {
            break
        }
        'wg-quickrs;config;enable;agent;help;web;password' {
            break
        }
        'wg-quickrs;config;enable;agent;help;vpn' {
            break
        }
        'wg-quickrs;config;enable;agent;help;firewall' {
            break
        }
        'wg-quickrs;config;enable;agent;help;help' {
            break
        }
        'wg-quickrs;config;enable;network' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Enable peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Enable connection')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Enable default configuration options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;network;peer' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Enable peer endpoint')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable peer MTU')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;network;peer;endpoint' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;network;peer;icon' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;network;peer;dns' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;network;peer;mtu' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;network;peer;help' {
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Enable peer endpoint')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable peer MTU')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;network;peer;help;endpoint' {
            break
        }
        'wg-quickrs;config;enable;network;peer;help;icon' {
            break
        }
        'wg-quickrs;config;enable;network;peer;help;dns' {
            break
        }
        'wg-quickrs;config;enable;network;peer;help;mtu' {
            break
        }
        'wg-quickrs;config;enable;network;peer;help;help' {
            break
        }
        'wg-quickrs;config;enable;network;connection' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;network;defaults' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Enable default peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Enable default connection options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;network;defaults;peer' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable default peer MTU')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;network;defaults;peer;icon' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;network;defaults;peer;dns' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;network;defaults;peer;mtu' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;network;defaults;peer;help' {
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable default peer MTU')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;network;defaults;peer;help;icon' {
            break
        }
        'wg-quickrs;config;enable;network;defaults;peer;help;dns' {
            break
        }
        'wg-quickrs;config;enable;network;defaults;peer;help;mtu' {
            break
        }
        'wg-quickrs;config;enable;network;defaults;peer;help;help' {
            break
        }
        'wg-quickrs;config;enable;network;defaults;connection' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Enable default connection persistent keepalive')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;network;defaults;connection;persistent-keepalive' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;enable;network;defaults;connection;help' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Enable default connection persistent keepalive')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;network;defaults;connection;help;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;enable;network;defaults;connection;help;help' {
            break
        }
        'wg-quickrs;config;enable;network;defaults;help' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Enable default peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Enable default connection options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;network;defaults;help;peer' {
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable default peer MTU')
            break
        }
        'wg-quickrs;config;enable;network;defaults;help;peer;icon' {
            break
        }
        'wg-quickrs;config;enable;network;defaults;help;peer;dns' {
            break
        }
        'wg-quickrs;config;enable;network;defaults;help;peer;mtu' {
            break
        }
        'wg-quickrs;config;enable;network;defaults;help;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Enable default connection persistent keepalive')
            break
        }
        'wg-quickrs;config;enable;network;defaults;help;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;enable;network;defaults;help;help' {
            break
        }
        'wg-quickrs;config;enable;network;help' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Enable peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Enable connection')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Enable default configuration options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;network;help;peer' {
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Enable peer endpoint')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable peer MTU')
            break
        }
        'wg-quickrs;config;enable;network;help;peer;endpoint' {
            break
        }
        'wg-quickrs;config;enable;network;help;peer;icon' {
            break
        }
        'wg-quickrs;config;enable;network;help;peer;dns' {
            break
        }
        'wg-quickrs;config;enable;network;help;peer;mtu' {
            break
        }
        'wg-quickrs;config;enable;network;help;connection' {
            break
        }
        'wg-quickrs;config;enable;network;help;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Enable default peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Enable default connection options')
            break
        }
        'wg-quickrs;config;enable;network;help;defaults;peer' {
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable default peer MTU')
            break
        }
        'wg-quickrs;config;enable;network;help;defaults;peer;icon' {
            break
        }
        'wg-quickrs;config;enable;network;help;defaults;peer;dns' {
            break
        }
        'wg-quickrs;config;enable;network;help;defaults;peer;mtu' {
            break
        }
        'wg-quickrs;config;enable;network;help;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Enable default connection persistent keepalive')
            break
        }
        'wg-quickrs;config;enable;network;help;defaults;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;enable;network;help;help' {
            break
        }
        'wg-quickrs;config;enable;help' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Enable agent configuration options')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Enable network configuration options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;enable;help;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Enable web server options')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Enable VPN server')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Enable firewall configuration')
            break
        }
        'wg-quickrs;config;enable;help;agent;web' {
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Enable HTTP on web server')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Enable HTTPS on web server')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Enable password authentication for web server')
            break
        }
        'wg-quickrs;config;enable;help;agent;web;http' {
            break
        }
        'wg-quickrs;config;enable;help;agent;web;https' {
            break
        }
        'wg-quickrs;config;enable;help;agent;web;password' {
            break
        }
        'wg-quickrs;config;enable;help;agent;vpn' {
            break
        }
        'wg-quickrs;config;enable;help;agent;firewall' {
            break
        }
        'wg-quickrs;config;enable;help;network' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Enable peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Enable connection')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Enable default configuration options')
            break
        }
        'wg-quickrs;config;enable;help;network;peer' {
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Enable peer endpoint')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable peer MTU')
            break
        }
        'wg-quickrs;config;enable;help;network;peer;endpoint' {
            break
        }
        'wg-quickrs;config;enable;help;network;peer;icon' {
            break
        }
        'wg-quickrs;config;enable;help;network;peer;dns' {
            break
        }
        'wg-quickrs;config;enable;help;network;peer;mtu' {
            break
        }
        'wg-quickrs;config;enable;help;network;connection' {
            break
        }
        'wg-quickrs;config;enable;help;network;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Enable default peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Enable default connection options')
            break
        }
        'wg-quickrs;config;enable;help;network;defaults;peer' {
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable default peer MTU')
            break
        }
        'wg-quickrs;config;enable;help;network;defaults;peer;icon' {
            break
        }
        'wg-quickrs;config;enable;help;network;defaults;peer;dns' {
            break
        }
        'wg-quickrs;config;enable;help;network;defaults;peer;mtu' {
            break
        }
        'wg-quickrs;config;enable;help;network;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Enable default connection persistent keepalive')
            break
        }
        'wg-quickrs;config;enable;help;network;defaults;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;enable;help;help' {
            break
        }
        'wg-quickrs;config;disable' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Disable agent configuration options')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Disable network configuration options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;agent' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Disable web server options')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Disable VPN server')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Disable firewall configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;agent;web' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Disable HTTP on web server')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Disable HTTPS on web server')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Disable password authentication for web server')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;agent;web;http' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;agent;web;https' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;agent;web;password' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;agent;web;help' {
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Disable HTTP on web server')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Disable HTTPS on web server')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Disable password authentication for web server')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;agent;web;help;http' {
            break
        }
        'wg-quickrs;config;disable;agent;web;help;https' {
            break
        }
        'wg-quickrs;config;disable;agent;web;help;password' {
            break
        }
        'wg-quickrs;config;disable;agent;web;help;help' {
            break
        }
        'wg-quickrs;config;disable;agent;vpn' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;agent;firewall' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;agent;help' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Disable web server options')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Disable VPN server')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Disable firewall configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;agent;help;web' {
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Disable HTTP on web server')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Disable HTTPS on web server')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Disable password authentication for web server')
            break
        }
        'wg-quickrs;config;disable;agent;help;web;http' {
            break
        }
        'wg-quickrs;config;disable;agent;help;web;https' {
            break
        }
        'wg-quickrs;config;disable;agent;help;web;password' {
            break
        }
        'wg-quickrs;config;disable;agent;help;vpn' {
            break
        }
        'wg-quickrs;config;disable;agent;help;firewall' {
            break
        }
        'wg-quickrs;config;disable;agent;help;help' {
            break
        }
        'wg-quickrs;config;disable;network' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Disable peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Disable connection')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Disable default configuration options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;network;peer' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Disable peer endpoint')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable peer MTU')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;network;peer;endpoint' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;network;peer;icon' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;network;peer;dns' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;network;peer;mtu' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;network;peer;help' {
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Disable peer endpoint')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable peer MTU')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;network;peer;help;endpoint' {
            break
        }
        'wg-quickrs;config;disable;network;peer;help;icon' {
            break
        }
        'wg-quickrs;config;disable;network;peer;help;dns' {
            break
        }
        'wg-quickrs;config;disable;network;peer;help;mtu' {
            break
        }
        'wg-quickrs;config;disable;network;peer;help;help' {
            break
        }
        'wg-quickrs;config;disable;network;connection' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;network;defaults' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Disable default peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Disable default connection options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;network;defaults;peer' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable default peer MTU')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;network;defaults;peer;icon' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;network;defaults;peer;dns' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;network;defaults;peer;mtu' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;network;defaults;peer;help' {
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable default peer MTU')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;network;defaults;peer;help;icon' {
            break
        }
        'wg-quickrs;config;disable;network;defaults;peer;help;dns' {
            break
        }
        'wg-quickrs;config;disable;network;defaults;peer;help;mtu' {
            break
        }
        'wg-quickrs;config;disable;network;defaults;peer;help;help' {
            break
        }
        'wg-quickrs;config;disable;network;defaults;connection' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Disable default connection persistent keepalive')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;network;defaults;connection;persistent-keepalive' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;disable;network;defaults;connection;help' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Disable default connection persistent keepalive')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;network;defaults;connection;help;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;disable;network;defaults;connection;help;help' {
            break
        }
        'wg-quickrs;config;disable;network;defaults;help' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Disable default peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Disable default connection options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;network;defaults;help;peer' {
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable default peer MTU')
            break
        }
        'wg-quickrs;config;disable;network;defaults;help;peer;icon' {
            break
        }
        'wg-quickrs;config;disable;network;defaults;help;peer;dns' {
            break
        }
        'wg-quickrs;config;disable;network;defaults;help;peer;mtu' {
            break
        }
        'wg-quickrs;config;disable;network;defaults;help;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Disable default connection persistent keepalive')
            break
        }
        'wg-quickrs;config;disable;network;defaults;help;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;disable;network;defaults;help;help' {
            break
        }
        'wg-quickrs;config;disable;network;help' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Disable peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Disable connection')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Disable default configuration options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;network;help;peer' {
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Disable peer endpoint')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable peer MTU')
            break
        }
        'wg-quickrs;config;disable;network;help;peer;endpoint' {
            break
        }
        'wg-quickrs;config;disable;network;help;peer;icon' {
            break
        }
        'wg-quickrs;config;disable;network;help;peer;dns' {
            break
        }
        'wg-quickrs;config;disable;network;help;peer;mtu' {
            break
        }
        'wg-quickrs;config;disable;network;help;connection' {
            break
        }
        'wg-quickrs;config;disable;network;help;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Disable default peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Disable default connection options')
            break
        }
        'wg-quickrs;config;disable;network;help;defaults;peer' {
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable default peer MTU')
            break
        }
        'wg-quickrs;config;disable;network;help;defaults;peer;icon' {
            break
        }
        'wg-quickrs;config;disable;network;help;defaults;peer;dns' {
            break
        }
        'wg-quickrs;config;disable;network;help;defaults;peer;mtu' {
            break
        }
        'wg-quickrs;config;disable;network;help;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Disable default connection persistent keepalive')
            break
        }
        'wg-quickrs;config;disable;network;help;defaults;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;disable;network;help;help' {
            break
        }
        'wg-quickrs;config;disable;help' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Disable agent configuration options')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Disable network configuration options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;disable;help;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Disable web server options')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Disable VPN server')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Disable firewall configuration')
            break
        }
        'wg-quickrs;config;disable;help;agent;web' {
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Disable HTTP on web server')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Disable HTTPS on web server')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Disable password authentication for web server')
            break
        }
        'wg-quickrs;config;disable;help;agent;web;http' {
            break
        }
        'wg-quickrs;config;disable;help;agent;web;https' {
            break
        }
        'wg-quickrs;config;disable;help;agent;web;password' {
            break
        }
        'wg-quickrs;config;disable;help;agent;vpn' {
            break
        }
        'wg-quickrs;config;disable;help;agent;firewall' {
            break
        }
        'wg-quickrs;config;disable;help;network' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Disable peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Disable connection')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Disable default configuration options')
            break
        }
        'wg-quickrs;config;disable;help;network;peer' {
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Disable peer endpoint')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable peer MTU')
            break
        }
        'wg-quickrs;config;disable;help;network;peer;endpoint' {
            break
        }
        'wg-quickrs;config;disable;help;network;peer;icon' {
            break
        }
        'wg-quickrs;config;disable;help;network;peer;dns' {
            break
        }
        'wg-quickrs;config;disable;help;network;peer;mtu' {
            break
        }
        'wg-quickrs;config;disable;help;network;connection' {
            break
        }
        'wg-quickrs;config;disable;help;network;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Disable default peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Disable default connection options')
            break
        }
        'wg-quickrs;config;disable;help;network;defaults;peer' {
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable default peer MTU')
            break
        }
        'wg-quickrs;config;disable;help;network;defaults;peer;icon' {
            break
        }
        'wg-quickrs;config;disable;help;network;defaults;peer;dns' {
            break
        }
        'wg-quickrs;config;disable;help;network;defaults;peer;mtu' {
            break
        }
        'wg-quickrs;config;disable;help;network;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Disable default connection persistent keepalive')
            break
        }
        'wg-quickrs;config;disable;help;network;defaults;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;disable;help;help' {
            break
        }
        'wg-quickrs;config;set' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Set agent configuration values')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Set network configuration values')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Set web server configuration')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Set VPN configuration')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Set firewall configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent;web' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Set agent web server bind IPv4 address')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Set HTTP configuration')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Set HTTPS configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent;web;address' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;agent;web;http' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTP port')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent;web;http;port' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;agent;web;http;help' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTP port')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent;web;http;help;port' {
            break
        }
        'wg-quickrs;config;set;agent;web;http;help;help' {
            break
        }
        'wg-quickrs;config;set;agent;web;https' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent;web;https;port' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;agent;web;https;tls-cert' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;agent;web;https;tls-key' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;agent;web;https;help' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent;web;https;help;port' {
            break
        }
        'wg-quickrs;config;set;agent;web;https;help;tls-cert' {
            break
        }
        'wg-quickrs;config;set;agent;web;https;help;tls-key' {
            break
        }
        'wg-quickrs;config;set;agent;web;https;help;help' {
            break
        }
        'wg-quickrs;config;set;agent;web;help' {
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Set agent web server bind IPv4 address')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Set HTTP configuration')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Set HTTPS configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent;web;help;address' {
            break
        }
        'wg-quickrs;config;set;agent;web;help;http' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTP port')
            break
        }
        'wg-quickrs;config;set;agent;web;help;http;port' {
            break
        }
        'wg-quickrs;config;set;agent;web;help;https' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS')
            break
        }
        'wg-quickrs;config;set;agent;web;help;https;port' {
            break
        }
        'wg-quickrs;config;set;agent;web;help;https;tls-cert' {
            break
        }
        'wg-quickrs;config;set;agent;web;help;https;tls-key' {
            break
        }
        'wg-quickrs;config;set;agent;web;help;help' {
            break
        }
        'wg-quickrs;config;set;agent;vpn' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set VPN server listening port')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent;vpn;port' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;agent;vpn;help' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set VPN server listening port')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent;vpn;help;port' {
            break
        }
        'wg-quickrs;config;set;agent;vpn;help;help' {
            break
        }
        'wg-quickrs;config;set;agent;firewall' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('utility', 'utility', [CompletionResultType]::ParameterValue, 'Set the utility used to configure firewall NAT and input rules (e.g. iptables, pfctl, etc.)')
            [CompletionResult]::new('gateway', 'gateway', [CompletionResultType]::ParameterValue, 'Set the gateway used to configure firewall NAT and input rules (e.g. en0, eth0, etc.)')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent;firewall;utility' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;agent;firewall;gateway' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;agent;firewall;help' {
            [CompletionResult]::new('utility', 'utility', [CompletionResultType]::ParameterValue, 'Set the utility used to configure firewall NAT and input rules (e.g. iptables, pfctl, etc.)')
            [CompletionResult]::new('gateway', 'gateway', [CompletionResultType]::ParameterValue, 'Set the gateway used to configure firewall NAT and input rules (e.g. en0, eth0, etc.)')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent;firewall;help;utility' {
            break
        }
        'wg-quickrs;config;set;agent;firewall;help;gateway' {
            break
        }
        'wg-quickrs;config;set;agent;firewall;help;help' {
            break
        }
        'wg-quickrs;config;set;agent;help' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Set web server configuration')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Set VPN configuration')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Set firewall configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;agent;help;web' {
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Set agent web server bind IPv4 address')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Set HTTP configuration')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Set HTTPS configuration')
            break
        }
        'wg-quickrs;config;set;agent;help;web;address' {
            break
        }
        'wg-quickrs;config;set;agent;help;web;http' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTP port')
            break
        }
        'wg-quickrs;config;set;agent;help;web;http;port' {
            break
        }
        'wg-quickrs;config;set;agent;help;web;https' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS')
            break
        }
        'wg-quickrs;config;set;agent;help;web;https;port' {
            break
        }
        'wg-quickrs;config;set;agent;help;web;https;tls-cert' {
            break
        }
        'wg-quickrs;config;set;agent;help;web;https;tls-key' {
            break
        }
        'wg-quickrs;config;set;agent;help;vpn' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set VPN server listening port')
            break
        }
        'wg-quickrs;config;set;agent;help;vpn;port' {
            break
        }
        'wg-quickrs;config;set;agent;help;firewall' {
            [CompletionResult]::new('utility', 'utility', [CompletionResultType]::ParameterValue, 'Set the utility used to configure firewall NAT and input rules (e.g. iptables, pfctl, etc.)')
            [CompletionResult]::new('gateway', 'gateway', [CompletionResultType]::ParameterValue, 'Set the gateway used to configure firewall NAT and input rules (e.g. en0, eth0, etc.)')
            break
        }
        'wg-quickrs;config;set;agent;help;firewall;utility' {
            break
        }
        'wg-quickrs;config;set;agent;help;firewall;gateway' {
            break
        }
        'wg-quickrs;config;set;agent;help;help' {
            break
        }
        'wg-quickrs;config;set;network' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Set network name')
            [CompletionResult]::new('subnet', 'subnet', [CompletionResultType]::ParameterValue, 'Set network subnet')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Set peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Set connection configuration')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Set default configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;network;name' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;subnet' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;peer' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Set peer name')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Set peer address')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Set peer endpoint address')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set peer MTU value')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;network;peer;name' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;peer;address' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;peer;endpoint' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;peer;kind' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;peer;icon' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;peer;dns' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;peer;mtu' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;peer;help' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Set peer name')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Set peer address')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Set peer endpoint address')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set peer MTU value')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;network;peer;help;name' {
            break
        }
        'wg-quickrs;config;set;network;peer;help;address' {
            break
        }
        'wg-quickrs;config;set;network;peer;help;endpoint' {
            break
        }
        'wg-quickrs;config;set;network;peer;help;kind' {
            break
        }
        'wg-quickrs;config;set;network;peer;help;icon' {
            break
        }
        'wg-quickrs;config;set;network;peer;help;dns' {
            break
        }
        'wg-quickrs;config;set;network;peer;help;mtu' {
            break
        }
        'wg-quickrs;config;set;network;peer;help;help' {
            break
        }
        'wg-quickrs;config;set;network;connection' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('allowed-ips-a-to-b', 'allowed-ips-a-to-b', [CompletionResultType]::ParameterValue, 'Set allowed IPs from peer A to peer B')
            [CompletionResult]::new('allowed-ips-b-to-a', 'allowed-ips-b-to-a', [CompletionResultType]::ParameterValue, 'Set allowed IPs from peer B to peer A')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set persistent keepalive period')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;network;connection;allowed-ips-a-to-b' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;connection;allowed-ips-b-to-a' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;connection;persistent-keepalive' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;connection;help' {
            [CompletionResult]::new('allowed-ips-a-to-b', 'allowed-ips-a-to-b', [CompletionResultType]::ParameterValue, 'Set allowed IPs from peer A to peer B')
            [CompletionResult]::new('allowed-ips-b-to-a', 'allowed-ips-b-to-a', [CompletionResultType]::ParameterValue, 'Set allowed IPs from peer B to peer A')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set persistent keepalive period')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;network;connection;help;allowed-ips-a-to-b' {
            break
        }
        'wg-quickrs;config;set;network;connection;help;allowed-ips-b-to-a' {
            break
        }
        'wg-quickrs;config;set;network;connection;help;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;set;network;connection;help;help' {
            break
        }
        'wg-quickrs;config;set;network;defaults' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Set default peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Set default connection configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;network;defaults;peer' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set default peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set default peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set default peer MTU value')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;network;defaults;peer;kind' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;defaults;peer;icon' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;defaults;peer;dns' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;defaults;peer;mtu' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;defaults;peer;help' {
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set default peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set default peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set default peer MTU value')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;network;defaults;peer;help;kind' {
            break
        }
        'wg-quickrs;config;set;network;defaults;peer;help;icon' {
            break
        }
        'wg-quickrs;config;set;network;defaults;peer;help;dns' {
            break
        }
        'wg-quickrs;config;set;network;defaults;peer;help;mtu' {
            break
        }
        'wg-quickrs;config;set;network;defaults;peer;help;help' {
            break
        }
        'wg-quickrs;config;set;network;defaults;connection' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set default connection persistent keepalive period')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;network;defaults;connection;persistent-keepalive' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;set;network;defaults;connection;help' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set default connection persistent keepalive period')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;network;defaults;connection;help;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;set;network;defaults;connection;help;help' {
            break
        }
        'wg-quickrs;config;set;network;defaults;help' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Set default peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Set default connection configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;network;defaults;help;peer' {
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set default peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set default peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set default peer MTU value')
            break
        }
        'wg-quickrs;config;set;network;defaults;help;peer;kind' {
            break
        }
        'wg-quickrs;config;set;network;defaults;help;peer;icon' {
            break
        }
        'wg-quickrs;config;set;network;defaults;help;peer;dns' {
            break
        }
        'wg-quickrs;config;set;network;defaults;help;peer;mtu' {
            break
        }
        'wg-quickrs;config;set;network;defaults;help;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set default connection persistent keepalive period')
            break
        }
        'wg-quickrs;config;set;network;defaults;help;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;set;network;defaults;help;help' {
            break
        }
        'wg-quickrs;config;set;network;help' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Set network name')
            [CompletionResult]::new('subnet', 'subnet', [CompletionResultType]::ParameterValue, 'Set network subnet')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Set peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Set connection configuration')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Set default configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;network;help;name' {
            break
        }
        'wg-quickrs;config;set;network;help;subnet' {
            break
        }
        'wg-quickrs;config;set;network;help;peer' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Set peer name')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Set peer address')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Set peer endpoint address')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set peer MTU value')
            break
        }
        'wg-quickrs;config;set;network;help;peer;name' {
            break
        }
        'wg-quickrs;config;set;network;help;peer;address' {
            break
        }
        'wg-quickrs;config;set;network;help;peer;endpoint' {
            break
        }
        'wg-quickrs;config;set;network;help;peer;kind' {
            break
        }
        'wg-quickrs;config;set;network;help;peer;icon' {
            break
        }
        'wg-quickrs;config;set;network;help;peer;dns' {
            break
        }
        'wg-quickrs;config;set;network;help;peer;mtu' {
            break
        }
        'wg-quickrs;config;set;network;help;connection' {
            [CompletionResult]::new('allowed-ips-a-to-b', 'allowed-ips-a-to-b', [CompletionResultType]::ParameterValue, 'Set allowed IPs from peer A to peer B')
            [CompletionResult]::new('allowed-ips-b-to-a', 'allowed-ips-b-to-a', [CompletionResultType]::ParameterValue, 'Set allowed IPs from peer B to peer A')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set persistent keepalive period')
            break
        }
        'wg-quickrs;config;set;network;help;connection;allowed-ips-a-to-b' {
            break
        }
        'wg-quickrs;config;set;network;help;connection;allowed-ips-b-to-a' {
            break
        }
        'wg-quickrs;config;set;network;help;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;set;network;help;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Set default peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Set default connection configuration')
            break
        }
        'wg-quickrs;config;set;network;help;defaults;peer' {
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set default peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set default peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set default peer MTU value')
            break
        }
        'wg-quickrs;config;set;network;help;defaults;peer;kind' {
            break
        }
        'wg-quickrs;config;set;network;help;defaults;peer;icon' {
            break
        }
        'wg-quickrs;config;set;network;help;defaults;peer;dns' {
            break
        }
        'wg-quickrs;config;set;network;help;defaults;peer;mtu' {
            break
        }
        'wg-quickrs;config;set;network;help;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set default connection persistent keepalive period')
            break
        }
        'wg-quickrs;config;set;network;help;defaults;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;set;network;help;help' {
            break
        }
        'wg-quickrs;config;set;help' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Set agent configuration values')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Set network configuration values')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;set;help;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Set web server configuration')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Set VPN configuration')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Set firewall configuration')
            break
        }
        'wg-quickrs;config;set;help;agent;web' {
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Set agent web server bind IPv4 address')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Set HTTP configuration')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Set HTTPS configuration')
            break
        }
        'wg-quickrs;config;set;help;agent;web;address' {
            break
        }
        'wg-quickrs;config;set;help;agent;web;http' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTP port')
            break
        }
        'wg-quickrs;config;set;help;agent;web;http;port' {
            break
        }
        'wg-quickrs;config;set;help;agent;web;https' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS')
            break
        }
        'wg-quickrs;config;set;help;agent;web;https;port' {
            break
        }
        'wg-quickrs;config;set;help;agent;web;https;tls-cert' {
            break
        }
        'wg-quickrs;config;set;help;agent;web;https;tls-key' {
            break
        }
        'wg-quickrs;config;set;help;agent;vpn' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set VPN server listening port')
            break
        }
        'wg-quickrs;config;set;help;agent;vpn;port' {
            break
        }
        'wg-quickrs;config;set;help;agent;firewall' {
            [CompletionResult]::new('utility', 'utility', [CompletionResultType]::ParameterValue, 'Set the utility used to configure firewall NAT and input rules (e.g. iptables, pfctl, etc.)')
            [CompletionResult]::new('gateway', 'gateway', [CompletionResultType]::ParameterValue, 'Set the gateway used to configure firewall NAT and input rules (e.g. en0, eth0, etc.)')
            break
        }
        'wg-quickrs;config;set;help;agent;firewall;utility' {
            break
        }
        'wg-quickrs;config;set;help;agent;firewall;gateway' {
            break
        }
        'wg-quickrs;config;set;help;network' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Set network name')
            [CompletionResult]::new('subnet', 'subnet', [CompletionResultType]::ParameterValue, 'Set network subnet')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Set peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Set connection configuration')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Set default configuration')
            break
        }
        'wg-quickrs;config;set;help;network;name' {
            break
        }
        'wg-quickrs;config;set;help;network;subnet' {
            break
        }
        'wg-quickrs;config;set;help;network;peer' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Set peer name')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Set peer address')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Set peer endpoint address')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set peer MTU value')
            break
        }
        'wg-quickrs;config;set;help;network;peer;name' {
            break
        }
        'wg-quickrs;config;set;help;network;peer;address' {
            break
        }
        'wg-quickrs;config;set;help;network;peer;endpoint' {
            break
        }
        'wg-quickrs;config;set;help;network;peer;kind' {
            break
        }
        'wg-quickrs;config;set;help;network;peer;icon' {
            break
        }
        'wg-quickrs;config;set;help;network;peer;dns' {
            break
        }
        'wg-quickrs;config;set;help;network;peer;mtu' {
            break
        }
        'wg-quickrs;config;set;help;network;connection' {
            [CompletionResult]::new('allowed-ips-a-to-b', 'allowed-ips-a-to-b', [CompletionResultType]::ParameterValue, 'Set allowed IPs from peer A to peer B')
            [CompletionResult]::new('allowed-ips-b-to-a', 'allowed-ips-b-to-a', [CompletionResultType]::ParameterValue, 'Set allowed IPs from peer B to peer A')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set persistent keepalive period')
            break
        }
        'wg-quickrs;config;set;help;network;connection;allowed-ips-a-to-b' {
            break
        }
        'wg-quickrs;config;set;help;network;connection;allowed-ips-b-to-a' {
            break
        }
        'wg-quickrs;config;set;help;network;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;set;help;network;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Set default peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Set default connection configuration')
            break
        }
        'wg-quickrs;config;set;help;network;defaults;peer' {
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set default peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set default peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set default peer MTU value')
            break
        }
        'wg-quickrs;config;set;help;network;defaults;peer;kind' {
            break
        }
        'wg-quickrs;config;set;help;network;defaults;peer;icon' {
            break
        }
        'wg-quickrs;config;set;help;network;defaults;peer;dns' {
            break
        }
        'wg-quickrs;config;set;help;network;defaults;peer;mtu' {
            break
        }
        'wg-quickrs;config;set;help;network;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set default connection persistent keepalive period')
            break
        }
        'wg-quickrs;config;set;help;network;defaults;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;set;help;help' {
            break
        }
        'wg-quickrs;config;reset' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Reset agent configuration options')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Reset network configuration options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;reset;agent' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Reset web server configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;reset;agent;web' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Reset password for web server access')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;reset;agent;web;password' {
            [CompletionResult]::new('--password', '--password', [CompletionResultType]::ParameterName, 'The use of this option is HIGHLY DISCOURAGED because the plaintext password might show up in the shell history! THIS IS HIGHLY INSECURE! Please set the password without the --password flag, and the script will prompt for the password.')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;reset;agent;web;help' {
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Reset password for web server access')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;reset;agent;web;help;password' {
            break
        }
        'wg-quickrs;config;reset;agent;web;help;help' {
            break
        }
        'wg-quickrs;config;reset;agent;help' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Reset web server configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;reset;agent;help;web' {
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Reset password for web server access')
            break
        }
        'wg-quickrs;config;reset;agent;help;web;password' {
            break
        }
        'wg-quickrs;config;reset;agent;help;help' {
            break
        }
        'wg-quickrs;config;reset;network' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Reset peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Reset connection options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;reset;network;peer' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('private-key', 'private-key', [CompletionResultType]::ParameterValue, 'Reset peer private key (generates new WireGuard key)')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;reset;network;peer;private-key' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;reset;network;peer;help' {
            [CompletionResult]::new('private-key', 'private-key', [CompletionResultType]::ParameterValue, 'Reset peer private key (generates new WireGuard key)')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;reset;network;peer;help;private-key' {
            break
        }
        'wg-quickrs;config;reset;network;peer;help;help' {
            break
        }
        'wg-quickrs;config;reset;network;connection' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('pre-shared-key', 'pre-shared-key', [CompletionResultType]::ParameterValue, 'Reset connection pre-shared key (generates new WireGuard key)')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;reset;network;connection;pre-shared-key' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;reset;network;connection;help' {
            [CompletionResult]::new('pre-shared-key', 'pre-shared-key', [CompletionResultType]::ParameterValue, 'Reset connection pre-shared key (generates new WireGuard key)')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;reset;network;connection;help;pre-shared-key' {
            break
        }
        'wg-quickrs;config;reset;network;connection;help;help' {
            break
        }
        'wg-quickrs;config;reset;network;help' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Reset peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Reset connection options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;reset;network;help;peer' {
            [CompletionResult]::new('private-key', 'private-key', [CompletionResultType]::ParameterValue, 'Reset peer private key (generates new WireGuard key)')
            break
        }
        'wg-quickrs;config;reset;network;help;peer;private-key' {
            break
        }
        'wg-quickrs;config;reset;network;help;connection' {
            [CompletionResult]::new('pre-shared-key', 'pre-shared-key', [CompletionResultType]::ParameterValue, 'Reset connection pre-shared key (generates new WireGuard key)')
            break
        }
        'wg-quickrs;config;reset;network;help;connection;pre-shared-key' {
            break
        }
        'wg-quickrs;config;reset;network;help;help' {
            break
        }
        'wg-quickrs;config;reset;help' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Reset agent configuration options')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Reset network configuration options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;reset;help;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Reset web server configuration')
            break
        }
        'wg-quickrs;config;reset;help;agent;web' {
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Reset password for web server access')
            break
        }
        'wg-quickrs;config;reset;help;agent;web;password' {
            break
        }
        'wg-quickrs;config;reset;help;network' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Reset peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Reset connection options')
            break
        }
        'wg-quickrs;config;reset;help;network;peer' {
            [CompletionResult]::new('private-key', 'private-key', [CompletionResultType]::ParameterValue, 'Reset peer private key (generates new WireGuard key)')
            break
        }
        'wg-quickrs;config;reset;help;network;peer;private-key' {
            break
        }
        'wg-quickrs;config;reset;help;network;connection' {
            [CompletionResult]::new('pre-shared-key', 'pre-shared-key', [CompletionResultType]::ParameterValue, 'Reset connection pre-shared key (generates new WireGuard key)')
            break
        }
        'wg-quickrs;config;reset;help;network;connection;pre-shared-key' {
            break
        }
        'wg-quickrs;config;reset;help;help' {
            break
        }
        'wg-quickrs;config;get' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Get agent configuration values')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Get network configuration values')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Get web server configuration')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Get VPN configuration')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Get firewall configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;web' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get agent web server bind IPv4 address')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Get HTTP configuration')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Get HTTPS configuration')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Get password authentication configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;web;address' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;web;http' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTP is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTP port')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;web;http;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;web;http;port' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;web;http;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTP is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTP port')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;web;http;help;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;web;http;help;port' {
            break
        }
        'wg-quickrs;config;get;agent;web;http;help;help' {
            break
        }
        'wg-quickrs;config;get;agent;web;https' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTPS is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Get path to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Get path to TLS private key file for HTTPS')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;web;https;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;web;https;port' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;web;https;tls-cert' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;web;https;tls-key' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;web;https;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTPS is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Get path to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Get path to TLS private key file for HTTPS')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;web;https;help;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;web;https;help;port' {
            break
        }
        'wg-quickrs;config;get;agent;web;https;help;tls-cert' {
            break
        }
        'wg-quickrs;config;get;agent;web;https;help;tls-key' {
            break
        }
        'wg-quickrs;config;get;agent;web;https;help;help' {
            break
        }
        'wg-quickrs;config;get;agent;web;password' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether password authentication is enabled')
            [CompletionResult]::new('hash', 'hash', [CompletionResultType]::ParameterValue, 'Get password hash')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;web;password;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;web;password;hash' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;web;password;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether password authentication is enabled')
            [CompletionResult]::new('hash', 'hash', [CompletionResultType]::ParameterValue, 'Get password hash')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;web;password;help;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;web;password;help;hash' {
            break
        }
        'wg-quickrs;config;get;agent;web;password;help;help' {
            break
        }
        'wg-quickrs;config;get;agent;web;help' {
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get agent web server bind IPv4 address')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Get HTTP configuration')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Get HTTPS configuration')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Get password authentication configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;web;help;address' {
            break
        }
        'wg-quickrs;config;get;agent;web;help;http' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTP is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTP port')
            break
        }
        'wg-quickrs;config;get;agent;web;help;http;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;web;help;http;port' {
            break
        }
        'wg-quickrs;config;get;agent;web;help;https' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTPS is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Get path to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Get path to TLS private key file for HTTPS')
            break
        }
        'wg-quickrs;config;get;agent;web;help;https;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;web;help;https;port' {
            break
        }
        'wg-quickrs;config;get;agent;web;help;https;tls-cert' {
            break
        }
        'wg-quickrs;config;get;agent;web;help;https;tls-key' {
            break
        }
        'wg-quickrs;config;get;agent;web;help;password' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether password authentication is enabled')
            [CompletionResult]::new('hash', 'hash', [CompletionResultType]::ParameterValue, 'Get password hash')
            break
        }
        'wg-quickrs;config;get;agent;web;help;password;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;web;help;password;hash' {
            break
        }
        'wg-quickrs;config;get;agent;web;help;help' {
            break
        }
        'wg-quickrs;config;get;agent;vpn' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether VPN server is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get VPN server listening port')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;vpn;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;vpn;port' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;vpn;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether VPN server is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get VPN server listening port')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;vpn;help;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;vpn;help;port' {
            break
        }
        'wg-quickrs;config;get;agent;vpn;help;help' {
            break
        }
        'wg-quickrs;config;get;agent;firewall' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether firewall configuration is enabled')
            [CompletionResult]::new('utility', 'utility', [CompletionResultType]::ParameterValue, 'Get the utility used to configure firewall NAT and input rules')
            [CompletionResult]::new('gateway', 'gateway', [CompletionResultType]::ParameterValue, 'Get the gateway used to configure firewall NAT and input rules')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;firewall;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;firewall;utility' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;firewall;gateway' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;agent;firewall;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether firewall configuration is enabled')
            [CompletionResult]::new('utility', 'utility', [CompletionResultType]::ParameterValue, 'Get the utility used to configure firewall NAT and input rules')
            [CompletionResult]::new('gateway', 'gateway', [CompletionResultType]::ParameterValue, 'Get the gateway used to configure firewall NAT and input rules')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;firewall;help;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;firewall;help;utility' {
            break
        }
        'wg-quickrs;config;get;agent;firewall;help;gateway' {
            break
        }
        'wg-quickrs;config;get;agent;firewall;help;help' {
            break
        }
        'wg-quickrs;config;get;agent;help' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Get web server configuration')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Get VPN configuration')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Get firewall configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;agent;help;web' {
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get agent web server bind IPv4 address')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Get HTTP configuration')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Get HTTPS configuration')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Get password authentication configuration')
            break
        }
        'wg-quickrs;config;get;agent;help;web;address' {
            break
        }
        'wg-quickrs;config;get;agent;help;web;http' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTP is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTP port')
            break
        }
        'wg-quickrs;config;get;agent;help;web;http;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;help;web;http;port' {
            break
        }
        'wg-quickrs;config;get;agent;help;web;https' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTPS is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Get path to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Get path to TLS private key file for HTTPS')
            break
        }
        'wg-quickrs;config;get;agent;help;web;https;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;help;web;https;port' {
            break
        }
        'wg-quickrs;config;get;agent;help;web;https;tls-cert' {
            break
        }
        'wg-quickrs;config;get;agent;help;web;https;tls-key' {
            break
        }
        'wg-quickrs;config;get;agent;help;web;password' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether password authentication is enabled')
            [CompletionResult]::new('hash', 'hash', [CompletionResultType]::ParameterValue, 'Get password hash')
            break
        }
        'wg-quickrs;config;get;agent;help;web;password;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;help;web;password;hash' {
            break
        }
        'wg-quickrs;config;get;agent;help;vpn' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether VPN server is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get VPN server listening port')
            break
        }
        'wg-quickrs;config;get;agent;help;vpn;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;help;vpn;port' {
            break
        }
        'wg-quickrs;config;get;agent;help;firewall' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether firewall configuration is enabled')
            [CompletionResult]::new('utility', 'utility', [CompletionResultType]::ParameterValue, 'Get the utility used to configure firewall NAT and input rules')
            [CompletionResult]::new('gateway', 'gateway', [CompletionResultType]::ParameterValue, 'Get the gateway used to configure firewall NAT and input rules')
            break
        }
        'wg-quickrs;config;get;agent;help;firewall;enabled' {
            break
        }
        'wg-quickrs;config;get;agent;help;firewall;utility' {
            break
        }
        'wg-quickrs;config;get;agent;help;firewall;gateway' {
            break
        }
        'wg-quickrs;config;get;agent;help;help' {
            break
        }
        'wg-quickrs;config;get;network' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Get network name')
            [CompletionResult]::new('subnet', 'subnet', [CompletionResultType]::ParameterValue, 'Get network subnet')
            [CompletionResult]::new('this-peer', 'this-peer', [CompletionResultType]::ParameterValue, 'Get this peer''s UUID')
            [CompletionResult]::new('peers', 'peers', [CompletionResultType]::ParameterValue, 'Get network peers')
            [CompletionResult]::new('connections', 'connections', [CompletionResultType]::ParameterValue, 'Get network connections')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Get network defaults')
            [CompletionResult]::new('reservations', 'reservations', [CompletionResultType]::ParameterValue, 'Get network reservations')
            [CompletionResult]::new('updated-at', 'updated-at', [CompletionResultType]::ParameterValue, 'Get network last updated timestamp')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;name' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;subnet' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;this-peer' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Get peer name')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get peer IP address')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Get peer endpoint')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get peer scripts')
            [CompletionResult]::new('private-key', 'private-key', [CompletionResultType]::ParameterValue, 'Get peer private key')
            [CompletionResult]::new('created-at', 'created-at', [CompletionResultType]::ParameterValue, 'Get peer creation timestamp')
            [CompletionResult]::new('updated-at', 'updated-at', [CompletionResultType]::ParameterValue, 'Get peer last updated timestamp')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;peers;name' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;address' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;endpoint' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether endpoint is enabled')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get endpoint address')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;peers;endpoint;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;endpoint;address' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;endpoint;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether endpoint is enabled')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get endpoint address')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;peers;endpoint;help;enabled' {
            break
        }
        'wg-quickrs;config;get;network;peers;endpoint;help;address' {
            break
        }
        'wg-quickrs;config;get;network;peers;endpoint;help;help' {
            break
        }
        'wg-quickrs;config;get;network;peers;kind' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;icon' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;peers;icon;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;icon;src' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;icon;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;peers;icon;help;enabled' {
            break
        }
        'wg-quickrs;config;get;network;peers;icon;help;src' {
            break
        }
        'wg-quickrs;config;get;network;peers;icon;help;help' {
            break
        }
        'wg-quickrs;config;get;network;peers;dns' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;peers;dns;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;dns;addresses' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;dns;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;peers;dns;help;enabled' {
            break
        }
        'wg-quickrs;config;get;network;peers;dns;help;addresses' {
            break
        }
        'wg-quickrs;config;get;network;peers;dns;help;help' {
            break
        }
        'wg-quickrs;config;get;network;peers;mtu' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;peers;mtu;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;mtu;value' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;mtu;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;peers;mtu;help;enabled' {
            break
        }
        'wg-quickrs;config;get;network;peers;mtu;help;value' {
            break
        }
        'wg-quickrs;config;get;network;peers;mtu;help;help' {
            break
        }
        'wg-quickrs;config;get;network;peers;scripts' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;private-key' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;created-at' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;updated-at' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;peers;help' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Get peer name')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get peer IP address')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Get peer endpoint')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get peer scripts')
            [CompletionResult]::new('private-key', 'private-key', [CompletionResultType]::ParameterValue, 'Get peer private key')
            [CompletionResult]::new('created-at', 'created-at', [CompletionResultType]::ParameterValue, 'Get peer creation timestamp')
            [CompletionResult]::new('updated-at', 'updated-at', [CompletionResultType]::ParameterValue, 'Get peer last updated timestamp')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;peers;help;name' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;address' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;endpoint' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether endpoint is enabled')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get endpoint address')
            break
        }
        'wg-quickrs;config;get;network;peers;help;endpoint;enabled' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;endpoint;address' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;kind' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;icon' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            break
        }
        'wg-quickrs;config;get;network;peers;help;icon;enabled' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;icon;src' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;dns' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            break
        }
        'wg-quickrs;config;get;network;peers;help;dns;enabled' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;dns;addresses' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;mtu' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            break
        }
        'wg-quickrs;config;get;network;peers;help;mtu;enabled' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;mtu;value' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;scripts' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;private-key' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;created-at' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;updated-at' {
            break
        }
        'wg-quickrs;config;get;network;peers;help;help' {
            break
        }
        'wg-quickrs;config;get;network;connections' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether connection is enabled')
            [CompletionResult]::new('pre-shared-key', 'pre-shared-key', [CompletionResultType]::ParameterValue, 'Get connection pre-shared key')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get connection persistent keepalive')
            [CompletionResult]::new('allowed-ips-a-to-b', 'allowed-ips-a-to-b', [CompletionResultType]::ParameterValue, 'Get allowed IPs from A to B')
            [CompletionResult]::new('allowed-ips-b-to-a', 'allowed-ips-b-to-a', [CompletionResultType]::ParameterValue, 'Get allowed IPs from B to A')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;connections;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;connections;pre-shared-key' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;connections;persistent-keepalive' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;connections;persistent-keepalive;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;connections;persistent-keepalive;period' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;connections;persistent-keepalive;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;connections;persistent-keepalive;help;enabled' {
            break
        }
        'wg-quickrs;config;get;network;connections;persistent-keepalive;help;period' {
            break
        }
        'wg-quickrs;config;get;network;connections;persistent-keepalive;help;help' {
            break
        }
        'wg-quickrs;config;get;network;connections;allowed-ips-a-to-b' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;connections;allowed-ips-b-to-a' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;connections;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether connection is enabled')
            [CompletionResult]::new('pre-shared-key', 'pre-shared-key', [CompletionResultType]::ParameterValue, 'Get connection pre-shared key')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get connection persistent keepalive')
            [CompletionResult]::new('allowed-ips-a-to-b', 'allowed-ips-a-to-b', [CompletionResultType]::ParameterValue, 'Get allowed IPs from A to B')
            [CompletionResult]::new('allowed-ips-b-to-a', 'allowed-ips-b-to-a', [CompletionResultType]::ParameterValue, 'Get allowed IPs from B to A')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;connections;help;enabled' {
            break
        }
        'wg-quickrs;config;get;network;connections;help;pre-shared-key' {
            break
        }
        'wg-quickrs;config;get;network;connections;help;persistent-keepalive' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            break
        }
        'wg-quickrs;config;get;network;connections;help;persistent-keepalive;enabled' {
            break
        }
        'wg-quickrs;config;get;network;connections;help;persistent-keepalive;period' {
            break
        }
        'wg-quickrs;config;get;network;connections;help;allowed-ips-a-to-b' {
            break
        }
        'wg-quickrs;config;get;network;connections;help;allowed-ips-b-to-a' {
            break
        }
        'wg-quickrs;config;get;network;connections;help;help' {
            break
        }
        'wg-quickrs;config;get;network;defaults' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Get default peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Get default connection configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get default peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get default peer scripts')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;kind' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;icon' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;icon;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;icon;src' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;icon;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;icon;help;enabled' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;icon;help;src' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;icon;help;help' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;dns' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;dns;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;dns;addresses' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;dns;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;dns;help;enabled' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;dns;help;addresses' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;dns;help;help' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;mtu' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;mtu;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;mtu;value' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;mtu;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;mtu;help;enabled' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;mtu;help;value' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;mtu;help;help' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;scripts' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help' {
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get default peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get default peer scripts')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help;kind' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help;icon' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help;icon;enabled' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help;icon;src' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help;dns' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help;dns;enabled' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help;dns;addresses' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help;mtu' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help;mtu;enabled' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help;mtu;value' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help;scripts' {
            break
        }
        'wg-quickrs;config;get;network;defaults;peer;help;help' {
            break
        }
        'wg-quickrs;config;get;network;defaults;connection' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get default connection persistent keepalive')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive;enabled' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive;period' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive;help' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive;help;enabled' {
            break
        }
        'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive;help;period' {
            break
        }
        'wg-quickrs;config;get;network;defaults;connection;persistent-keepalive;help;help' {
            break
        }
        'wg-quickrs;config;get;network;defaults;connection;help' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get default connection persistent keepalive')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;connection;help;persistent-keepalive' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            break
        }
        'wg-quickrs;config;get;network;defaults;connection;help;persistent-keepalive;enabled' {
            break
        }
        'wg-quickrs;config;get;network;defaults;connection;help;persistent-keepalive;period' {
            break
        }
        'wg-quickrs;config;get;network;defaults;connection;help;help' {
            break
        }
        'wg-quickrs;config;get;network;defaults;help' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Get default peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Get default connection configuration')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;defaults;help;peer' {
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get default peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get default peer scripts')
            break
        }
        'wg-quickrs;config;get;network;defaults;help;peer;kind' {
            break
        }
        'wg-quickrs;config;get;network;defaults;help;peer;icon' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            break
        }
        'wg-quickrs;config;get;network;defaults;help;peer;icon;enabled' {
            break
        }
        'wg-quickrs;config;get;network;defaults;help;peer;icon;src' {
            break
        }
        'wg-quickrs;config;get;network;defaults;help;peer;dns' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            break
        }
        'wg-quickrs;config;get;network;defaults;help;peer;dns;enabled' {
            break
        }
        'wg-quickrs;config;get;network;defaults;help;peer;dns;addresses' {
            break
        }
        'wg-quickrs;config;get;network;defaults;help;peer;mtu' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            break
        }
        'wg-quickrs;config;get;network;defaults;help;peer;mtu;enabled' {
            break
        }
        'wg-quickrs;config;get;network;defaults;help;peer;mtu;value' {
            break
        }
        'wg-quickrs;config;get;network;defaults;help;peer;scripts' {
            break
        }
        'wg-quickrs;config;get;network;defaults;help;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get default connection persistent keepalive')
            break
        }
        'wg-quickrs;config;get;network;defaults;help;connection;persistent-keepalive' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            break
        }
        'wg-quickrs;config;get;network;defaults;help;connection;persistent-keepalive;enabled' {
            break
        }
        'wg-quickrs;config;get;network;defaults;help;connection;persistent-keepalive;period' {
            break
        }
        'wg-quickrs;config;get;network;defaults;help;help' {
            break
        }
        'wg-quickrs;config;get;network;reservations' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('peer-id', 'peer-id', [CompletionResultType]::ParameterValue, 'Get reservation peer ID')
            [CompletionResult]::new('valid-until', 'valid-until', [CompletionResultType]::ParameterValue, 'Get reservation validity timestamp')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;reservations;peer-id' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;reservations;valid-until' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;reservations;help' {
            [CompletionResult]::new('peer-id', 'peer-id', [CompletionResultType]::ParameterValue, 'Get reservation peer ID')
            [CompletionResult]::new('valid-until', 'valid-until', [CompletionResultType]::ParameterValue, 'Get reservation validity timestamp')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;reservations;help;peer-id' {
            break
        }
        'wg-quickrs;config;get;network;reservations;help;valid-until' {
            break
        }
        'wg-quickrs;config;get;network;reservations;help;help' {
            break
        }
        'wg-quickrs;config;get;network;updated-at' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;get;network;help' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Get network name')
            [CompletionResult]::new('subnet', 'subnet', [CompletionResultType]::ParameterValue, 'Get network subnet')
            [CompletionResult]::new('this-peer', 'this-peer', [CompletionResultType]::ParameterValue, 'Get this peer''s UUID')
            [CompletionResult]::new('peers', 'peers', [CompletionResultType]::ParameterValue, 'Get network peers')
            [CompletionResult]::new('connections', 'connections', [CompletionResultType]::ParameterValue, 'Get network connections')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Get network defaults')
            [CompletionResult]::new('reservations', 'reservations', [CompletionResultType]::ParameterValue, 'Get network reservations')
            [CompletionResult]::new('updated-at', 'updated-at', [CompletionResultType]::ParameterValue, 'Get network last updated timestamp')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;network;help;name' {
            break
        }
        'wg-quickrs;config;get;network;help;subnet' {
            break
        }
        'wg-quickrs;config;get;network;help;this-peer' {
            break
        }
        'wg-quickrs;config;get;network;help;peers' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Get peer name')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get peer IP address')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Get peer endpoint')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get peer scripts')
            [CompletionResult]::new('private-key', 'private-key', [CompletionResultType]::ParameterValue, 'Get peer private key')
            [CompletionResult]::new('created-at', 'created-at', [CompletionResultType]::ParameterValue, 'Get peer creation timestamp')
            [CompletionResult]::new('updated-at', 'updated-at', [CompletionResultType]::ParameterValue, 'Get peer last updated timestamp')
            break
        }
        'wg-quickrs;config;get;network;help;peers;name' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;address' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;endpoint' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether endpoint is enabled')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get endpoint address')
            break
        }
        'wg-quickrs;config;get;network;help;peers;endpoint;enabled' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;endpoint;address' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;kind' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;icon' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            break
        }
        'wg-quickrs;config;get;network;help;peers;icon;enabled' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;icon;src' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;dns' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            break
        }
        'wg-quickrs;config;get;network;help;peers;dns;enabled' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;dns;addresses' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;mtu' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            break
        }
        'wg-quickrs;config;get;network;help;peers;mtu;enabled' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;mtu;value' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;scripts' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;private-key' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;created-at' {
            break
        }
        'wg-quickrs;config;get;network;help;peers;updated-at' {
            break
        }
        'wg-quickrs;config;get;network;help;connections' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether connection is enabled')
            [CompletionResult]::new('pre-shared-key', 'pre-shared-key', [CompletionResultType]::ParameterValue, 'Get connection pre-shared key')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get connection persistent keepalive')
            [CompletionResult]::new('allowed-ips-a-to-b', 'allowed-ips-a-to-b', [CompletionResultType]::ParameterValue, 'Get allowed IPs from A to B')
            [CompletionResult]::new('allowed-ips-b-to-a', 'allowed-ips-b-to-a', [CompletionResultType]::ParameterValue, 'Get allowed IPs from B to A')
            break
        }
        'wg-quickrs;config;get;network;help;connections;enabled' {
            break
        }
        'wg-quickrs;config;get;network;help;connections;pre-shared-key' {
            break
        }
        'wg-quickrs;config;get;network;help;connections;persistent-keepalive' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            break
        }
        'wg-quickrs;config;get;network;help;connections;persistent-keepalive;enabled' {
            break
        }
        'wg-quickrs;config;get;network;help;connections;persistent-keepalive;period' {
            break
        }
        'wg-quickrs;config;get;network;help;connections;allowed-ips-a-to-b' {
            break
        }
        'wg-quickrs;config;get;network;help;connections;allowed-ips-b-to-a' {
            break
        }
        'wg-quickrs;config;get;network;help;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Get default peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Get default connection configuration')
            break
        }
        'wg-quickrs;config;get;network;help;defaults;peer' {
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get default peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get default peer scripts')
            break
        }
        'wg-quickrs;config;get;network;help;defaults;peer;kind' {
            break
        }
        'wg-quickrs;config;get;network;help;defaults;peer;icon' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            break
        }
        'wg-quickrs;config;get;network;help;defaults;peer;icon;enabled' {
            break
        }
        'wg-quickrs;config;get;network;help;defaults;peer;icon;src' {
            break
        }
        'wg-quickrs;config;get;network;help;defaults;peer;dns' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            break
        }
        'wg-quickrs;config;get;network;help;defaults;peer;dns;enabled' {
            break
        }
        'wg-quickrs;config;get;network;help;defaults;peer;dns;addresses' {
            break
        }
        'wg-quickrs;config;get;network;help;defaults;peer;mtu' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            break
        }
        'wg-quickrs;config;get;network;help;defaults;peer;mtu;enabled' {
            break
        }
        'wg-quickrs;config;get;network;help;defaults;peer;mtu;value' {
            break
        }
        'wg-quickrs;config;get;network;help;defaults;peer;scripts' {
            break
        }
        'wg-quickrs;config;get;network;help;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get default connection persistent keepalive')
            break
        }
        'wg-quickrs;config;get;network;help;defaults;connection;persistent-keepalive' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            break
        }
        'wg-quickrs;config;get;network;help;defaults;connection;persistent-keepalive;enabled' {
            break
        }
        'wg-quickrs;config;get;network;help;defaults;connection;persistent-keepalive;period' {
            break
        }
        'wg-quickrs;config;get;network;help;reservations' {
            [CompletionResult]::new('peer-id', 'peer-id', [CompletionResultType]::ParameterValue, 'Get reservation peer ID')
            [CompletionResult]::new('valid-until', 'valid-until', [CompletionResultType]::ParameterValue, 'Get reservation validity timestamp')
            break
        }
        'wg-quickrs;config;get;network;help;reservations;peer-id' {
            break
        }
        'wg-quickrs;config;get;network;help;reservations;valid-until' {
            break
        }
        'wg-quickrs;config;get;network;help;updated-at' {
            break
        }
        'wg-quickrs;config;get;network;help;help' {
            break
        }
        'wg-quickrs;config;get;help' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Get agent configuration values')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Get network configuration values')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;get;help;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Get web server configuration')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Get VPN configuration')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Get firewall configuration')
            break
        }
        'wg-quickrs;config;get;help;agent;web' {
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get agent web server bind IPv4 address')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Get HTTP configuration')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Get HTTPS configuration')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Get password authentication configuration')
            break
        }
        'wg-quickrs;config;get;help;agent;web;address' {
            break
        }
        'wg-quickrs;config;get;help;agent;web;http' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTP is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTP port')
            break
        }
        'wg-quickrs;config;get;help;agent;web;http;enabled' {
            break
        }
        'wg-quickrs;config;get;help;agent;web;http;port' {
            break
        }
        'wg-quickrs;config;get;help;agent;web;https' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTPS is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Get path to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Get path to TLS private key file for HTTPS')
            break
        }
        'wg-quickrs;config;get;help;agent;web;https;enabled' {
            break
        }
        'wg-quickrs;config;get;help;agent;web;https;port' {
            break
        }
        'wg-quickrs;config;get;help;agent;web;https;tls-cert' {
            break
        }
        'wg-quickrs;config;get;help;agent;web;https;tls-key' {
            break
        }
        'wg-quickrs;config;get;help;agent;web;password' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether password authentication is enabled')
            [CompletionResult]::new('hash', 'hash', [CompletionResultType]::ParameterValue, 'Get password hash')
            break
        }
        'wg-quickrs;config;get;help;agent;web;password;enabled' {
            break
        }
        'wg-quickrs;config;get;help;agent;web;password;hash' {
            break
        }
        'wg-quickrs;config;get;help;agent;vpn' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether VPN server is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get VPN server listening port')
            break
        }
        'wg-quickrs;config;get;help;agent;vpn;enabled' {
            break
        }
        'wg-quickrs;config;get;help;agent;vpn;port' {
            break
        }
        'wg-quickrs;config;get;help;agent;firewall' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether firewall configuration is enabled')
            [CompletionResult]::new('utility', 'utility', [CompletionResultType]::ParameterValue, 'Get the utility used to configure firewall NAT and input rules')
            [CompletionResult]::new('gateway', 'gateway', [CompletionResultType]::ParameterValue, 'Get the gateway used to configure firewall NAT and input rules')
            break
        }
        'wg-quickrs;config;get;help;agent;firewall;enabled' {
            break
        }
        'wg-quickrs;config;get;help;agent;firewall;utility' {
            break
        }
        'wg-quickrs;config;get;help;agent;firewall;gateway' {
            break
        }
        'wg-quickrs;config;get;help;network' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Get network name')
            [CompletionResult]::new('subnet', 'subnet', [CompletionResultType]::ParameterValue, 'Get network subnet')
            [CompletionResult]::new('this-peer', 'this-peer', [CompletionResultType]::ParameterValue, 'Get this peer''s UUID')
            [CompletionResult]::new('peers', 'peers', [CompletionResultType]::ParameterValue, 'Get network peers')
            [CompletionResult]::new('connections', 'connections', [CompletionResultType]::ParameterValue, 'Get network connections')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Get network defaults')
            [CompletionResult]::new('reservations', 'reservations', [CompletionResultType]::ParameterValue, 'Get network reservations')
            [CompletionResult]::new('updated-at', 'updated-at', [CompletionResultType]::ParameterValue, 'Get network last updated timestamp')
            break
        }
        'wg-quickrs;config;get;help;network;name' {
            break
        }
        'wg-quickrs;config;get;help;network;subnet' {
            break
        }
        'wg-quickrs;config;get;help;network;this-peer' {
            break
        }
        'wg-quickrs;config;get;help;network;peers' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Get peer name')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get peer IP address')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Get peer endpoint')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get peer scripts')
            [CompletionResult]::new('private-key', 'private-key', [CompletionResultType]::ParameterValue, 'Get peer private key')
            [CompletionResult]::new('created-at', 'created-at', [CompletionResultType]::ParameterValue, 'Get peer creation timestamp')
            [CompletionResult]::new('updated-at', 'updated-at', [CompletionResultType]::ParameterValue, 'Get peer last updated timestamp')
            break
        }
        'wg-quickrs;config;get;help;network;peers;name' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;address' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;endpoint' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether endpoint is enabled')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get endpoint address')
            break
        }
        'wg-quickrs;config;get;help;network;peers;endpoint;enabled' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;endpoint;address' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;kind' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;icon' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            break
        }
        'wg-quickrs;config;get;help;network;peers;icon;enabled' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;icon;src' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;dns' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            break
        }
        'wg-quickrs;config;get;help;network;peers;dns;enabled' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;dns;addresses' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;mtu' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            break
        }
        'wg-quickrs;config;get;help;network;peers;mtu;enabled' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;mtu;value' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;scripts' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;private-key' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;created-at' {
            break
        }
        'wg-quickrs;config;get;help;network;peers;updated-at' {
            break
        }
        'wg-quickrs;config;get;help;network;connections' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether connection is enabled')
            [CompletionResult]::new('pre-shared-key', 'pre-shared-key', [CompletionResultType]::ParameterValue, 'Get connection pre-shared key')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get connection persistent keepalive')
            [CompletionResult]::new('allowed-ips-a-to-b', 'allowed-ips-a-to-b', [CompletionResultType]::ParameterValue, 'Get allowed IPs from A to B')
            [CompletionResult]::new('allowed-ips-b-to-a', 'allowed-ips-b-to-a', [CompletionResultType]::ParameterValue, 'Get allowed IPs from B to A')
            break
        }
        'wg-quickrs;config;get;help;network;connections;enabled' {
            break
        }
        'wg-quickrs;config;get;help;network;connections;pre-shared-key' {
            break
        }
        'wg-quickrs;config;get;help;network;connections;persistent-keepalive' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            break
        }
        'wg-quickrs;config;get;help;network;connections;persistent-keepalive;enabled' {
            break
        }
        'wg-quickrs;config;get;help;network;connections;persistent-keepalive;period' {
            break
        }
        'wg-quickrs;config;get;help;network;connections;allowed-ips-a-to-b' {
            break
        }
        'wg-quickrs;config;get;help;network;connections;allowed-ips-b-to-a' {
            break
        }
        'wg-quickrs;config;get;help;network;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Get default peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Get default connection configuration')
            break
        }
        'wg-quickrs;config;get;help;network;defaults;peer' {
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get default peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get default peer scripts')
            break
        }
        'wg-quickrs;config;get;help;network;defaults;peer;kind' {
            break
        }
        'wg-quickrs;config;get;help;network;defaults;peer;icon' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            break
        }
        'wg-quickrs;config;get;help;network;defaults;peer;icon;enabled' {
            break
        }
        'wg-quickrs;config;get;help;network;defaults;peer;icon;src' {
            break
        }
        'wg-quickrs;config;get;help;network;defaults;peer;dns' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            break
        }
        'wg-quickrs;config;get;help;network;defaults;peer;dns;enabled' {
            break
        }
        'wg-quickrs;config;get;help;network;defaults;peer;dns;addresses' {
            break
        }
        'wg-quickrs;config;get;help;network;defaults;peer;mtu' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            break
        }
        'wg-quickrs;config;get;help;network;defaults;peer;mtu;enabled' {
            break
        }
        'wg-quickrs;config;get;help;network;defaults;peer;mtu;value' {
            break
        }
        'wg-quickrs;config;get;help;network;defaults;peer;scripts' {
            break
        }
        'wg-quickrs;config;get;help;network;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get default connection persistent keepalive')
            break
        }
        'wg-quickrs;config;get;help;network;defaults;connection;persistent-keepalive' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            break
        }
        'wg-quickrs;config;get;help;network;defaults;connection;persistent-keepalive;enabled' {
            break
        }
        'wg-quickrs;config;get;help;network;defaults;connection;persistent-keepalive;period' {
            break
        }
        'wg-quickrs;config;get;help;network;reservations' {
            [CompletionResult]::new('peer-id', 'peer-id', [CompletionResultType]::ParameterValue, 'Get reservation peer ID')
            [CompletionResult]::new('valid-until', 'valid-until', [CompletionResultType]::ParameterValue, 'Get reservation validity timestamp')
            break
        }
        'wg-quickrs;config;get;help;network;reservations;peer-id' {
            break
        }
        'wg-quickrs;config;get;help;network;reservations;valid-until' {
            break
        }
        'wg-quickrs;config;get;help;network;updated-at' {
            break
        }
        'wg-quickrs;config;get;help;help' {
            break
        }
        'wg-quickrs;config;list' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('peers', 'peers', [CompletionResultType]::ParameterValue, 'List all peers in human-readable format')
            [CompletionResult]::new('connections', 'connections', [CompletionResultType]::ParameterValue, 'List all connections in human-readable format')
            [CompletionResult]::new('reservations', 'reservations', [CompletionResultType]::ParameterValue, 'List all reservations in human-readable format')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;list;peers' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;list;connections' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;list;reservations' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;list;help' {
            [CompletionResult]::new('peers', 'peers', [CompletionResultType]::ParameterValue, 'List all peers in human-readable format')
            [CompletionResult]::new('connections', 'connections', [CompletionResultType]::ParameterValue, 'List all connections in human-readable format')
            [CompletionResult]::new('reservations', 'reservations', [CompletionResultType]::ParameterValue, 'List all reservations in human-readable format')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;list;help;peers' {
            break
        }
        'wg-quickrs;config;list;help;connections' {
            break
        }
        'wg-quickrs;config;list;help;reservations' {
            break
        }
        'wg-quickrs;config;list;help;help' {
            break
        }
        'wg-quickrs;config;remove' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Remove a peer by UUID')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Remove a connection by connection ID')
            [CompletionResult]::new('reservation', 'reservation', [CompletionResultType]::ParameterValue, 'Remove a reservation by IPv4 address')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;remove;peer' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;remove;connection' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;remove;reservation' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'wg-quickrs;config;remove;help' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Remove a peer by UUID')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Remove a connection by connection ID')
            [CompletionResult]::new('reservation', 'reservation', [CompletionResultType]::ParameterValue, 'Remove a reservation by IPv4 address')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;remove;help;peer' {
            break
        }
        'wg-quickrs;config;remove;help;connection' {
            break
        }
        'wg-quickrs;config;remove;help;reservation' {
            break
        }
        'wg-quickrs;config;remove;help;help' {
            break
        }
        'wg-quickrs;config;add' {
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Add a peer to the network')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Add a connection between two peers')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;add;peer' {
            [CompletionResult]::new('--no-prompt', '--no-prompt', [CompletionResultType]::ParameterName, 'no-prompt')
            [CompletionResult]::new('--name', '--name', [CompletionResultType]::ParameterName, 'name')
            [CompletionResult]::new('--address', '--address', [CompletionResultType]::ParameterName, 'address')
            [CompletionResult]::new('--endpoint-enabled', '--endpoint-enabled', [CompletionResultType]::ParameterName, 'endpoint-enabled')
            [CompletionResult]::new('--endpoint-address', '--endpoint-address', [CompletionResultType]::ParameterName, 'endpoint-address')
            [CompletionResult]::new('--kind', '--kind', [CompletionResultType]::ParameterName, 'kind')
            [CompletionResult]::new('--icon-enabled', '--icon-enabled', [CompletionResultType]::ParameterName, 'icon-enabled')
            [CompletionResult]::new('--icon-src', '--icon-src', [CompletionResultType]::ParameterName, 'icon-src')
            [CompletionResult]::new('--dns-enabled', '--dns-enabled', [CompletionResultType]::ParameterName, 'dns-enabled')
            [CompletionResult]::new('--dns-addresses', '--dns-addresses', [CompletionResultType]::ParameterName, 'dns-addresses')
            [CompletionResult]::new('--mtu-enabled', '--mtu-enabled', [CompletionResultType]::ParameterName, 'mtu-enabled')
            [CompletionResult]::new('--mtu-value', '--mtu-value', [CompletionResultType]::ParameterName, 'mtu-value')
            [CompletionResult]::new('--script-pre-up-enabled', '--script-pre-up-enabled', [CompletionResultType]::ParameterName, 'script-pre-up-enabled')
            [CompletionResult]::new('--script-pre-up-line', '--script-pre-up-line', [CompletionResultType]::ParameterName, 'script-pre-up-line')
            [CompletionResult]::new('--script-post-up-enabled', '--script-post-up-enabled', [CompletionResultType]::ParameterName, 'script-post-up-enabled')
            [CompletionResult]::new('--script-post-up-line', '--script-post-up-line', [CompletionResultType]::ParameterName, 'script-post-up-line')
            [CompletionResult]::new('--script-pre-down-enabled', '--script-pre-down-enabled', [CompletionResultType]::ParameterName, 'script-pre-down-enabled')
            [CompletionResult]::new('--script-pre-down-line', '--script-pre-down-line', [CompletionResultType]::ParameterName, 'script-pre-down-line')
            [CompletionResult]::new('--script-post-down-enabled', '--script-post-down-enabled', [CompletionResultType]::ParameterName, 'script-post-down-enabled')
            [CompletionResult]::new('--script-post-down-line', '--script-post-down-line', [CompletionResultType]::ParameterName, 'script-post-down-line')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help (see more with ''--help'')')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help (see more with ''--help'')')
            break
        }
        'wg-quickrs;config;add;connection' {
            [CompletionResult]::new('--no-prompt', '--no-prompt', [CompletionResultType]::ParameterName, 'no-prompt')
            [CompletionResult]::new('--first-peer', '--first-peer', [CompletionResultType]::ParameterName, 'first-peer')
            [CompletionResult]::new('--second-peer', '--second-peer', [CompletionResultType]::ParameterName, 'second-peer')
            [CompletionResult]::new('--persistent-keepalive-enabled', '--persistent-keepalive-enabled', [CompletionResultType]::ParameterName, 'persistent-keepalive-enabled')
            [CompletionResult]::new('--persistent-keepalive-period', '--persistent-keepalive-period', [CompletionResultType]::ParameterName, 'persistent-keepalive-period')
            [CompletionResult]::new('--allowed-ips-first-to-second', '--allowed-ips-first-to-second', [CompletionResultType]::ParameterName, 'allowed-ips-first-to-second')
            [CompletionResult]::new('--allowed-ips-second-to-first', '--allowed-ips-second-to-first', [CompletionResultType]::ParameterName, 'allowed-ips-second-to-first')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help (see more with ''--help'')')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help (see more with ''--help'')')
            break
        }
        'wg-quickrs;config;add;help' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Add a peer to the network')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Add a connection between two peers')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;add;help;peer' {
            break
        }
        'wg-quickrs;config;add;help;connection' {
            break
        }
        'wg-quickrs;config;add;help;help' {
            break
        }
        'wg-quickrs;config;help' {
            [CompletionResult]::new('enable', 'enable', [CompletionResultType]::ParameterValue, 'Enable a configuration option')
            [CompletionResult]::new('disable', 'disable', [CompletionResultType]::ParameterValue, 'Disable a configuration option')
            [CompletionResult]::new('set', 'set', [CompletionResultType]::ParameterValue, 'Set a configuration value')
            [CompletionResult]::new('reset', 'reset', [CompletionResultType]::ParameterValue, 'Reset a configuration option')
            [CompletionResult]::new('get', 'get', [CompletionResultType]::ParameterValue, 'Get a configuration value')
            [CompletionResult]::new('list', 'list', [CompletionResultType]::ParameterValue, 'List network entities in human-readable format')
            [CompletionResult]::new('remove', 'remove', [CompletionResultType]::ParameterValue, 'Remove network entities')
            [CompletionResult]::new('add', 'add', [CompletionResultType]::ParameterValue, 'Add network entities')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;config;help;enable' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Enable agent configuration options')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Enable network configuration options')
            break
        }
        'wg-quickrs;config;help;enable;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Enable web server options')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Enable VPN server')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Enable firewall configuration')
            break
        }
        'wg-quickrs;config;help;enable;agent;web' {
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Enable HTTP on web server')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Enable HTTPS on web server')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Enable password authentication for web server')
            break
        }
        'wg-quickrs;config;help;enable;agent;web;http' {
            break
        }
        'wg-quickrs;config;help;enable;agent;web;https' {
            break
        }
        'wg-quickrs;config;help;enable;agent;web;password' {
            break
        }
        'wg-quickrs;config;help;enable;agent;vpn' {
            break
        }
        'wg-quickrs;config;help;enable;agent;firewall' {
            break
        }
        'wg-quickrs;config;help;enable;network' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Enable peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Enable connection')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Enable default configuration options')
            break
        }
        'wg-quickrs;config;help;enable;network;peer' {
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Enable peer endpoint')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable peer MTU')
            break
        }
        'wg-quickrs;config;help;enable;network;peer;endpoint' {
            break
        }
        'wg-quickrs;config;help;enable;network;peer;icon' {
            break
        }
        'wg-quickrs;config;help;enable;network;peer;dns' {
            break
        }
        'wg-quickrs;config;help;enable;network;peer;mtu' {
            break
        }
        'wg-quickrs;config;help;enable;network;connection' {
            break
        }
        'wg-quickrs;config;help;enable;network;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Enable default peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Enable default connection options')
            break
        }
        'wg-quickrs;config;help;enable;network;defaults;peer' {
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable default peer MTU')
            break
        }
        'wg-quickrs;config;help;enable;network;defaults;peer;icon' {
            break
        }
        'wg-quickrs;config;help;enable;network;defaults;peer;dns' {
            break
        }
        'wg-quickrs;config;help;enable;network;defaults;peer;mtu' {
            break
        }
        'wg-quickrs;config;help;enable;network;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Enable default connection persistent keepalive')
            break
        }
        'wg-quickrs;config;help;enable;network;defaults;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;help;disable' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Disable agent configuration options')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Disable network configuration options')
            break
        }
        'wg-quickrs;config;help;disable;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Disable web server options')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Disable VPN server')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Disable firewall configuration')
            break
        }
        'wg-quickrs;config;help;disable;agent;web' {
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Disable HTTP on web server')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Disable HTTPS on web server')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Disable password authentication for web server')
            break
        }
        'wg-quickrs;config;help;disable;agent;web;http' {
            break
        }
        'wg-quickrs;config;help;disable;agent;web;https' {
            break
        }
        'wg-quickrs;config;help;disable;agent;web;password' {
            break
        }
        'wg-quickrs;config;help;disable;agent;vpn' {
            break
        }
        'wg-quickrs;config;help;disable;agent;firewall' {
            break
        }
        'wg-quickrs;config;help;disable;network' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Disable peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Disable connection')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Disable default configuration options')
            break
        }
        'wg-quickrs;config;help;disable;network;peer' {
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Disable peer endpoint')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable peer MTU')
            break
        }
        'wg-quickrs;config;help;disable;network;peer;endpoint' {
            break
        }
        'wg-quickrs;config;help;disable;network;peer;icon' {
            break
        }
        'wg-quickrs;config;help;disable;network;peer;dns' {
            break
        }
        'wg-quickrs;config;help;disable;network;peer;mtu' {
            break
        }
        'wg-quickrs;config;help;disable;network;connection' {
            break
        }
        'wg-quickrs;config;help;disable;network;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Disable default peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Disable default connection options')
            break
        }
        'wg-quickrs;config;help;disable;network;defaults;peer' {
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable default peer MTU')
            break
        }
        'wg-quickrs;config;help;disable;network;defaults;peer;icon' {
            break
        }
        'wg-quickrs;config;help;disable;network;defaults;peer;dns' {
            break
        }
        'wg-quickrs;config;help;disable;network;defaults;peer;mtu' {
            break
        }
        'wg-quickrs;config;help;disable;network;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Disable default connection persistent keepalive')
            break
        }
        'wg-quickrs;config;help;disable;network;defaults;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;help;set' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Set agent configuration values')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Set network configuration values')
            break
        }
        'wg-quickrs;config;help;set;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Set web server configuration')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Set VPN configuration')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Set firewall configuration')
            break
        }
        'wg-quickrs;config;help;set;agent;web' {
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Set agent web server bind IPv4 address')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Set HTTP configuration')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Set HTTPS configuration')
            break
        }
        'wg-quickrs;config;help;set;agent;web;address' {
            break
        }
        'wg-quickrs;config;help;set;agent;web;http' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTP port')
            break
        }
        'wg-quickrs;config;help;set;agent;web;http;port' {
            break
        }
        'wg-quickrs;config;help;set;agent;web;https' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS')
            break
        }
        'wg-quickrs;config;help;set;agent;web;https;port' {
            break
        }
        'wg-quickrs;config;help;set;agent;web;https;tls-cert' {
            break
        }
        'wg-quickrs;config;help;set;agent;web;https;tls-key' {
            break
        }
        'wg-quickrs;config;help;set;agent;vpn' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set VPN server listening port')
            break
        }
        'wg-quickrs;config;help;set;agent;vpn;port' {
            break
        }
        'wg-quickrs;config;help;set;agent;firewall' {
            [CompletionResult]::new('utility', 'utility', [CompletionResultType]::ParameterValue, 'Set the utility used to configure firewall NAT and input rules (e.g. iptables, pfctl, etc.)')
            [CompletionResult]::new('gateway', 'gateway', [CompletionResultType]::ParameterValue, 'Set the gateway used to configure firewall NAT and input rules (e.g. en0, eth0, etc.)')
            break
        }
        'wg-quickrs;config;help;set;agent;firewall;utility' {
            break
        }
        'wg-quickrs;config;help;set;agent;firewall;gateway' {
            break
        }
        'wg-quickrs;config;help;set;network' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Set network name')
            [CompletionResult]::new('subnet', 'subnet', [CompletionResultType]::ParameterValue, 'Set network subnet')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Set peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Set connection configuration')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Set default configuration')
            break
        }
        'wg-quickrs;config;help;set;network;name' {
            break
        }
        'wg-quickrs;config;help;set;network;subnet' {
            break
        }
        'wg-quickrs;config;help;set;network;peer' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Set peer name')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Set peer address')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Set peer endpoint address')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set peer MTU value')
            break
        }
        'wg-quickrs;config;help;set;network;peer;name' {
            break
        }
        'wg-quickrs;config;help;set;network;peer;address' {
            break
        }
        'wg-quickrs;config;help;set;network;peer;endpoint' {
            break
        }
        'wg-quickrs;config;help;set;network;peer;kind' {
            break
        }
        'wg-quickrs;config;help;set;network;peer;icon' {
            break
        }
        'wg-quickrs;config;help;set;network;peer;dns' {
            break
        }
        'wg-quickrs;config;help;set;network;peer;mtu' {
            break
        }
        'wg-quickrs;config;help;set;network;connection' {
            [CompletionResult]::new('allowed-ips-a-to-b', 'allowed-ips-a-to-b', [CompletionResultType]::ParameterValue, 'Set allowed IPs from peer A to peer B')
            [CompletionResult]::new('allowed-ips-b-to-a', 'allowed-ips-b-to-a', [CompletionResultType]::ParameterValue, 'Set allowed IPs from peer B to peer A')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set persistent keepalive period')
            break
        }
        'wg-quickrs;config;help;set;network;connection;allowed-ips-a-to-b' {
            break
        }
        'wg-quickrs;config;help;set;network;connection;allowed-ips-b-to-a' {
            break
        }
        'wg-quickrs;config;help;set;network;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;help;set;network;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Set default peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Set default connection configuration')
            break
        }
        'wg-quickrs;config;help;set;network;defaults;peer' {
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set default peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set default peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set default peer MTU value')
            break
        }
        'wg-quickrs;config;help;set;network;defaults;peer;kind' {
            break
        }
        'wg-quickrs;config;help;set;network;defaults;peer;icon' {
            break
        }
        'wg-quickrs;config;help;set;network;defaults;peer;dns' {
            break
        }
        'wg-quickrs;config;help;set;network;defaults;peer;mtu' {
            break
        }
        'wg-quickrs;config;help;set;network;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set default connection persistent keepalive period')
            break
        }
        'wg-quickrs;config;help;set;network;defaults;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;config;help;reset' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Reset agent configuration options')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Reset network configuration options')
            break
        }
        'wg-quickrs;config;help;reset;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Reset web server configuration')
            break
        }
        'wg-quickrs;config;help;reset;agent;web' {
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Reset password for web server access')
            break
        }
        'wg-quickrs;config;help;reset;agent;web;password' {
            break
        }
        'wg-quickrs;config;help;reset;network' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Reset peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Reset connection options')
            break
        }
        'wg-quickrs;config;help;reset;network;peer' {
            [CompletionResult]::new('private-key', 'private-key', [CompletionResultType]::ParameterValue, 'Reset peer private key (generates new WireGuard key)')
            break
        }
        'wg-quickrs;config;help;reset;network;peer;private-key' {
            break
        }
        'wg-quickrs;config;help;reset;network;connection' {
            [CompletionResult]::new('pre-shared-key', 'pre-shared-key', [CompletionResultType]::ParameterValue, 'Reset connection pre-shared key (generates new WireGuard key)')
            break
        }
        'wg-quickrs;config;help;reset;network;connection;pre-shared-key' {
            break
        }
        'wg-quickrs;config;help;get' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Get agent configuration values')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Get network configuration values')
            break
        }
        'wg-quickrs;config;help;get;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Get web server configuration')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Get VPN configuration')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Get firewall configuration')
            break
        }
        'wg-quickrs;config;help;get;agent;web' {
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get agent web server bind IPv4 address')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Get HTTP configuration')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Get HTTPS configuration')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Get password authentication configuration')
            break
        }
        'wg-quickrs;config;help;get;agent;web;address' {
            break
        }
        'wg-quickrs;config;help;get;agent;web;http' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTP is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTP port')
            break
        }
        'wg-quickrs;config;help;get;agent;web;http;enabled' {
            break
        }
        'wg-quickrs;config;help;get;agent;web;http;port' {
            break
        }
        'wg-quickrs;config;help;get;agent;web;https' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTPS is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Get path to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Get path to TLS private key file for HTTPS')
            break
        }
        'wg-quickrs;config;help;get;agent;web;https;enabled' {
            break
        }
        'wg-quickrs;config;help;get;agent;web;https;port' {
            break
        }
        'wg-quickrs;config;help;get;agent;web;https;tls-cert' {
            break
        }
        'wg-quickrs;config;help;get;agent;web;https;tls-key' {
            break
        }
        'wg-quickrs;config;help;get;agent;web;password' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether password authentication is enabled')
            [CompletionResult]::new('hash', 'hash', [CompletionResultType]::ParameterValue, 'Get password hash')
            break
        }
        'wg-quickrs;config;help;get;agent;web;password;enabled' {
            break
        }
        'wg-quickrs;config;help;get;agent;web;password;hash' {
            break
        }
        'wg-quickrs;config;help;get;agent;vpn' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether VPN server is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get VPN server listening port')
            break
        }
        'wg-quickrs;config;help;get;agent;vpn;enabled' {
            break
        }
        'wg-quickrs;config;help;get;agent;vpn;port' {
            break
        }
        'wg-quickrs;config;help;get;agent;firewall' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether firewall configuration is enabled')
            [CompletionResult]::new('utility', 'utility', [CompletionResultType]::ParameterValue, 'Get the utility used to configure firewall NAT and input rules')
            [CompletionResult]::new('gateway', 'gateway', [CompletionResultType]::ParameterValue, 'Get the gateway used to configure firewall NAT and input rules')
            break
        }
        'wg-quickrs;config;help;get;agent;firewall;enabled' {
            break
        }
        'wg-quickrs;config;help;get;agent;firewall;utility' {
            break
        }
        'wg-quickrs;config;help;get;agent;firewall;gateway' {
            break
        }
        'wg-quickrs;config;help;get;network' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Get network name')
            [CompletionResult]::new('subnet', 'subnet', [CompletionResultType]::ParameterValue, 'Get network subnet')
            [CompletionResult]::new('this-peer', 'this-peer', [CompletionResultType]::ParameterValue, 'Get this peer''s UUID')
            [CompletionResult]::new('peers', 'peers', [CompletionResultType]::ParameterValue, 'Get network peers')
            [CompletionResult]::new('connections', 'connections', [CompletionResultType]::ParameterValue, 'Get network connections')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Get network defaults')
            [CompletionResult]::new('reservations', 'reservations', [CompletionResultType]::ParameterValue, 'Get network reservations')
            [CompletionResult]::new('updated-at', 'updated-at', [CompletionResultType]::ParameterValue, 'Get network last updated timestamp')
            break
        }
        'wg-quickrs;config;help;get;network;name' {
            break
        }
        'wg-quickrs;config;help;get;network;subnet' {
            break
        }
        'wg-quickrs;config;help;get;network;this-peer' {
            break
        }
        'wg-quickrs;config;help;get;network;peers' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Get peer name')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get peer IP address')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Get peer endpoint')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get peer scripts')
            [CompletionResult]::new('private-key', 'private-key', [CompletionResultType]::ParameterValue, 'Get peer private key')
            [CompletionResult]::new('created-at', 'created-at', [CompletionResultType]::ParameterValue, 'Get peer creation timestamp')
            [CompletionResult]::new('updated-at', 'updated-at', [CompletionResultType]::ParameterValue, 'Get peer last updated timestamp')
            break
        }
        'wg-quickrs;config;help;get;network;peers;name' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;address' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;endpoint' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether endpoint is enabled')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get endpoint address')
            break
        }
        'wg-quickrs;config;help;get;network;peers;endpoint;enabled' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;endpoint;address' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;kind' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;icon' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            break
        }
        'wg-quickrs;config;help;get;network;peers;icon;enabled' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;icon;src' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;dns' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            break
        }
        'wg-quickrs;config;help;get;network;peers;dns;enabled' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;dns;addresses' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;mtu' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            break
        }
        'wg-quickrs;config;help;get;network;peers;mtu;enabled' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;mtu;value' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;scripts' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;private-key' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;created-at' {
            break
        }
        'wg-quickrs;config;help;get;network;peers;updated-at' {
            break
        }
        'wg-quickrs;config;help;get;network;connections' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether connection is enabled')
            [CompletionResult]::new('pre-shared-key', 'pre-shared-key', [CompletionResultType]::ParameterValue, 'Get connection pre-shared key')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get connection persistent keepalive')
            [CompletionResult]::new('allowed-ips-a-to-b', 'allowed-ips-a-to-b', [CompletionResultType]::ParameterValue, 'Get allowed IPs from A to B')
            [CompletionResult]::new('allowed-ips-b-to-a', 'allowed-ips-b-to-a', [CompletionResultType]::ParameterValue, 'Get allowed IPs from B to A')
            break
        }
        'wg-quickrs;config;help;get;network;connections;enabled' {
            break
        }
        'wg-quickrs;config;help;get;network;connections;pre-shared-key' {
            break
        }
        'wg-quickrs;config;help;get;network;connections;persistent-keepalive' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            break
        }
        'wg-quickrs;config;help;get;network;connections;persistent-keepalive;enabled' {
            break
        }
        'wg-quickrs;config;help;get;network;connections;persistent-keepalive;period' {
            break
        }
        'wg-quickrs;config;help;get;network;connections;allowed-ips-a-to-b' {
            break
        }
        'wg-quickrs;config;help;get;network;connections;allowed-ips-b-to-a' {
            break
        }
        'wg-quickrs;config;help;get;network;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Get default peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Get default connection configuration')
            break
        }
        'wg-quickrs;config;help;get;network;defaults;peer' {
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get default peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get default peer scripts')
            break
        }
        'wg-quickrs;config;help;get;network;defaults;peer;kind' {
            break
        }
        'wg-quickrs;config;help;get;network;defaults;peer;icon' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            break
        }
        'wg-quickrs;config;help;get;network;defaults;peer;icon;enabled' {
            break
        }
        'wg-quickrs;config;help;get;network;defaults;peer;icon;src' {
            break
        }
        'wg-quickrs;config;help;get;network;defaults;peer;dns' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            break
        }
        'wg-quickrs;config;help;get;network;defaults;peer;dns;enabled' {
            break
        }
        'wg-quickrs;config;help;get;network;defaults;peer;dns;addresses' {
            break
        }
        'wg-quickrs;config;help;get;network;defaults;peer;mtu' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            break
        }
        'wg-quickrs;config;help;get;network;defaults;peer;mtu;enabled' {
            break
        }
        'wg-quickrs;config;help;get;network;defaults;peer;mtu;value' {
            break
        }
        'wg-quickrs;config;help;get;network;defaults;peer;scripts' {
            break
        }
        'wg-quickrs;config;help;get;network;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get default connection persistent keepalive')
            break
        }
        'wg-quickrs;config;help;get;network;defaults;connection;persistent-keepalive' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            break
        }
        'wg-quickrs;config;help;get;network;defaults;connection;persistent-keepalive;enabled' {
            break
        }
        'wg-quickrs;config;help;get;network;defaults;connection;persistent-keepalive;period' {
            break
        }
        'wg-quickrs;config;help;get;network;reservations' {
            [CompletionResult]::new('peer-id', 'peer-id', [CompletionResultType]::ParameterValue, 'Get reservation peer ID')
            [CompletionResult]::new('valid-until', 'valid-until', [CompletionResultType]::ParameterValue, 'Get reservation validity timestamp')
            break
        }
        'wg-quickrs;config;help;get;network;reservations;peer-id' {
            break
        }
        'wg-quickrs;config;help;get;network;reservations;valid-until' {
            break
        }
        'wg-quickrs;config;help;get;network;updated-at' {
            break
        }
        'wg-quickrs;config;help;list' {
            [CompletionResult]::new('peers', 'peers', [CompletionResultType]::ParameterValue, 'List all peers in human-readable format')
            [CompletionResult]::new('connections', 'connections', [CompletionResultType]::ParameterValue, 'List all connections in human-readable format')
            [CompletionResult]::new('reservations', 'reservations', [CompletionResultType]::ParameterValue, 'List all reservations in human-readable format')
            break
        }
        'wg-quickrs;config;help;list;peers' {
            break
        }
        'wg-quickrs;config;help;list;connections' {
            break
        }
        'wg-quickrs;config;help;list;reservations' {
            break
        }
        'wg-quickrs;config;help;remove' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Remove a peer by UUID')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Remove a connection by connection ID')
            [CompletionResult]::new('reservation', 'reservation', [CompletionResultType]::ParameterValue, 'Remove a reservation by IPv4 address')
            break
        }
        'wg-quickrs;config;help;remove;peer' {
            break
        }
        'wg-quickrs;config;help;remove;connection' {
            break
        }
        'wg-quickrs;config;help;remove;reservation' {
            break
        }
        'wg-quickrs;config;help;add' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Add a peer to the network')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Add a connection between two peers')
            break
        }
        'wg-quickrs;config;help;add;peer' {
            break
        }
        'wg-quickrs;config;help;add;connection' {
            break
        }
        'wg-quickrs;config;help;help' {
            break
        }
        'wg-quickrs;help' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Run agent commands')
            [CompletionResult]::new('config', 'config', [CompletionResultType]::ParameterValue, 'Edit agent configuration options')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'wg-quickrs;help;agent' {
            [CompletionResult]::new('init', 'init', [CompletionResultType]::ParameterValue, 'Initialize the wg-quickrs agent. Configuration options can be filled either by prompts on screen (when no argument is provided) or specified as arguments to this command')
            [CompletionResult]::new('run', 'run', [CompletionResultType]::ParameterValue, 'Run the wg-quickrs agent')
            break
        }
        'wg-quickrs;help;agent;init' {
            break
        }
        'wg-quickrs;help;agent;run' {
            break
        }
        'wg-quickrs;help;config' {
            [CompletionResult]::new('enable', 'enable', [CompletionResultType]::ParameterValue, 'Enable a configuration option')
            [CompletionResult]::new('disable', 'disable', [CompletionResultType]::ParameterValue, 'Disable a configuration option')
            [CompletionResult]::new('set', 'set', [CompletionResultType]::ParameterValue, 'Set a configuration value')
            [CompletionResult]::new('reset', 'reset', [CompletionResultType]::ParameterValue, 'Reset a configuration option')
            [CompletionResult]::new('get', 'get', [CompletionResultType]::ParameterValue, 'Get a configuration value')
            [CompletionResult]::new('list', 'list', [CompletionResultType]::ParameterValue, 'List network entities in human-readable format')
            [CompletionResult]::new('remove', 'remove', [CompletionResultType]::ParameterValue, 'Remove network entities')
            [CompletionResult]::new('add', 'add', [CompletionResultType]::ParameterValue, 'Add network entities')
            break
        }
        'wg-quickrs;help;config;enable' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Enable agent configuration options')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Enable network configuration options')
            break
        }
        'wg-quickrs;help;config;enable;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Enable web server options')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Enable VPN server')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Enable firewall configuration')
            break
        }
        'wg-quickrs;help;config;enable;agent;web' {
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Enable HTTP on web server')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Enable HTTPS on web server')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Enable password authentication for web server')
            break
        }
        'wg-quickrs;help;config;enable;agent;web;http' {
            break
        }
        'wg-quickrs;help;config;enable;agent;web;https' {
            break
        }
        'wg-quickrs;help;config;enable;agent;web;password' {
            break
        }
        'wg-quickrs;help;config;enable;agent;vpn' {
            break
        }
        'wg-quickrs;help;config;enable;agent;firewall' {
            break
        }
        'wg-quickrs;help;config;enable;network' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Enable peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Enable connection')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Enable default configuration options')
            break
        }
        'wg-quickrs;help;config;enable;network;peer' {
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Enable peer endpoint')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable peer MTU')
            break
        }
        'wg-quickrs;help;config;enable;network;peer;endpoint' {
            break
        }
        'wg-quickrs;help;config;enable;network;peer;icon' {
            break
        }
        'wg-quickrs;help;config;enable;network;peer;dns' {
            break
        }
        'wg-quickrs;help;config;enable;network;peer;mtu' {
            break
        }
        'wg-quickrs;help;config;enable;network;connection' {
            break
        }
        'wg-quickrs;help;config;enable;network;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Enable default peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Enable default connection options')
            break
        }
        'wg-quickrs;help;config;enable;network;defaults;peer' {
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Enable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Enable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Enable default peer MTU')
            break
        }
        'wg-quickrs;help;config;enable;network;defaults;peer;icon' {
            break
        }
        'wg-quickrs;help;config;enable;network;defaults;peer;dns' {
            break
        }
        'wg-quickrs;help;config;enable;network;defaults;peer;mtu' {
            break
        }
        'wg-quickrs;help;config;enable;network;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Enable default connection persistent keepalive')
            break
        }
        'wg-quickrs;help;config;enable;network;defaults;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;help;config;disable' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Disable agent configuration options')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Disable network configuration options')
            break
        }
        'wg-quickrs;help;config;disable;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Disable web server options')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Disable VPN server')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Disable firewall configuration')
            break
        }
        'wg-quickrs;help;config;disable;agent;web' {
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Disable HTTP on web server')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Disable HTTPS on web server')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Disable password authentication for web server')
            break
        }
        'wg-quickrs;help;config;disable;agent;web;http' {
            break
        }
        'wg-quickrs;help;config;disable;agent;web;https' {
            break
        }
        'wg-quickrs;help;config;disable;agent;web;password' {
            break
        }
        'wg-quickrs;help;config;disable;agent;vpn' {
            break
        }
        'wg-quickrs;help;config;disable;agent;firewall' {
            break
        }
        'wg-quickrs;help;config;disable;network' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Disable peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Disable connection')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Disable default configuration options')
            break
        }
        'wg-quickrs;help;config;disable;network;peer' {
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Disable peer endpoint')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable peer MTU')
            break
        }
        'wg-quickrs;help;config;disable;network;peer;endpoint' {
            break
        }
        'wg-quickrs;help;config;disable;network;peer;icon' {
            break
        }
        'wg-quickrs;help;config;disable;network;peer;dns' {
            break
        }
        'wg-quickrs;help;config;disable;network;peer;mtu' {
            break
        }
        'wg-quickrs;help;config;disable;network;connection' {
            break
        }
        'wg-quickrs;help;config;disable;network;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Disable default peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Disable default connection options')
            break
        }
        'wg-quickrs;help;config;disable;network;defaults;peer' {
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Disable default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Disable default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Disable default peer MTU')
            break
        }
        'wg-quickrs;help;config;disable;network;defaults;peer;icon' {
            break
        }
        'wg-quickrs;help;config;disable;network;defaults;peer;dns' {
            break
        }
        'wg-quickrs;help;config;disable;network;defaults;peer;mtu' {
            break
        }
        'wg-quickrs;help;config;disable;network;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Disable default connection persistent keepalive')
            break
        }
        'wg-quickrs;help;config;disable;network;defaults;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;help;config;set' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Set agent configuration values')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Set network configuration values')
            break
        }
        'wg-quickrs;help;config;set;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Set web server configuration')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Set VPN configuration')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Set firewall configuration')
            break
        }
        'wg-quickrs;help;config;set;agent;web' {
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Set agent web server bind IPv4 address')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Set HTTP configuration')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Set HTTPS configuration')
            break
        }
        'wg-quickrs;help;config;set;agent;web;address' {
            break
        }
        'wg-quickrs;help;config;set;agent;web;http' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTP port')
            break
        }
        'wg-quickrs;help;config;set;agent;web;http;port' {
            break
        }
        'wg-quickrs;help;config;set;agent;web;https' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Set path (relative to the wg-quickrs config folder) to TLS private key file for HTTPS')
            break
        }
        'wg-quickrs;help;config;set;agent;web;https;port' {
            break
        }
        'wg-quickrs;help;config;set;agent;web;https;tls-cert' {
            break
        }
        'wg-quickrs;help;config;set;agent;web;https;tls-key' {
            break
        }
        'wg-quickrs;help;config;set;agent;vpn' {
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Set VPN server listening port')
            break
        }
        'wg-quickrs;help;config;set;agent;vpn;port' {
            break
        }
        'wg-quickrs;help;config;set;agent;firewall' {
            [CompletionResult]::new('utility', 'utility', [CompletionResultType]::ParameterValue, 'Set the utility used to configure firewall NAT and input rules (e.g. iptables, pfctl, etc.)')
            [CompletionResult]::new('gateway', 'gateway', [CompletionResultType]::ParameterValue, 'Set the gateway used to configure firewall NAT and input rules (e.g. en0, eth0, etc.)')
            break
        }
        'wg-quickrs;help;config;set;agent;firewall;utility' {
            break
        }
        'wg-quickrs;help;config;set;agent;firewall;gateway' {
            break
        }
        'wg-quickrs;help;config;set;network' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Set network name')
            [CompletionResult]::new('subnet', 'subnet', [CompletionResultType]::ParameterValue, 'Set network subnet')
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Set peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Set connection configuration')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Set default configuration')
            break
        }
        'wg-quickrs;help;config;set;network;name' {
            break
        }
        'wg-quickrs;help;config;set;network;subnet' {
            break
        }
        'wg-quickrs;help;config;set;network;peer' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Set peer name')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Set peer address')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Set peer endpoint address')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set peer MTU value')
            break
        }
        'wg-quickrs;help;config;set;network;peer;name' {
            break
        }
        'wg-quickrs;help;config;set;network;peer;address' {
            break
        }
        'wg-quickrs;help;config;set;network;peer;endpoint' {
            break
        }
        'wg-quickrs;help;config;set;network;peer;kind' {
            break
        }
        'wg-quickrs;help;config;set;network;peer;icon' {
            break
        }
        'wg-quickrs;help;config;set;network;peer;dns' {
            break
        }
        'wg-quickrs;help;config;set;network;peer;mtu' {
            break
        }
        'wg-quickrs;help;config;set;network;connection' {
            [CompletionResult]::new('allowed-ips-a-to-b', 'allowed-ips-a-to-b', [CompletionResultType]::ParameterValue, 'Set allowed IPs from peer A to peer B')
            [CompletionResult]::new('allowed-ips-b-to-a', 'allowed-ips-b-to-a', [CompletionResultType]::ParameterValue, 'Set allowed IPs from peer B to peer A')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set persistent keepalive period')
            break
        }
        'wg-quickrs;help;config;set;network;connection;allowed-ips-a-to-b' {
            break
        }
        'wg-quickrs;help;config;set;network;connection;allowed-ips-b-to-a' {
            break
        }
        'wg-quickrs;help;config;set;network;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;help;config;set;network;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Set default peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Set default connection configuration')
            break
        }
        'wg-quickrs;help;config;set;network;defaults;peer' {
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Set default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Set default peer icon source')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Set default peer DNS addresses')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Set default peer MTU value')
            break
        }
        'wg-quickrs;help;config;set;network;defaults;peer;kind' {
            break
        }
        'wg-quickrs;help;config;set;network;defaults;peer;icon' {
            break
        }
        'wg-quickrs;help;config;set;network;defaults;peer;dns' {
            break
        }
        'wg-quickrs;help;config;set;network;defaults;peer;mtu' {
            break
        }
        'wg-quickrs;help;config;set;network;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Set default connection persistent keepalive period')
            break
        }
        'wg-quickrs;help;config;set;network;defaults;connection;persistent-keepalive' {
            break
        }
        'wg-quickrs;help;config;reset' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Reset agent configuration options')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Reset network configuration options')
            break
        }
        'wg-quickrs;help;config;reset;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Reset web server configuration')
            break
        }
        'wg-quickrs;help;config;reset;agent;web' {
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Reset password for web server access')
            break
        }
        'wg-quickrs;help;config;reset;agent;web;password' {
            break
        }
        'wg-quickrs;help;config;reset;network' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Reset peer options')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Reset connection options')
            break
        }
        'wg-quickrs;help;config;reset;network;peer' {
            [CompletionResult]::new('private-key', 'private-key', [CompletionResultType]::ParameterValue, 'Reset peer private key (generates new WireGuard key)')
            break
        }
        'wg-quickrs;help;config;reset;network;peer;private-key' {
            break
        }
        'wg-quickrs;help;config;reset;network;connection' {
            [CompletionResult]::new('pre-shared-key', 'pre-shared-key', [CompletionResultType]::ParameterValue, 'Reset connection pre-shared key (generates new WireGuard key)')
            break
        }
        'wg-quickrs;help;config;reset;network;connection;pre-shared-key' {
            break
        }
        'wg-quickrs;help;config;get' {
            [CompletionResult]::new('agent', 'agent', [CompletionResultType]::ParameterValue, 'Get agent configuration values')
            [CompletionResult]::new('network', 'network', [CompletionResultType]::ParameterValue, 'Get network configuration values')
            break
        }
        'wg-quickrs;help;config;get;agent' {
            [CompletionResult]::new('web', 'web', [CompletionResultType]::ParameterValue, 'Get web server configuration')
            [CompletionResult]::new('vpn', 'vpn', [CompletionResultType]::ParameterValue, 'Get VPN configuration')
            [CompletionResult]::new('firewall', 'firewall', [CompletionResultType]::ParameterValue, 'Get firewall configuration')
            break
        }
        'wg-quickrs;help;config;get;agent;web' {
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get agent web server bind IPv4 address')
            [CompletionResult]::new('http', 'http', [CompletionResultType]::ParameterValue, 'Get HTTP configuration')
            [CompletionResult]::new('https', 'https', [CompletionResultType]::ParameterValue, 'Get HTTPS configuration')
            [CompletionResult]::new('password', 'password', [CompletionResultType]::ParameterValue, 'Get password authentication configuration')
            break
        }
        'wg-quickrs;help;config;get;agent;web;address' {
            break
        }
        'wg-quickrs;help;config;get;agent;web;http' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTP is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTP port')
            break
        }
        'wg-quickrs;help;config;get;agent;web;http;enabled' {
            break
        }
        'wg-quickrs;help;config;get;agent;web;http;port' {
            break
        }
        'wg-quickrs;help;config;get;agent;web;https' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether HTTPS is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get web server HTTPS port')
            [CompletionResult]::new('tls-cert', 'tls-cert', [CompletionResultType]::ParameterValue, 'Get path to TLS certificate file for HTTPS')
            [CompletionResult]::new('tls-key', 'tls-key', [CompletionResultType]::ParameterValue, 'Get path to TLS private key file for HTTPS')
            break
        }
        'wg-quickrs;help;config;get;agent;web;https;enabled' {
            break
        }
        'wg-quickrs;help;config;get;agent;web;https;port' {
            break
        }
        'wg-quickrs;help;config;get;agent;web;https;tls-cert' {
            break
        }
        'wg-quickrs;help;config;get;agent;web;https;tls-key' {
            break
        }
        'wg-quickrs;help;config;get;agent;web;password' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether password authentication is enabled')
            [CompletionResult]::new('hash', 'hash', [CompletionResultType]::ParameterValue, 'Get password hash')
            break
        }
        'wg-quickrs;help;config;get;agent;web;password;enabled' {
            break
        }
        'wg-quickrs;help;config;get;agent;web;password;hash' {
            break
        }
        'wg-quickrs;help;config;get;agent;vpn' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether VPN server is enabled')
            [CompletionResult]::new('port', 'port', [CompletionResultType]::ParameterValue, 'Get VPN server listening port')
            break
        }
        'wg-quickrs;help;config;get;agent;vpn;enabled' {
            break
        }
        'wg-quickrs;help;config;get;agent;vpn;port' {
            break
        }
        'wg-quickrs;help;config;get;agent;firewall' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether firewall configuration is enabled')
            [CompletionResult]::new('utility', 'utility', [CompletionResultType]::ParameterValue, 'Get the utility used to configure firewall NAT and input rules')
            [CompletionResult]::new('gateway', 'gateway', [CompletionResultType]::ParameterValue, 'Get the gateway used to configure firewall NAT and input rules')
            break
        }
        'wg-quickrs;help;config;get;agent;firewall;enabled' {
            break
        }
        'wg-quickrs;help;config;get;agent;firewall;utility' {
            break
        }
        'wg-quickrs;help;config;get;agent;firewall;gateway' {
            break
        }
        'wg-quickrs;help;config;get;network' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Get network name')
            [CompletionResult]::new('subnet', 'subnet', [CompletionResultType]::ParameterValue, 'Get network subnet')
            [CompletionResult]::new('this-peer', 'this-peer', [CompletionResultType]::ParameterValue, 'Get this peer''s UUID')
            [CompletionResult]::new('peers', 'peers', [CompletionResultType]::ParameterValue, 'Get network peers')
            [CompletionResult]::new('connections', 'connections', [CompletionResultType]::ParameterValue, 'Get network connections')
            [CompletionResult]::new('defaults', 'defaults', [CompletionResultType]::ParameterValue, 'Get network defaults')
            [CompletionResult]::new('reservations', 'reservations', [CompletionResultType]::ParameterValue, 'Get network reservations')
            [CompletionResult]::new('updated-at', 'updated-at', [CompletionResultType]::ParameterValue, 'Get network last updated timestamp')
            break
        }
        'wg-quickrs;help;config;get;network;name' {
            break
        }
        'wg-quickrs;help;config;get;network;subnet' {
            break
        }
        'wg-quickrs;help;config;get;network;this-peer' {
            break
        }
        'wg-quickrs;help;config;get;network;peers' {
            [CompletionResult]::new('name', 'name', [CompletionResultType]::ParameterValue, 'Get peer name')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get peer IP address')
            [CompletionResult]::new('endpoint', 'endpoint', [CompletionResultType]::ParameterValue, 'Get peer endpoint')
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get peer scripts')
            [CompletionResult]::new('private-key', 'private-key', [CompletionResultType]::ParameterValue, 'Get peer private key')
            [CompletionResult]::new('created-at', 'created-at', [CompletionResultType]::ParameterValue, 'Get peer creation timestamp')
            [CompletionResult]::new('updated-at', 'updated-at', [CompletionResultType]::ParameterValue, 'Get peer last updated timestamp')
            break
        }
        'wg-quickrs;help;config;get;network;peers;name' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;address' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;endpoint' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether endpoint is enabled')
            [CompletionResult]::new('address', 'address', [CompletionResultType]::ParameterValue, 'Get endpoint address')
            break
        }
        'wg-quickrs;help;config;get;network;peers;endpoint;enabled' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;endpoint;address' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;kind' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;icon' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            break
        }
        'wg-quickrs;help;config;get;network;peers;icon;enabled' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;icon;src' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;dns' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            break
        }
        'wg-quickrs;help;config;get;network;peers;dns;enabled' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;dns;addresses' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;mtu' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            break
        }
        'wg-quickrs;help;config;get;network;peers;mtu;enabled' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;mtu;value' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;scripts' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;private-key' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;created-at' {
            break
        }
        'wg-quickrs;help;config;get;network;peers;updated-at' {
            break
        }
        'wg-quickrs;help;config;get;network;connections' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether connection is enabled')
            [CompletionResult]::new('pre-shared-key', 'pre-shared-key', [CompletionResultType]::ParameterValue, 'Get connection pre-shared key')
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get connection persistent keepalive')
            [CompletionResult]::new('allowed-ips-a-to-b', 'allowed-ips-a-to-b', [CompletionResultType]::ParameterValue, 'Get allowed IPs from A to B')
            [CompletionResult]::new('allowed-ips-b-to-a', 'allowed-ips-b-to-a', [CompletionResultType]::ParameterValue, 'Get allowed IPs from B to A')
            break
        }
        'wg-quickrs;help;config;get;network;connections;enabled' {
            break
        }
        'wg-quickrs;help;config;get;network;connections;pre-shared-key' {
            break
        }
        'wg-quickrs;help;config;get;network;connections;persistent-keepalive' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            break
        }
        'wg-quickrs;help;config;get;network;connections;persistent-keepalive;enabled' {
            break
        }
        'wg-quickrs;help;config;get;network;connections;persistent-keepalive;period' {
            break
        }
        'wg-quickrs;help;config;get;network;connections;allowed-ips-a-to-b' {
            break
        }
        'wg-quickrs;help;config;get;network;connections;allowed-ips-b-to-a' {
            break
        }
        'wg-quickrs;help;config;get;network;defaults' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Get default peer configuration')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Get default connection configuration')
            break
        }
        'wg-quickrs;help;config;get;network;defaults;peer' {
            [CompletionResult]::new('kind', 'kind', [CompletionResultType]::ParameterValue, 'Get default peer kind')
            [CompletionResult]::new('icon', 'icon', [CompletionResultType]::ParameterValue, 'Get default peer icon')
            [CompletionResult]::new('dns', 'dns', [CompletionResultType]::ParameterValue, 'Get default peer DNS')
            [CompletionResult]::new('mtu', 'mtu', [CompletionResultType]::ParameterValue, 'Get default peer MTU')
            [CompletionResult]::new('scripts', 'scripts', [CompletionResultType]::ParameterValue, 'Get default peer scripts')
            break
        }
        'wg-quickrs;help;config;get;network;defaults;peer;kind' {
            break
        }
        'wg-quickrs;help;config;get;network;defaults;peer;icon' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether icon is enabled')
            [CompletionResult]::new('src', 'src', [CompletionResultType]::ParameterValue, 'Get icon source')
            break
        }
        'wg-quickrs;help;config;get;network;defaults;peer;icon;enabled' {
            break
        }
        'wg-quickrs;help;config;get;network;defaults;peer;icon;src' {
            break
        }
        'wg-quickrs;help;config;get;network;defaults;peer;dns' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether DNS is enabled')
            [CompletionResult]::new('addresses', 'addresses', [CompletionResultType]::ParameterValue, 'Get DNS addresses')
            break
        }
        'wg-quickrs;help;config;get;network;defaults;peer;dns;enabled' {
            break
        }
        'wg-quickrs;help;config;get;network;defaults;peer;dns;addresses' {
            break
        }
        'wg-quickrs;help;config;get;network;defaults;peer;mtu' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether MTU is enabled')
            [CompletionResult]::new('value', 'value', [CompletionResultType]::ParameterValue, 'Get MTU value')
            break
        }
        'wg-quickrs;help;config;get;network;defaults;peer;mtu;enabled' {
            break
        }
        'wg-quickrs;help;config;get;network;defaults;peer;mtu;value' {
            break
        }
        'wg-quickrs;help;config;get;network;defaults;peer;scripts' {
            break
        }
        'wg-quickrs;help;config;get;network;defaults;connection' {
            [CompletionResult]::new('persistent-keepalive', 'persistent-keepalive', [CompletionResultType]::ParameterValue, 'Get default connection persistent keepalive')
            break
        }
        'wg-quickrs;help;config;get;network;defaults;connection;persistent-keepalive' {
            [CompletionResult]::new('enabled', 'enabled', [CompletionResultType]::ParameterValue, 'Get whether persistent keepalive is enabled')
            [CompletionResult]::new('period', 'period', [CompletionResultType]::ParameterValue, 'Get persistent keepalive period')
            break
        }
        'wg-quickrs;help;config;get;network;defaults;connection;persistent-keepalive;enabled' {
            break
        }
        'wg-quickrs;help;config;get;network;defaults;connection;persistent-keepalive;period' {
            break
        }
        'wg-quickrs;help;config;get;network;reservations' {
            [CompletionResult]::new('peer-id', 'peer-id', [CompletionResultType]::ParameterValue, 'Get reservation peer ID')
            [CompletionResult]::new('valid-until', 'valid-until', [CompletionResultType]::ParameterValue, 'Get reservation validity timestamp')
            break
        }
        'wg-quickrs;help;config;get;network;reservations;peer-id' {
            break
        }
        'wg-quickrs;help;config;get;network;reservations;valid-until' {
            break
        }
        'wg-quickrs;help;config;get;network;updated-at' {
            break
        }
        'wg-quickrs;help;config;list' {
            [CompletionResult]::new('peers', 'peers', [CompletionResultType]::ParameterValue, 'List all peers in human-readable format')
            [CompletionResult]::new('connections', 'connections', [CompletionResultType]::ParameterValue, 'List all connections in human-readable format')
            [CompletionResult]::new('reservations', 'reservations', [CompletionResultType]::ParameterValue, 'List all reservations in human-readable format')
            break
        }
        'wg-quickrs;help;config;list;peers' {
            break
        }
        'wg-quickrs;help;config;list;connections' {
            break
        }
        'wg-quickrs;help;config;list;reservations' {
            break
        }
        'wg-quickrs;help;config;remove' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Remove a peer by UUID')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Remove a connection by connection ID')
            [CompletionResult]::new('reservation', 'reservation', [CompletionResultType]::ParameterValue, 'Remove a reservation by IPv4 address')
            break
        }
        'wg-quickrs;help;config;remove;peer' {
            break
        }
        'wg-quickrs;help;config;remove;connection' {
            break
        }
        'wg-quickrs;help;config;remove;reservation' {
            break
        }
        'wg-quickrs;help;config;add' {
            [CompletionResult]::new('peer', 'peer', [CompletionResultType]::ParameterValue, 'Add a peer to the network')
            [CompletionResult]::new('connection', 'connection', [CompletionResultType]::ParameterValue, 'Add a connection between two peers')
            break
        }
        'wg-quickrs;help;config;add;peer' {
            break
        }
        'wg-quickrs;help;config;add;connection' {
            break
        }
        'wg-quickrs;help;help' {
            break
        }
    })

    $completions.Where{ $_.CompletionText -like "$wordToComplete*" } |
        Sort-Object -Property ListItemText
}
