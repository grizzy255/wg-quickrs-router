# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_wg_quickrs_global_optspecs
	string join \n v/verbose wg-quickrs-config-folder= h/help
end

function __fish_wg_quickrs_needs_command
	# Figure out if the current invocation already has a command.
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_wg_quickrs_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		# Also print the command, so this can be used to figure out what it is.
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_wg_quickrs_using_subcommand
	set -l cmd (__fish_wg_quickrs_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c wg-quickrs -n "__fish_wg_quickrs_needs_command" -l wg-quickrs-config-folder -r -F
complete -c wg-quickrs -n "__fish_wg_quickrs_needs_command" -s v -l verbose -d 'Increase verbosity level from Info to Debug'
complete -c wg-quickrs -n "__fish_wg_quickrs_needs_command" -s h -l help -d 'Print help'
complete -c wg-quickrs -n "__fish_wg_quickrs_needs_command" -f -a "agent" -d 'Run agent commands'
complete -c wg-quickrs -n "__fish_wg_quickrs_needs_command" -f -a "config" -d 'Edit agent configuration options'
complete -c wg-quickrs -n "__fish_wg_quickrs_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and not __fish_seen_subcommand_from init run help" -s h -l help -d 'Print help'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and not __fish_seen_subcommand_from init run help" -f -a "init" -d 'Initialize the wg-quickrs agent. Configuration options can be filled either by prompts on screen (when no argument is provided) or specified as arguments to this command'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and not __fish_seen_subcommand_from init run help" -f -a "run" -d 'Run the wg-quickrs agent'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and not __fish_seen_subcommand_from init run help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l network-name -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l network-subnet -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-web-address -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-web-http-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-web-http-port -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-web-https-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-web-https-port -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-web-https-tls-cert -r -F
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-web-https-tls-key -r -F
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-web-password-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-web-password -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-vpn-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-vpn-port -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-firewall-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-firewall-utility -r -F
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-firewall-gateway -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-name -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-vpn-internal-address -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-vpn-endpoint -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-kind -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-icon-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-icon-src -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-dns-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-dns-addresses -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-mtu-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-mtu-value -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-script-pre-up-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-script-pre-up-line -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-script-post-up-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-script-post-up-line -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-script-pre-down-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-script-pre-down-line -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-script-post-down-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l agent-peer-script-post-down-line -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-kind -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-icon-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-icon-src -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-dns-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-dns-addresses -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-mtu-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-mtu-value -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-script-pre-up-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-script-pre-up-line -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-script-post-up-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-script-post-up-line -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-script-pre-down-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-script-pre-down-line -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-script-post-down-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-peer-script-post-down-line -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-connection-persistent-keepalive-enabled -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l default-connection-persistent-keepalive-period -r
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -l no-prompt -r -f -a "true\t''
false\t''"
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from init" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from run" -s h -l help -d 'Print help'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from help" -f -a "init" -d 'Initialize the wg-quickrs agent. Configuration options can be filled either by prompts on screen (when no argument is provided) or specified as arguments to this command'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from help" -f -a "run" -d 'Run the wg-quickrs agent'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand agent; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and not __fish_seen_subcommand_from enable disable set reset get list remove add help" -s h -l help -d 'Print help'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and not __fish_seen_subcommand_from enable disable set reset get list remove add help" -f -a "enable" -d 'Enable a configuration option'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and not __fish_seen_subcommand_from enable disable set reset get list remove add help" -f -a "disable" -d 'Disable a configuration option'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and not __fish_seen_subcommand_from enable disable set reset get list remove add help" -f -a "set" -d 'Set a configuration value'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and not __fish_seen_subcommand_from enable disable set reset get list remove add help" -f -a "reset" -d 'Reset a configuration option'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and not __fish_seen_subcommand_from enable disable set reset get list remove add help" -f -a "get" -d 'Get a configuration value'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and not __fish_seen_subcommand_from enable disable set reset get list remove add help" -f -a "list" -d 'List network entities in human-readable format'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and not __fish_seen_subcommand_from enable disable set reset get list remove add help" -f -a "remove" -d 'Remove network entities'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and not __fish_seen_subcommand_from enable disable set reset get list remove add help" -f -a "add" -d 'Add network entities'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and not __fish_seen_subcommand_from enable disable set reset get list remove add help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from enable" -s h -l help -d 'Print help'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from enable" -f -a "agent" -d 'Enable agent configuration options'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from enable" -f -a "network" -d 'Enable network configuration options'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from enable" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from disable" -s h -l help -d 'Print help'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from disable" -f -a "agent" -d 'Disable agent configuration options'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from disable" -f -a "network" -d 'Disable network configuration options'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from disable" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from set" -s h -l help -d 'Print help'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from set" -f -a "agent" -d 'Set agent configuration values'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from set" -f -a "network" -d 'Set network configuration values'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from set" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from reset" -s h -l help -d 'Print help'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from reset" -f -a "agent" -d 'Reset agent configuration options'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from reset" -f -a "network" -d 'Reset network configuration options'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from reset" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from get" -s h -l help -d 'Print help'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from get" -f -a "agent" -d 'Get agent configuration values'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from get" -f -a "network" -d 'Get network configuration values'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from get" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from list" -f -a "peers" -d 'List all peers in human-readable format'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from list" -f -a "connections" -d 'List all connections in human-readable format'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from list" -f -a "reservations" -d 'List all reservations in human-readable format'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from list" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from remove" -s h -l help -d 'Print help'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from remove" -f -a "peer" -d 'Remove a peer by UUID'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from remove" -f -a "connection" -d 'Remove a connection by connection ID'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from remove" -f -a "reservation" -d 'Remove a reservation by IPv4 address'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from remove" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from add" -s h -l help -d 'Print help'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from add" -f -a "peer" -d 'Add a peer to the network'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from add" -f -a "connection" -d 'Add a connection between two peers'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from add" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "enable" -d 'Enable a configuration option'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "disable" -d 'Disable a configuration option'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "set" -d 'Set a configuration value'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "reset" -d 'Reset a configuration option'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "get" -d 'Get a configuration value'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "list" -d 'List network entities in human-readable format'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "remove" -d 'Remove network entities'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "add" -d 'Add network entities'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and not __fish_seen_subcommand_from agent config help" -f -a "agent" -d 'Run agent commands'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and not __fish_seen_subcommand_from agent config help" -f -a "config" -d 'Edit agent configuration options'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and not __fish_seen_subcommand_from agent config help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and __fish_seen_subcommand_from agent" -f -a "init" -d 'Initialize the wg-quickrs agent. Configuration options can be filled either by prompts on screen (when no argument is provided) or specified as arguments to this command'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and __fish_seen_subcommand_from agent" -f -a "run" -d 'Run the wg-quickrs agent'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "enable" -d 'Enable a configuration option'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "disable" -d 'Disable a configuration option'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "set" -d 'Set a configuration value'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "reset" -d 'Reset a configuration option'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "get" -d 'Get a configuration value'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "list" -d 'List network entities in human-readable format'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "remove" -d 'Remove network entities'
complete -c wg-quickrs -n "__fish_wg_quickrs_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "add" -d 'Add network entities'
