_wg-quickrs() {
    local i cur prev opts cmd
    COMPREPLY=()
    if [[ "${BASH_VERSINFO[0]}" -ge 4 ]]; then
        cur="$2"
    else
        cur="${COMP_WORDS[COMP_CWORD]}"
    fi
    prev="$3"
    cmd=""
    opts=""

    for i in "${COMP_WORDS[@]:0:COMP_CWORD}"
    do
        case "${cmd},${i}" in
            ",$1")
                cmd="wg__quickrs"
                ;;
            wg__quickrs,agent)
                cmd="wg__quickrs__agent"
                ;;
            wg__quickrs,config)
                cmd="wg__quickrs__config"
                ;;
            wg__quickrs,help)
                cmd="wg__quickrs__help"
                ;;
            wg__quickrs__agent,help)
                cmd="wg__quickrs__agent__help"
                ;;
            wg__quickrs__agent,init)
                cmd="wg__quickrs__agent__init"
                ;;
            wg__quickrs__agent,run)
                cmd="wg__quickrs__agent__run"
                ;;
            wg__quickrs__agent__help,help)
                cmd="wg__quickrs__agent__help__help"
                ;;
            wg__quickrs__agent__help,init)
                cmd="wg__quickrs__agent__help__init"
                ;;
            wg__quickrs__agent__help,run)
                cmd="wg__quickrs__agent__help__run"
                ;;
            wg__quickrs__config,add)
                cmd="wg__quickrs__config__add"
                ;;
            wg__quickrs__config,disable)
                cmd="wg__quickrs__config__disable"
                ;;
            wg__quickrs__config,enable)
                cmd="wg__quickrs__config__enable"
                ;;
            wg__quickrs__config,get)
                cmd="wg__quickrs__config__get"
                ;;
            wg__quickrs__config,help)
                cmd="wg__quickrs__config__help"
                ;;
            wg__quickrs__config,list)
                cmd="wg__quickrs__config__list"
                ;;
            wg__quickrs__config,remove)
                cmd="wg__quickrs__config__remove"
                ;;
            wg__quickrs__config,reset)
                cmd="wg__quickrs__config__reset"
                ;;
            wg__quickrs__config,set)
                cmd="wg__quickrs__config__set"
                ;;
            wg__quickrs__config__add,connection)
                cmd="wg__quickrs__config__add__connection"
                ;;
            wg__quickrs__config__add,help)
                cmd="wg__quickrs__config__add__help"
                ;;
            wg__quickrs__config__add,peer)
                cmd="wg__quickrs__config__add__peer"
                ;;
            wg__quickrs__config__add__help,connection)
                cmd="wg__quickrs__config__add__help__connection"
                ;;
            wg__quickrs__config__add__help,help)
                cmd="wg__quickrs__config__add__help__help"
                ;;
            wg__quickrs__config__add__help,peer)
                cmd="wg__quickrs__config__add__help__peer"
                ;;
            wg__quickrs__config__disable,agent)
                cmd="wg__quickrs__config__disable__agent"
                ;;
            wg__quickrs__config__disable,help)
                cmd="wg__quickrs__config__disable__help"
                ;;
            wg__quickrs__config__disable,network)
                cmd="wg__quickrs__config__disable__network"
                ;;
            wg__quickrs__config__disable__agent,firewall)
                cmd="wg__quickrs__config__disable__agent__firewall"
                ;;
            wg__quickrs__config__disable__agent,help)
                cmd="wg__quickrs__config__disable__agent__help"
                ;;
            wg__quickrs__config__disable__agent,vpn)
                cmd="wg__quickrs__config__disable__agent__vpn"
                ;;
            wg__quickrs__config__disable__agent,web)
                cmd="wg__quickrs__config__disable__agent__web"
                ;;
            wg__quickrs__config__disable__agent__help,firewall)
                cmd="wg__quickrs__config__disable__agent__help__firewall"
                ;;
            wg__quickrs__config__disable__agent__help,help)
                cmd="wg__quickrs__config__disable__agent__help__help"
                ;;
            wg__quickrs__config__disable__agent__help,vpn)
                cmd="wg__quickrs__config__disable__agent__help__vpn"
                ;;
            wg__quickrs__config__disable__agent__help,web)
                cmd="wg__quickrs__config__disable__agent__help__web"
                ;;
            wg__quickrs__config__disable__agent__help__web,http)
                cmd="wg__quickrs__config__disable__agent__help__web__http"
                ;;
            wg__quickrs__config__disable__agent__help__web,https)
                cmd="wg__quickrs__config__disable__agent__help__web__https"
                ;;
            wg__quickrs__config__disable__agent__help__web,password)
                cmd="wg__quickrs__config__disable__agent__help__web__password"
                ;;
            wg__quickrs__config__disable__agent__web,help)
                cmd="wg__quickrs__config__disable__agent__web__help"
                ;;
            wg__quickrs__config__disable__agent__web,http)
                cmd="wg__quickrs__config__disable__agent__web__http"
                ;;
            wg__quickrs__config__disable__agent__web,https)
                cmd="wg__quickrs__config__disable__agent__web__https"
                ;;
            wg__quickrs__config__disable__agent__web,password)
                cmd="wg__quickrs__config__disable__agent__web__password"
                ;;
            wg__quickrs__config__disable__agent__web__help,help)
                cmd="wg__quickrs__config__disable__agent__web__help__help"
                ;;
            wg__quickrs__config__disable__agent__web__help,http)
                cmd="wg__quickrs__config__disable__agent__web__help__http"
                ;;
            wg__quickrs__config__disable__agent__web__help,https)
                cmd="wg__quickrs__config__disable__agent__web__help__https"
                ;;
            wg__quickrs__config__disable__agent__web__help,password)
                cmd="wg__quickrs__config__disable__agent__web__help__password"
                ;;
            wg__quickrs__config__disable__help,agent)
                cmd="wg__quickrs__config__disable__help__agent"
                ;;
            wg__quickrs__config__disable__help,help)
                cmd="wg__quickrs__config__disable__help__help"
                ;;
            wg__quickrs__config__disable__help,network)
                cmd="wg__quickrs__config__disable__help__network"
                ;;
            wg__quickrs__config__disable__help__agent,firewall)
                cmd="wg__quickrs__config__disable__help__agent__firewall"
                ;;
            wg__quickrs__config__disable__help__agent,vpn)
                cmd="wg__quickrs__config__disable__help__agent__vpn"
                ;;
            wg__quickrs__config__disable__help__agent,web)
                cmd="wg__quickrs__config__disable__help__agent__web"
                ;;
            wg__quickrs__config__disable__help__agent__web,http)
                cmd="wg__quickrs__config__disable__help__agent__web__http"
                ;;
            wg__quickrs__config__disable__help__agent__web,https)
                cmd="wg__quickrs__config__disable__help__agent__web__https"
                ;;
            wg__quickrs__config__disable__help__agent__web,password)
                cmd="wg__quickrs__config__disable__help__agent__web__password"
                ;;
            wg__quickrs__config__disable__help__network,connection)
                cmd="wg__quickrs__config__disable__help__network__connection"
                ;;
            wg__quickrs__config__disable__help__network,defaults)
                cmd="wg__quickrs__config__disable__help__network__defaults"
                ;;
            wg__quickrs__config__disable__help__network,peer)
                cmd="wg__quickrs__config__disable__help__network__peer"
                ;;
            wg__quickrs__config__disable__help__network__defaults,connection)
                cmd="wg__quickrs__config__disable__help__network__defaults__connection"
                ;;
            wg__quickrs__config__disable__help__network__defaults,peer)
                cmd="wg__quickrs__config__disable__help__network__defaults__peer"
                ;;
            wg__quickrs__config__disable__help__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__disable__help__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__disable__help__network__defaults__peer,dns)
                cmd="wg__quickrs__config__disable__help__network__defaults__peer__dns"
                ;;
            wg__quickrs__config__disable__help__network__defaults__peer,icon)
                cmd="wg__quickrs__config__disable__help__network__defaults__peer__icon"
                ;;
            wg__quickrs__config__disable__help__network__defaults__peer,mtu)
                cmd="wg__quickrs__config__disable__help__network__defaults__peer__mtu"
                ;;
            wg__quickrs__config__disable__help__network__peer,dns)
                cmd="wg__quickrs__config__disable__help__network__peer__dns"
                ;;
            wg__quickrs__config__disable__help__network__peer,endpoint)
                cmd="wg__quickrs__config__disable__help__network__peer__endpoint"
                ;;
            wg__quickrs__config__disable__help__network__peer,icon)
                cmd="wg__quickrs__config__disable__help__network__peer__icon"
                ;;
            wg__quickrs__config__disable__help__network__peer,mtu)
                cmd="wg__quickrs__config__disable__help__network__peer__mtu"
                ;;
            wg__quickrs__config__disable__network,connection)
                cmd="wg__quickrs__config__disable__network__connection"
                ;;
            wg__quickrs__config__disable__network,defaults)
                cmd="wg__quickrs__config__disable__network__defaults"
                ;;
            wg__quickrs__config__disable__network,help)
                cmd="wg__quickrs__config__disable__network__help"
                ;;
            wg__quickrs__config__disable__network,peer)
                cmd="wg__quickrs__config__disable__network__peer"
                ;;
            wg__quickrs__config__disable__network__defaults,connection)
                cmd="wg__quickrs__config__disable__network__defaults__connection"
                ;;
            wg__quickrs__config__disable__network__defaults,help)
                cmd="wg__quickrs__config__disable__network__defaults__help"
                ;;
            wg__quickrs__config__disable__network__defaults,peer)
                cmd="wg__quickrs__config__disable__network__defaults__peer"
                ;;
            wg__quickrs__config__disable__network__defaults__connection,help)
                cmd="wg__quickrs__config__disable__network__defaults__connection__help"
                ;;
            wg__quickrs__config__disable__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__disable__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__disable__network__defaults__connection__help,help)
                cmd="wg__quickrs__config__disable__network__defaults__connection__help__help"
                ;;
            wg__quickrs__config__disable__network__defaults__connection__help,persistent-keepalive)
                cmd="wg__quickrs__config__disable__network__defaults__connection__help__persistent__keepalive"
                ;;
            wg__quickrs__config__disable__network__defaults__help,connection)
                cmd="wg__quickrs__config__disable__network__defaults__help__connection"
                ;;
            wg__quickrs__config__disable__network__defaults__help,help)
                cmd="wg__quickrs__config__disable__network__defaults__help__help"
                ;;
            wg__quickrs__config__disable__network__defaults__help,peer)
                cmd="wg__quickrs__config__disable__network__defaults__help__peer"
                ;;
            wg__quickrs__config__disable__network__defaults__help__connection,persistent-keepalive)
                cmd="wg__quickrs__config__disable__network__defaults__help__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__disable__network__defaults__help__peer,dns)
                cmd="wg__quickrs__config__disable__network__defaults__help__peer__dns"
                ;;
            wg__quickrs__config__disable__network__defaults__help__peer,icon)
                cmd="wg__quickrs__config__disable__network__defaults__help__peer__icon"
                ;;
            wg__quickrs__config__disable__network__defaults__help__peer,mtu)
                cmd="wg__quickrs__config__disable__network__defaults__help__peer__mtu"
                ;;
            wg__quickrs__config__disable__network__defaults__peer,dns)
                cmd="wg__quickrs__config__disable__network__defaults__peer__dns"
                ;;
            wg__quickrs__config__disable__network__defaults__peer,help)
                cmd="wg__quickrs__config__disable__network__defaults__peer__help"
                ;;
            wg__quickrs__config__disable__network__defaults__peer,icon)
                cmd="wg__quickrs__config__disable__network__defaults__peer__icon"
                ;;
            wg__quickrs__config__disable__network__defaults__peer,mtu)
                cmd="wg__quickrs__config__disable__network__defaults__peer__mtu"
                ;;
            wg__quickrs__config__disable__network__defaults__peer__help,dns)
                cmd="wg__quickrs__config__disable__network__defaults__peer__help__dns"
                ;;
            wg__quickrs__config__disable__network__defaults__peer__help,help)
                cmd="wg__quickrs__config__disable__network__defaults__peer__help__help"
                ;;
            wg__quickrs__config__disable__network__defaults__peer__help,icon)
                cmd="wg__quickrs__config__disable__network__defaults__peer__help__icon"
                ;;
            wg__quickrs__config__disable__network__defaults__peer__help,mtu)
                cmd="wg__quickrs__config__disable__network__defaults__peer__help__mtu"
                ;;
            wg__quickrs__config__disable__network__help,connection)
                cmd="wg__quickrs__config__disable__network__help__connection"
                ;;
            wg__quickrs__config__disable__network__help,defaults)
                cmd="wg__quickrs__config__disable__network__help__defaults"
                ;;
            wg__quickrs__config__disable__network__help,help)
                cmd="wg__quickrs__config__disable__network__help__help"
                ;;
            wg__quickrs__config__disable__network__help,peer)
                cmd="wg__quickrs__config__disable__network__help__peer"
                ;;
            wg__quickrs__config__disable__network__help__defaults,connection)
                cmd="wg__quickrs__config__disable__network__help__defaults__connection"
                ;;
            wg__quickrs__config__disable__network__help__defaults,peer)
                cmd="wg__quickrs__config__disable__network__help__defaults__peer"
                ;;
            wg__quickrs__config__disable__network__help__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__disable__network__help__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__disable__network__help__defaults__peer,dns)
                cmd="wg__quickrs__config__disable__network__help__defaults__peer__dns"
                ;;
            wg__quickrs__config__disable__network__help__defaults__peer,icon)
                cmd="wg__quickrs__config__disable__network__help__defaults__peer__icon"
                ;;
            wg__quickrs__config__disable__network__help__defaults__peer,mtu)
                cmd="wg__quickrs__config__disable__network__help__defaults__peer__mtu"
                ;;
            wg__quickrs__config__disable__network__help__peer,dns)
                cmd="wg__quickrs__config__disable__network__help__peer__dns"
                ;;
            wg__quickrs__config__disable__network__help__peer,endpoint)
                cmd="wg__quickrs__config__disable__network__help__peer__endpoint"
                ;;
            wg__quickrs__config__disable__network__help__peer,icon)
                cmd="wg__quickrs__config__disable__network__help__peer__icon"
                ;;
            wg__quickrs__config__disable__network__help__peer,mtu)
                cmd="wg__quickrs__config__disable__network__help__peer__mtu"
                ;;
            wg__quickrs__config__disable__network__peer,dns)
                cmd="wg__quickrs__config__disable__network__peer__dns"
                ;;
            wg__quickrs__config__disable__network__peer,endpoint)
                cmd="wg__quickrs__config__disable__network__peer__endpoint"
                ;;
            wg__quickrs__config__disable__network__peer,help)
                cmd="wg__quickrs__config__disable__network__peer__help"
                ;;
            wg__quickrs__config__disable__network__peer,icon)
                cmd="wg__quickrs__config__disable__network__peer__icon"
                ;;
            wg__quickrs__config__disable__network__peer,mtu)
                cmd="wg__quickrs__config__disable__network__peer__mtu"
                ;;
            wg__quickrs__config__disable__network__peer__help,dns)
                cmd="wg__quickrs__config__disable__network__peer__help__dns"
                ;;
            wg__quickrs__config__disable__network__peer__help,endpoint)
                cmd="wg__quickrs__config__disable__network__peer__help__endpoint"
                ;;
            wg__quickrs__config__disable__network__peer__help,help)
                cmd="wg__quickrs__config__disable__network__peer__help__help"
                ;;
            wg__quickrs__config__disable__network__peer__help,icon)
                cmd="wg__quickrs__config__disable__network__peer__help__icon"
                ;;
            wg__quickrs__config__disable__network__peer__help,mtu)
                cmd="wg__quickrs__config__disable__network__peer__help__mtu"
                ;;
            wg__quickrs__config__enable,agent)
                cmd="wg__quickrs__config__enable__agent"
                ;;
            wg__quickrs__config__enable,help)
                cmd="wg__quickrs__config__enable__help"
                ;;
            wg__quickrs__config__enable,network)
                cmd="wg__quickrs__config__enable__network"
                ;;
            wg__quickrs__config__enable__agent,firewall)
                cmd="wg__quickrs__config__enable__agent__firewall"
                ;;
            wg__quickrs__config__enable__agent,help)
                cmd="wg__quickrs__config__enable__agent__help"
                ;;
            wg__quickrs__config__enable__agent,vpn)
                cmd="wg__quickrs__config__enable__agent__vpn"
                ;;
            wg__quickrs__config__enable__agent,web)
                cmd="wg__quickrs__config__enable__agent__web"
                ;;
            wg__quickrs__config__enable__agent__help,firewall)
                cmd="wg__quickrs__config__enable__agent__help__firewall"
                ;;
            wg__quickrs__config__enable__agent__help,help)
                cmd="wg__quickrs__config__enable__agent__help__help"
                ;;
            wg__quickrs__config__enable__agent__help,vpn)
                cmd="wg__quickrs__config__enable__agent__help__vpn"
                ;;
            wg__quickrs__config__enable__agent__help,web)
                cmd="wg__quickrs__config__enable__agent__help__web"
                ;;
            wg__quickrs__config__enable__agent__help__web,http)
                cmd="wg__quickrs__config__enable__agent__help__web__http"
                ;;
            wg__quickrs__config__enable__agent__help__web,https)
                cmd="wg__quickrs__config__enable__agent__help__web__https"
                ;;
            wg__quickrs__config__enable__agent__help__web,password)
                cmd="wg__quickrs__config__enable__agent__help__web__password"
                ;;
            wg__quickrs__config__enable__agent__web,help)
                cmd="wg__quickrs__config__enable__agent__web__help"
                ;;
            wg__quickrs__config__enable__agent__web,http)
                cmd="wg__quickrs__config__enable__agent__web__http"
                ;;
            wg__quickrs__config__enable__agent__web,https)
                cmd="wg__quickrs__config__enable__agent__web__https"
                ;;
            wg__quickrs__config__enable__agent__web,password)
                cmd="wg__quickrs__config__enable__agent__web__password"
                ;;
            wg__quickrs__config__enable__agent__web__help,help)
                cmd="wg__quickrs__config__enable__agent__web__help__help"
                ;;
            wg__quickrs__config__enable__agent__web__help,http)
                cmd="wg__quickrs__config__enable__agent__web__help__http"
                ;;
            wg__quickrs__config__enable__agent__web__help,https)
                cmd="wg__quickrs__config__enable__agent__web__help__https"
                ;;
            wg__quickrs__config__enable__agent__web__help,password)
                cmd="wg__quickrs__config__enable__agent__web__help__password"
                ;;
            wg__quickrs__config__enable__help,agent)
                cmd="wg__quickrs__config__enable__help__agent"
                ;;
            wg__quickrs__config__enable__help,help)
                cmd="wg__quickrs__config__enable__help__help"
                ;;
            wg__quickrs__config__enable__help,network)
                cmd="wg__quickrs__config__enable__help__network"
                ;;
            wg__quickrs__config__enable__help__agent,firewall)
                cmd="wg__quickrs__config__enable__help__agent__firewall"
                ;;
            wg__quickrs__config__enable__help__agent,vpn)
                cmd="wg__quickrs__config__enable__help__agent__vpn"
                ;;
            wg__quickrs__config__enable__help__agent,web)
                cmd="wg__quickrs__config__enable__help__agent__web"
                ;;
            wg__quickrs__config__enable__help__agent__web,http)
                cmd="wg__quickrs__config__enable__help__agent__web__http"
                ;;
            wg__quickrs__config__enable__help__agent__web,https)
                cmd="wg__quickrs__config__enable__help__agent__web__https"
                ;;
            wg__quickrs__config__enable__help__agent__web,password)
                cmd="wg__quickrs__config__enable__help__agent__web__password"
                ;;
            wg__quickrs__config__enable__help__network,connection)
                cmd="wg__quickrs__config__enable__help__network__connection"
                ;;
            wg__quickrs__config__enable__help__network,defaults)
                cmd="wg__quickrs__config__enable__help__network__defaults"
                ;;
            wg__quickrs__config__enable__help__network,peer)
                cmd="wg__quickrs__config__enable__help__network__peer"
                ;;
            wg__quickrs__config__enable__help__network__defaults,connection)
                cmd="wg__quickrs__config__enable__help__network__defaults__connection"
                ;;
            wg__quickrs__config__enable__help__network__defaults,peer)
                cmd="wg__quickrs__config__enable__help__network__defaults__peer"
                ;;
            wg__quickrs__config__enable__help__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__enable__help__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__enable__help__network__defaults__peer,dns)
                cmd="wg__quickrs__config__enable__help__network__defaults__peer__dns"
                ;;
            wg__quickrs__config__enable__help__network__defaults__peer,icon)
                cmd="wg__quickrs__config__enable__help__network__defaults__peer__icon"
                ;;
            wg__quickrs__config__enable__help__network__defaults__peer,mtu)
                cmd="wg__quickrs__config__enable__help__network__defaults__peer__mtu"
                ;;
            wg__quickrs__config__enable__help__network__peer,dns)
                cmd="wg__quickrs__config__enable__help__network__peer__dns"
                ;;
            wg__quickrs__config__enable__help__network__peer,endpoint)
                cmd="wg__quickrs__config__enable__help__network__peer__endpoint"
                ;;
            wg__quickrs__config__enable__help__network__peer,icon)
                cmd="wg__quickrs__config__enable__help__network__peer__icon"
                ;;
            wg__quickrs__config__enable__help__network__peer,mtu)
                cmd="wg__quickrs__config__enable__help__network__peer__mtu"
                ;;
            wg__quickrs__config__enable__network,connection)
                cmd="wg__quickrs__config__enable__network__connection"
                ;;
            wg__quickrs__config__enable__network,defaults)
                cmd="wg__quickrs__config__enable__network__defaults"
                ;;
            wg__quickrs__config__enable__network,help)
                cmd="wg__quickrs__config__enable__network__help"
                ;;
            wg__quickrs__config__enable__network,peer)
                cmd="wg__quickrs__config__enable__network__peer"
                ;;
            wg__quickrs__config__enable__network__defaults,connection)
                cmd="wg__quickrs__config__enable__network__defaults__connection"
                ;;
            wg__quickrs__config__enable__network__defaults,help)
                cmd="wg__quickrs__config__enable__network__defaults__help"
                ;;
            wg__quickrs__config__enable__network__defaults,peer)
                cmd="wg__quickrs__config__enable__network__defaults__peer"
                ;;
            wg__quickrs__config__enable__network__defaults__connection,help)
                cmd="wg__quickrs__config__enable__network__defaults__connection__help"
                ;;
            wg__quickrs__config__enable__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__enable__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__enable__network__defaults__connection__help,help)
                cmd="wg__quickrs__config__enable__network__defaults__connection__help__help"
                ;;
            wg__quickrs__config__enable__network__defaults__connection__help,persistent-keepalive)
                cmd="wg__quickrs__config__enable__network__defaults__connection__help__persistent__keepalive"
                ;;
            wg__quickrs__config__enable__network__defaults__help,connection)
                cmd="wg__quickrs__config__enable__network__defaults__help__connection"
                ;;
            wg__quickrs__config__enable__network__defaults__help,help)
                cmd="wg__quickrs__config__enable__network__defaults__help__help"
                ;;
            wg__quickrs__config__enable__network__defaults__help,peer)
                cmd="wg__quickrs__config__enable__network__defaults__help__peer"
                ;;
            wg__quickrs__config__enable__network__defaults__help__connection,persistent-keepalive)
                cmd="wg__quickrs__config__enable__network__defaults__help__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__enable__network__defaults__help__peer,dns)
                cmd="wg__quickrs__config__enable__network__defaults__help__peer__dns"
                ;;
            wg__quickrs__config__enable__network__defaults__help__peer,icon)
                cmd="wg__quickrs__config__enable__network__defaults__help__peer__icon"
                ;;
            wg__quickrs__config__enable__network__defaults__help__peer,mtu)
                cmd="wg__quickrs__config__enable__network__defaults__help__peer__mtu"
                ;;
            wg__quickrs__config__enable__network__defaults__peer,dns)
                cmd="wg__quickrs__config__enable__network__defaults__peer__dns"
                ;;
            wg__quickrs__config__enable__network__defaults__peer,help)
                cmd="wg__quickrs__config__enable__network__defaults__peer__help"
                ;;
            wg__quickrs__config__enable__network__defaults__peer,icon)
                cmd="wg__quickrs__config__enable__network__defaults__peer__icon"
                ;;
            wg__quickrs__config__enable__network__defaults__peer,mtu)
                cmd="wg__quickrs__config__enable__network__defaults__peer__mtu"
                ;;
            wg__quickrs__config__enable__network__defaults__peer__help,dns)
                cmd="wg__quickrs__config__enable__network__defaults__peer__help__dns"
                ;;
            wg__quickrs__config__enable__network__defaults__peer__help,help)
                cmd="wg__quickrs__config__enable__network__defaults__peer__help__help"
                ;;
            wg__quickrs__config__enable__network__defaults__peer__help,icon)
                cmd="wg__quickrs__config__enable__network__defaults__peer__help__icon"
                ;;
            wg__quickrs__config__enable__network__defaults__peer__help,mtu)
                cmd="wg__quickrs__config__enable__network__defaults__peer__help__mtu"
                ;;
            wg__quickrs__config__enable__network__help,connection)
                cmd="wg__quickrs__config__enable__network__help__connection"
                ;;
            wg__quickrs__config__enable__network__help,defaults)
                cmd="wg__quickrs__config__enable__network__help__defaults"
                ;;
            wg__quickrs__config__enable__network__help,help)
                cmd="wg__quickrs__config__enable__network__help__help"
                ;;
            wg__quickrs__config__enable__network__help,peer)
                cmd="wg__quickrs__config__enable__network__help__peer"
                ;;
            wg__quickrs__config__enable__network__help__defaults,connection)
                cmd="wg__quickrs__config__enable__network__help__defaults__connection"
                ;;
            wg__quickrs__config__enable__network__help__defaults,peer)
                cmd="wg__quickrs__config__enable__network__help__defaults__peer"
                ;;
            wg__quickrs__config__enable__network__help__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__enable__network__help__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__enable__network__help__defaults__peer,dns)
                cmd="wg__quickrs__config__enable__network__help__defaults__peer__dns"
                ;;
            wg__quickrs__config__enable__network__help__defaults__peer,icon)
                cmd="wg__quickrs__config__enable__network__help__defaults__peer__icon"
                ;;
            wg__quickrs__config__enable__network__help__defaults__peer,mtu)
                cmd="wg__quickrs__config__enable__network__help__defaults__peer__mtu"
                ;;
            wg__quickrs__config__enable__network__help__peer,dns)
                cmd="wg__quickrs__config__enable__network__help__peer__dns"
                ;;
            wg__quickrs__config__enable__network__help__peer,endpoint)
                cmd="wg__quickrs__config__enable__network__help__peer__endpoint"
                ;;
            wg__quickrs__config__enable__network__help__peer,icon)
                cmd="wg__quickrs__config__enable__network__help__peer__icon"
                ;;
            wg__quickrs__config__enable__network__help__peer,mtu)
                cmd="wg__quickrs__config__enable__network__help__peer__mtu"
                ;;
            wg__quickrs__config__enable__network__peer,dns)
                cmd="wg__quickrs__config__enable__network__peer__dns"
                ;;
            wg__quickrs__config__enable__network__peer,endpoint)
                cmd="wg__quickrs__config__enable__network__peer__endpoint"
                ;;
            wg__quickrs__config__enable__network__peer,help)
                cmd="wg__quickrs__config__enable__network__peer__help"
                ;;
            wg__quickrs__config__enable__network__peer,icon)
                cmd="wg__quickrs__config__enable__network__peer__icon"
                ;;
            wg__quickrs__config__enable__network__peer,mtu)
                cmd="wg__quickrs__config__enable__network__peer__mtu"
                ;;
            wg__quickrs__config__enable__network__peer__help,dns)
                cmd="wg__quickrs__config__enable__network__peer__help__dns"
                ;;
            wg__quickrs__config__enable__network__peer__help,endpoint)
                cmd="wg__quickrs__config__enable__network__peer__help__endpoint"
                ;;
            wg__quickrs__config__enable__network__peer__help,help)
                cmd="wg__quickrs__config__enable__network__peer__help__help"
                ;;
            wg__quickrs__config__enable__network__peer__help,icon)
                cmd="wg__quickrs__config__enable__network__peer__help__icon"
                ;;
            wg__quickrs__config__enable__network__peer__help,mtu)
                cmd="wg__quickrs__config__enable__network__peer__help__mtu"
                ;;
            wg__quickrs__config__get,agent)
                cmd="wg__quickrs__config__get__agent"
                ;;
            wg__quickrs__config__get,help)
                cmd="wg__quickrs__config__get__help"
                ;;
            wg__quickrs__config__get,network)
                cmd="wg__quickrs__config__get__network"
                ;;
            wg__quickrs__config__get__agent,firewall)
                cmd="wg__quickrs__config__get__agent__firewall"
                ;;
            wg__quickrs__config__get__agent,help)
                cmd="wg__quickrs__config__get__agent__help"
                ;;
            wg__quickrs__config__get__agent,vpn)
                cmd="wg__quickrs__config__get__agent__vpn"
                ;;
            wg__quickrs__config__get__agent,web)
                cmd="wg__quickrs__config__get__agent__web"
                ;;
            wg__quickrs__config__get__agent__firewall,enabled)
                cmd="wg__quickrs__config__get__agent__firewall__enabled"
                ;;
            wg__quickrs__config__get__agent__firewall,gateway)
                cmd="wg__quickrs__config__get__agent__firewall__gateway"
                ;;
            wg__quickrs__config__get__agent__firewall,help)
                cmd="wg__quickrs__config__get__agent__firewall__help"
                ;;
            wg__quickrs__config__get__agent__firewall,utility)
                cmd="wg__quickrs__config__get__agent__firewall__utility"
                ;;
            wg__quickrs__config__get__agent__firewall__help,enabled)
                cmd="wg__quickrs__config__get__agent__firewall__help__enabled"
                ;;
            wg__quickrs__config__get__agent__firewall__help,gateway)
                cmd="wg__quickrs__config__get__agent__firewall__help__gateway"
                ;;
            wg__quickrs__config__get__agent__firewall__help,help)
                cmd="wg__quickrs__config__get__agent__firewall__help__help"
                ;;
            wg__quickrs__config__get__agent__firewall__help,utility)
                cmd="wg__quickrs__config__get__agent__firewall__help__utility"
                ;;
            wg__quickrs__config__get__agent__help,firewall)
                cmd="wg__quickrs__config__get__agent__help__firewall"
                ;;
            wg__quickrs__config__get__agent__help,help)
                cmd="wg__quickrs__config__get__agent__help__help"
                ;;
            wg__quickrs__config__get__agent__help,vpn)
                cmd="wg__quickrs__config__get__agent__help__vpn"
                ;;
            wg__quickrs__config__get__agent__help,web)
                cmd="wg__quickrs__config__get__agent__help__web"
                ;;
            wg__quickrs__config__get__agent__help__firewall,enabled)
                cmd="wg__quickrs__config__get__agent__help__firewall__enabled"
                ;;
            wg__quickrs__config__get__agent__help__firewall,gateway)
                cmd="wg__quickrs__config__get__agent__help__firewall__gateway"
                ;;
            wg__quickrs__config__get__agent__help__firewall,utility)
                cmd="wg__quickrs__config__get__agent__help__firewall__utility"
                ;;
            wg__quickrs__config__get__agent__help__vpn,enabled)
                cmd="wg__quickrs__config__get__agent__help__vpn__enabled"
                ;;
            wg__quickrs__config__get__agent__help__vpn,port)
                cmd="wg__quickrs__config__get__agent__help__vpn__port"
                ;;
            wg__quickrs__config__get__agent__help__web,address)
                cmd="wg__quickrs__config__get__agent__help__web__address"
                ;;
            wg__quickrs__config__get__agent__help__web,http)
                cmd="wg__quickrs__config__get__agent__help__web__http"
                ;;
            wg__quickrs__config__get__agent__help__web,https)
                cmd="wg__quickrs__config__get__agent__help__web__https"
                ;;
            wg__quickrs__config__get__agent__help__web,password)
                cmd="wg__quickrs__config__get__agent__help__web__password"
                ;;
            wg__quickrs__config__get__agent__help__web__http,enabled)
                cmd="wg__quickrs__config__get__agent__help__web__http__enabled"
                ;;
            wg__quickrs__config__get__agent__help__web__http,port)
                cmd="wg__quickrs__config__get__agent__help__web__http__port"
                ;;
            wg__quickrs__config__get__agent__help__web__https,enabled)
                cmd="wg__quickrs__config__get__agent__help__web__https__enabled"
                ;;
            wg__quickrs__config__get__agent__help__web__https,port)
                cmd="wg__quickrs__config__get__agent__help__web__https__port"
                ;;
            wg__quickrs__config__get__agent__help__web__https,tls-cert)
                cmd="wg__quickrs__config__get__agent__help__web__https__tls__cert"
                ;;
            wg__quickrs__config__get__agent__help__web__https,tls-key)
                cmd="wg__quickrs__config__get__agent__help__web__https__tls__key"
                ;;
            wg__quickrs__config__get__agent__help__web__password,enabled)
                cmd="wg__quickrs__config__get__agent__help__web__password__enabled"
                ;;
            wg__quickrs__config__get__agent__help__web__password,hash)
                cmd="wg__quickrs__config__get__agent__help__web__password__hash"
                ;;
            wg__quickrs__config__get__agent__vpn,enabled)
                cmd="wg__quickrs__config__get__agent__vpn__enabled"
                ;;
            wg__quickrs__config__get__agent__vpn,help)
                cmd="wg__quickrs__config__get__agent__vpn__help"
                ;;
            wg__quickrs__config__get__agent__vpn,port)
                cmd="wg__quickrs__config__get__agent__vpn__port"
                ;;
            wg__quickrs__config__get__agent__vpn__help,enabled)
                cmd="wg__quickrs__config__get__agent__vpn__help__enabled"
                ;;
            wg__quickrs__config__get__agent__vpn__help,help)
                cmd="wg__quickrs__config__get__agent__vpn__help__help"
                ;;
            wg__quickrs__config__get__agent__vpn__help,port)
                cmd="wg__quickrs__config__get__agent__vpn__help__port"
                ;;
            wg__quickrs__config__get__agent__web,address)
                cmd="wg__quickrs__config__get__agent__web__address"
                ;;
            wg__quickrs__config__get__agent__web,help)
                cmd="wg__quickrs__config__get__agent__web__help"
                ;;
            wg__quickrs__config__get__agent__web,http)
                cmd="wg__quickrs__config__get__agent__web__http"
                ;;
            wg__quickrs__config__get__agent__web,https)
                cmd="wg__quickrs__config__get__agent__web__https"
                ;;
            wg__quickrs__config__get__agent__web,password)
                cmd="wg__quickrs__config__get__agent__web__password"
                ;;
            wg__quickrs__config__get__agent__web__help,address)
                cmd="wg__quickrs__config__get__agent__web__help__address"
                ;;
            wg__quickrs__config__get__agent__web__help,help)
                cmd="wg__quickrs__config__get__agent__web__help__help"
                ;;
            wg__quickrs__config__get__agent__web__help,http)
                cmd="wg__quickrs__config__get__agent__web__help__http"
                ;;
            wg__quickrs__config__get__agent__web__help,https)
                cmd="wg__quickrs__config__get__agent__web__help__https"
                ;;
            wg__quickrs__config__get__agent__web__help,password)
                cmd="wg__quickrs__config__get__agent__web__help__password"
                ;;
            wg__quickrs__config__get__agent__web__help__http,enabled)
                cmd="wg__quickrs__config__get__agent__web__help__http__enabled"
                ;;
            wg__quickrs__config__get__agent__web__help__http,port)
                cmd="wg__quickrs__config__get__agent__web__help__http__port"
                ;;
            wg__quickrs__config__get__agent__web__help__https,enabled)
                cmd="wg__quickrs__config__get__agent__web__help__https__enabled"
                ;;
            wg__quickrs__config__get__agent__web__help__https,port)
                cmd="wg__quickrs__config__get__agent__web__help__https__port"
                ;;
            wg__quickrs__config__get__agent__web__help__https,tls-cert)
                cmd="wg__quickrs__config__get__agent__web__help__https__tls__cert"
                ;;
            wg__quickrs__config__get__agent__web__help__https,tls-key)
                cmd="wg__quickrs__config__get__agent__web__help__https__tls__key"
                ;;
            wg__quickrs__config__get__agent__web__help__password,enabled)
                cmd="wg__quickrs__config__get__agent__web__help__password__enabled"
                ;;
            wg__quickrs__config__get__agent__web__help__password,hash)
                cmd="wg__quickrs__config__get__agent__web__help__password__hash"
                ;;
            wg__quickrs__config__get__agent__web__http,enabled)
                cmd="wg__quickrs__config__get__agent__web__http__enabled"
                ;;
            wg__quickrs__config__get__agent__web__http,help)
                cmd="wg__quickrs__config__get__agent__web__http__help"
                ;;
            wg__quickrs__config__get__agent__web__http,port)
                cmd="wg__quickrs__config__get__agent__web__http__port"
                ;;
            wg__quickrs__config__get__agent__web__http__help,enabled)
                cmd="wg__quickrs__config__get__agent__web__http__help__enabled"
                ;;
            wg__quickrs__config__get__agent__web__http__help,help)
                cmd="wg__quickrs__config__get__agent__web__http__help__help"
                ;;
            wg__quickrs__config__get__agent__web__http__help,port)
                cmd="wg__quickrs__config__get__agent__web__http__help__port"
                ;;
            wg__quickrs__config__get__agent__web__https,enabled)
                cmd="wg__quickrs__config__get__agent__web__https__enabled"
                ;;
            wg__quickrs__config__get__agent__web__https,help)
                cmd="wg__quickrs__config__get__agent__web__https__help"
                ;;
            wg__quickrs__config__get__agent__web__https,port)
                cmd="wg__quickrs__config__get__agent__web__https__port"
                ;;
            wg__quickrs__config__get__agent__web__https,tls-cert)
                cmd="wg__quickrs__config__get__agent__web__https__tls__cert"
                ;;
            wg__quickrs__config__get__agent__web__https,tls-key)
                cmd="wg__quickrs__config__get__agent__web__https__tls__key"
                ;;
            wg__quickrs__config__get__agent__web__https__help,enabled)
                cmd="wg__quickrs__config__get__agent__web__https__help__enabled"
                ;;
            wg__quickrs__config__get__agent__web__https__help,help)
                cmd="wg__quickrs__config__get__agent__web__https__help__help"
                ;;
            wg__quickrs__config__get__agent__web__https__help,port)
                cmd="wg__quickrs__config__get__agent__web__https__help__port"
                ;;
            wg__quickrs__config__get__agent__web__https__help,tls-cert)
                cmd="wg__quickrs__config__get__agent__web__https__help__tls__cert"
                ;;
            wg__quickrs__config__get__agent__web__https__help,tls-key)
                cmd="wg__quickrs__config__get__agent__web__https__help__tls__key"
                ;;
            wg__quickrs__config__get__agent__web__password,enabled)
                cmd="wg__quickrs__config__get__agent__web__password__enabled"
                ;;
            wg__quickrs__config__get__agent__web__password,hash)
                cmd="wg__quickrs__config__get__agent__web__password__hash"
                ;;
            wg__quickrs__config__get__agent__web__password,help)
                cmd="wg__quickrs__config__get__agent__web__password__help"
                ;;
            wg__quickrs__config__get__agent__web__password__help,enabled)
                cmd="wg__quickrs__config__get__agent__web__password__help__enabled"
                ;;
            wg__quickrs__config__get__agent__web__password__help,hash)
                cmd="wg__quickrs__config__get__agent__web__password__help__hash"
                ;;
            wg__quickrs__config__get__agent__web__password__help,help)
                cmd="wg__quickrs__config__get__agent__web__password__help__help"
                ;;
            wg__quickrs__config__get__help,agent)
                cmd="wg__quickrs__config__get__help__agent"
                ;;
            wg__quickrs__config__get__help,help)
                cmd="wg__quickrs__config__get__help__help"
                ;;
            wg__quickrs__config__get__help,network)
                cmd="wg__quickrs__config__get__help__network"
                ;;
            wg__quickrs__config__get__help__agent,firewall)
                cmd="wg__quickrs__config__get__help__agent__firewall"
                ;;
            wg__quickrs__config__get__help__agent,vpn)
                cmd="wg__quickrs__config__get__help__agent__vpn"
                ;;
            wg__quickrs__config__get__help__agent,web)
                cmd="wg__quickrs__config__get__help__agent__web"
                ;;
            wg__quickrs__config__get__help__agent__firewall,enabled)
                cmd="wg__quickrs__config__get__help__agent__firewall__enabled"
                ;;
            wg__quickrs__config__get__help__agent__firewall,gateway)
                cmd="wg__quickrs__config__get__help__agent__firewall__gateway"
                ;;
            wg__quickrs__config__get__help__agent__firewall,utility)
                cmd="wg__quickrs__config__get__help__agent__firewall__utility"
                ;;
            wg__quickrs__config__get__help__agent__vpn,enabled)
                cmd="wg__quickrs__config__get__help__agent__vpn__enabled"
                ;;
            wg__quickrs__config__get__help__agent__vpn,port)
                cmd="wg__quickrs__config__get__help__agent__vpn__port"
                ;;
            wg__quickrs__config__get__help__agent__web,address)
                cmd="wg__quickrs__config__get__help__agent__web__address"
                ;;
            wg__quickrs__config__get__help__agent__web,http)
                cmd="wg__quickrs__config__get__help__agent__web__http"
                ;;
            wg__quickrs__config__get__help__agent__web,https)
                cmd="wg__quickrs__config__get__help__agent__web__https"
                ;;
            wg__quickrs__config__get__help__agent__web,password)
                cmd="wg__quickrs__config__get__help__agent__web__password"
                ;;
            wg__quickrs__config__get__help__agent__web__http,enabled)
                cmd="wg__quickrs__config__get__help__agent__web__http__enabled"
                ;;
            wg__quickrs__config__get__help__agent__web__http,port)
                cmd="wg__quickrs__config__get__help__agent__web__http__port"
                ;;
            wg__quickrs__config__get__help__agent__web__https,enabled)
                cmd="wg__quickrs__config__get__help__agent__web__https__enabled"
                ;;
            wg__quickrs__config__get__help__agent__web__https,port)
                cmd="wg__quickrs__config__get__help__agent__web__https__port"
                ;;
            wg__quickrs__config__get__help__agent__web__https,tls-cert)
                cmd="wg__quickrs__config__get__help__agent__web__https__tls__cert"
                ;;
            wg__quickrs__config__get__help__agent__web__https,tls-key)
                cmd="wg__quickrs__config__get__help__agent__web__https__tls__key"
                ;;
            wg__quickrs__config__get__help__agent__web__password,enabled)
                cmd="wg__quickrs__config__get__help__agent__web__password__enabled"
                ;;
            wg__quickrs__config__get__help__agent__web__password,hash)
                cmd="wg__quickrs__config__get__help__agent__web__password__hash"
                ;;
            wg__quickrs__config__get__help__network,connections)
                cmd="wg__quickrs__config__get__help__network__connections"
                ;;
            wg__quickrs__config__get__help__network,defaults)
                cmd="wg__quickrs__config__get__help__network__defaults"
                ;;
            wg__quickrs__config__get__help__network,name)
                cmd="wg__quickrs__config__get__help__network__name"
                ;;
            wg__quickrs__config__get__help__network,peers)
                cmd="wg__quickrs__config__get__help__network__peers"
                ;;
            wg__quickrs__config__get__help__network,reservations)
                cmd="wg__quickrs__config__get__help__network__reservations"
                ;;
            wg__quickrs__config__get__help__network,subnet)
                cmd="wg__quickrs__config__get__help__network__subnet"
                ;;
            wg__quickrs__config__get__help__network,this-peer)
                cmd="wg__quickrs__config__get__help__network__this__peer"
                ;;
            wg__quickrs__config__get__help__network,updated-at)
                cmd="wg__quickrs__config__get__help__network__updated__at"
                ;;
            wg__quickrs__config__get__help__network__connections,allowed-ips-a-to-b)
                cmd="wg__quickrs__config__get__help__network__connections__allowed__ips__a__to__b"
                ;;
            wg__quickrs__config__get__help__network__connections,allowed-ips-b-to-a)
                cmd="wg__quickrs__config__get__help__network__connections__allowed__ips__b__to__a"
                ;;
            wg__quickrs__config__get__help__network__connections,enabled)
                cmd="wg__quickrs__config__get__help__network__connections__enabled"
                ;;
            wg__quickrs__config__get__help__network__connections,persistent-keepalive)
                cmd="wg__quickrs__config__get__help__network__connections__persistent__keepalive"
                ;;
            wg__quickrs__config__get__help__network__connections,pre-shared-key)
                cmd="wg__quickrs__config__get__help__network__connections__pre__shared__key"
                ;;
            wg__quickrs__config__get__help__network__connections__persistent__keepalive,enabled)
                cmd="wg__quickrs__config__get__help__network__connections__persistent__keepalive__enabled"
                ;;
            wg__quickrs__config__get__help__network__connections__persistent__keepalive,period)
                cmd="wg__quickrs__config__get__help__network__connections__persistent__keepalive__period"
                ;;
            wg__quickrs__config__get__help__network__defaults,connection)
                cmd="wg__quickrs__config__get__help__network__defaults__connection"
                ;;
            wg__quickrs__config__get__help__network__defaults,peer)
                cmd="wg__quickrs__config__get__help__network__defaults__peer"
                ;;
            wg__quickrs__config__get__help__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__get__help__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__get__help__network__defaults__connection__persistent__keepalive,enabled)
                cmd="wg__quickrs__config__get__help__network__defaults__connection__persistent__keepalive__enabled"
                ;;
            wg__quickrs__config__get__help__network__defaults__connection__persistent__keepalive,period)
                cmd="wg__quickrs__config__get__help__network__defaults__connection__persistent__keepalive__period"
                ;;
            wg__quickrs__config__get__help__network__defaults__peer,dns)
                cmd="wg__quickrs__config__get__help__network__defaults__peer__dns"
                ;;
            wg__quickrs__config__get__help__network__defaults__peer,icon)
                cmd="wg__quickrs__config__get__help__network__defaults__peer__icon"
                ;;
            wg__quickrs__config__get__help__network__defaults__peer,kind)
                cmd="wg__quickrs__config__get__help__network__defaults__peer__kind"
                ;;
            wg__quickrs__config__get__help__network__defaults__peer,mtu)
                cmd="wg__quickrs__config__get__help__network__defaults__peer__mtu"
                ;;
            wg__quickrs__config__get__help__network__defaults__peer,scripts)
                cmd="wg__quickrs__config__get__help__network__defaults__peer__scripts"
                ;;
            wg__quickrs__config__get__help__network__defaults__peer__dns,addresses)
                cmd="wg__quickrs__config__get__help__network__defaults__peer__dns__addresses"
                ;;
            wg__quickrs__config__get__help__network__defaults__peer__dns,enabled)
                cmd="wg__quickrs__config__get__help__network__defaults__peer__dns__enabled"
                ;;
            wg__quickrs__config__get__help__network__defaults__peer__icon,enabled)
                cmd="wg__quickrs__config__get__help__network__defaults__peer__icon__enabled"
                ;;
            wg__quickrs__config__get__help__network__defaults__peer__icon,src)
                cmd="wg__quickrs__config__get__help__network__defaults__peer__icon__src"
                ;;
            wg__quickrs__config__get__help__network__defaults__peer__mtu,enabled)
                cmd="wg__quickrs__config__get__help__network__defaults__peer__mtu__enabled"
                ;;
            wg__quickrs__config__get__help__network__defaults__peer__mtu,value)
                cmd="wg__quickrs__config__get__help__network__defaults__peer__mtu__value"
                ;;
            wg__quickrs__config__get__help__network__peers,address)
                cmd="wg__quickrs__config__get__help__network__peers__address"
                ;;
            wg__quickrs__config__get__help__network__peers,created-at)
                cmd="wg__quickrs__config__get__help__network__peers__created__at"
                ;;
            wg__quickrs__config__get__help__network__peers,dns)
                cmd="wg__quickrs__config__get__help__network__peers__dns"
                ;;
            wg__quickrs__config__get__help__network__peers,endpoint)
                cmd="wg__quickrs__config__get__help__network__peers__endpoint"
                ;;
            wg__quickrs__config__get__help__network__peers,icon)
                cmd="wg__quickrs__config__get__help__network__peers__icon"
                ;;
            wg__quickrs__config__get__help__network__peers,kind)
                cmd="wg__quickrs__config__get__help__network__peers__kind"
                ;;
            wg__quickrs__config__get__help__network__peers,mtu)
                cmd="wg__quickrs__config__get__help__network__peers__mtu"
                ;;
            wg__quickrs__config__get__help__network__peers,name)
                cmd="wg__quickrs__config__get__help__network__peers__name"
                ;;
            wg__quickrs__config__get__help__network__peers,private-key)
                cmd="wg__quickrs__config__get__help__network__peers__private__key"
                ;;
            wg__quickrs__config__get__help__network__peers,scripts)
                cmd="wg__quickrs__config__get__help__network__peers__scripts"
                ;;
            wg__quickrs__config__get__help__network__peers,updated-at)
                cmd="wg__quickrs__config__get__help__network__peers__updated__at"
                ;;
            wg__quickrs__config__get__help__network__peers__dns,addresses)
                cmd="wg__quickrs__config__get__help__network__peers__dns__addresses"
                ;;
            wg__quickrs__config__get__help__network__peers__dns,enabled)
                cmd="wg__quickrs__config__get__help__network__peers__dns__enabled"
                ;;
            wg__quickrs__config__get__help__network__peers__endpoint,address)
                cmd="wg__quickrs__config__get__help__network__peers__endpoint__address"
                ;;
            wg__quickrs__config__get__help__network__peers__endpoint,enabled)
                cmd="wg__quickrs__config__get__help__network__peers__endpoint__enabled"
                ;;
            wg__quickrs__config__get__help__network__peers__icon,enabled)
                cmd="wg__quickrs__config__get__help__network__peers__icon__enabled"
                ;;
            wg__quickrs__config__get__help__network__peers__icon,src)
                cmd="wg__quickrs__config__get__help__network__peers__icon__src"
                ;;
            wg__quickrs__config__get__help__network__peers__mtu,enabled)
                cmd="wg__quickrs__config__get__help__network__peers__mtu__enabled"
                ;;
            wg__quickrs__config__get__help__network__peers__mtu,value)
                cmd="wg__quickrs__config__get__help__network__peers__mtu__value"
                ;;
            wg__quickrs__config__get__help__network__reservations,peer-id)
                cmd="wg__quickrs__config__get__help__network__reservations__peer__id"
                ;;
            wg__quickrs__config__get__help__network__reservations,valid-until)
                cmd="wg__quickrs__config__get__help__network__reservations__valid__until"
                ;;
            wg__quickrs__config__get__network,connections)
                cmd="wg__quickrs__config__get__network__connections"
                ;;
            wg__quickrs__config__get__network,defaults)
                cmd="wg__quickrs__config__get__network__defaults"
                ;;
            wg__quickrs__config__get__network,help)
                cmd="wg__quickrs__config__get__network__help"
                ;;
            wg__quickrs__config__get__network,name)
                cmd="wg__quickrs__config__get__network__name"
                ;;
            wg__quickrs__config__get__network,peers)
                cmd="wg__quickrs__config__get__network__peers"
                ;;
            wg__quickrs__config__get__network,reservations)
                cmd="wg__quickrs__config__get__network__reservations"
                ;;
            wg__quickrs__config__get__network,subnet)
                cmd="wg__quickrs__config__get__network__subnet"
                ;;
            wg__quickrs__config__get__network,this-peer)
                cmd="wg__quickrs__config__get__network__this__peer"
                ;;
            wg__quickrs__config__get__network,updated-at)
                cmd="wg__quickrs__config__get__network__updated__at"
                ;;
            wg__quickrs__config__get__network__connections,allowed-ips-a-to-b)
                cmd="wg__quickrs__config__get__network__connections__allowed__ips__a__to__b"
                ;;
            wg__quickrs__config__get__network__connections,allowed-ips-b-to-a)
                cmd="wg__quickrs__config__get__network__connections__allowed__ips__b__to__a"
                ;;
            wg__quickrs__config__get__network__connections,enabled)
                cmd="wg__quickrs__config__get__network__connections__enabled"
                ;;
            wg__quickrs__config__get__network__connections,help)
                cmd="wg__quickrs__config__get__network__connections__help"
                ;;
            wg__quickrs__config__get__network__connections,persistent-keepalive)
                cmd="wg__quickrs__config__get__network__connections__persistent__keepalive"
                ;;
            wg__quickrs__config__get__network__connections,pre-shared-key)
                cmd="wg__quickrs__config__get__network__connections__pre__shared__key"
                ;;
            wg__quickrs__config__get__network__connections__help,allowed-ips-a-to-b)
                cmd="wg__quickrs__config__get__network__connections__help__allowed__ips__a__to__b"
                ;;
            wg__quickrs__config__get__network__connections__help,allowed-ips-b-to-a)
                cmd="wg__quickrs__config__get__network__connections__help__allowed__ips__b__to__a"
                ;;
            wg__quickrs__config__get__network__connections__help,enabled)
                cmd="wg__quickrs__config__get__network__connections__help__enabled"
                ;;
            wg__quickrs__config__get__network__connections__help,help)
                cmd="wg__quickrs__config__get__network__connections__help__help"
                ;;
            wg__quickrs__config__get__network__connections__help,persistent-keepalive)
                cmd="wg__quickrs__config__get__network__connections__help__persistent__keepalive"
                ;;
            wg__quickrs__config__get__network__connections__help,pre-shared-key)
                cmd="wg__quickrs__config__get__network__connections__help__pre__shared__key"
                ;;
            wg__quickrs__config__get__network__connections__help__persistent__keepalive,enabled)
                cmd="wg__quickrs__config__get__network__connections__help__persistent__keepalive__enabled"
                ;;
            wg__quickrs__config__get__network__connections__help__persistent__keepalive,period)
                cmd="wg__quickrs__config__get__network__connections__help__persistent__keepalive__period"
                ;;
            wg__quickrs__config__get__network__connections__persistent__keepalive,enabled)
                cmd="wg__quickrs__config__get__network__connections__persistent__keepalive__enabled"
                ;;
            wg__quickrs__config__get__network__connections__persistent__keepalive,help)
                cmd="wg__quickrs__config__get__network__connections__persistent__keepalive__help"
                ;;
            wg__quickrs__config__get__network__connections__persistent__keepalive,period)
                cmd="wg__quickrs__config__get__network__connections__persistent__keepalive__period"
                ;;
            wg__quickrs__config__get__network__connections__persistent__keepalive__help,enabled)
                cmd="wg__quickrs__config__get__network__connections__persistent__keepalive__help__enabled"
                ;;
            wg__quickrs__config__get__network__connections__persistent__keepalive__help,help)
                cmd="wg__quickrs__config__get__network__connections__persistent__keepalive__help__help"
                ;;
            wg__quickrs__config__get__network__connections__persistent__keepalive__help,period)
                cmd="wg__quickrs__config__get__network__connections__persistent__keepalive__help__period"
                ;;
            wg__quickrs__config__get__network__defaults,connection)
                cmd="wg__quickrs__config__get__network__defaults__connection"
                ;;
            wg__quickrs__config__get__network__defaults,help)
                cmd="wg__quickrs__config__get__network__defaults__help"
                ;;
            wg__quickrs__config__get__network__defaults,peer)
                cmd="wg__quickrs__config__get__network__defaults__peer"
                ;;
            wg__quickrs__config__get__network__defaults__connection,help)
                cmd="wg__quickrs__config__get__network__defaults__connection__help"
                ;;
            wg__quickrs__config__get__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__get__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__get__network__defaults__connection__help,help)
                cmd="wg__quickrs__config__get__network__defaults__connection__help__help"
                ;;
            wg__quickrs__config__get__network__defaults__connection__help,persistent-keepalive)
                cmd="wg__quickrs__config__get__network__defaults__connection__help__persistent__keepalive"
                ;;
            wg__quickrs__config__get__network__defaults__connection__help__persistent__keepalive,enabled)
                cmd="wg__quickrs__config__get__network__defaults__connection__help__persistent__keepalive__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__connection__help__persistent__keepalive,period)
                cmd="wg__quickrs__config__get__network__defaults__connection__help__persistent__keepalive__period"
                ;;
            wg__quickrs__config__get__network__defaults__connection__persistent__keepalive,enabled)
                cmd="wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__connection__persistent__keepalive,help)
                cmd="wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__help"
                ;;
            wg__quickrs__config__get__network__defaults__connection__persistent__keepalive,period)
                cmd="wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__period"
                ;;
            wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__help,enabled)
                cmd="wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__help__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__help,help)
                cmd="wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__help__help"
                ;;
            wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__help,period)
                cmd="wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__help__period"
                ;;
            wg__quickrs__config__get__network__defaults__help,connection)
                cmd="wg__quickrs__config__get__network__defaults__help__connection"
                ;;
            wg__quickrs__config__get__network__defaults__help,help)
                cmd="wg__quickrs__config__get__network__defaults__help__help"
                ;;
            wg__quickrs__config__get__network__defaults__help,peer)
                cmd="wg__quickrs__config__get__network__defaults__help__peer"
                ;;
            wg__quickrs__config__get__network__defaults__help__connection,persistent-keepalive)
                cmd="wg__quickrs__config__get__network__defaults__help__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__get__network__defaults__help__connection__persistent__keepalive,enabled)
                cmd="wg__quickrs__config__get__network__defaults__help__connection__persistent__keepalive__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__help__connection__persistent__keepalive,period)
                cmd="wg__quickrs__config__get__network__defaults__help__connection__persistent__keepalive__period"
                ;;
            wg__quickrs__config__get__network__defaults__help__peer,dns)
                cmd="wg__quickrs__config__get__network__defaults__help__peer__dns"
                ;;
            wg__quickrs__config__get__network__defaults__help__peer,icon)
                cmd="wg__quickrs__config__get__network__defaults__help__peer__icon"
                ;;
            wg__quickrs__config__get__network__defaults__help__peer,kind)
                cmd="wg__quickrs__config__get__network__defaults__help__peer__kind"
                ;;
            wg__quickrs__config__get__network__defaults__help__peer,mtu)
                cmd="wg__quickrs__config__get__network__defaults__help__peer__mtu"
                ;;
            wg__quickrs__config__get__network__defaults__help__peer,scripts)
                cmd="wg__quickrs__config__get__network__defaults__help__peer__scripts"
                ;;
            wg__quickrs__config__get__network__defaults__help__peer__dns,addresses)
                cmd="wg__quickrs__config__get__network__defaults__help__peer__dns__addresses"
                ;;
            wg__quickrs__config__get__network__defaults__help__peer__dns,enabled)
                cmd="wg__quickrs__config__get__network__defaults__help__peer__dns__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__help__peer__icon,enabled)
                cmd="wg__quickrs__config__get__network__defaults__help__peer__icon__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__help__peer__icon,src)
                cmd="wg__quickrs__config__get__network__defaults__help__peer__icon__src"
                ;;
            wg__quickrs__config__get__network__defaults__help__peer__mtu,enabled)
                cmd="wg__quickrs__config__get__network__defaults__help__peer__mtu__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__help__peer__mtu,value)
                cmd="wg__quickrs__config__get__network__defaults__help__peer__mtu__value"
                ;;
            wg__quickrs__config__get__network__defaults__peer,dns)
                cmd="wg__quickrs__config__get__network__defaults__peer__dns"
                ;;
            wg__quickrs__config__get__network__defaults__peer,help)
                cmd="wg__quickrs__config__get__network__defaults__peer__help"
                ;;
            wg__quickrs__config__get__network__defaults__peer,icon)
                cmd="wg__quickrs__config__get__network__defaults__peer__icon"
                ;;
            wg__quickrs__config__get__network__defaults__peer,kind)
                cmd="wg__quickrs__config__get__network__defaults__peer__kind"
                ;;
            wg__quickrs__config__get__network__defaults__peer,mtu)
                cmd="wg__quickrs__config__get__network__defaults__peer__mtu"
                ;;
            wg__quickrs__config__get__network__defaults__peer,scripts)
                cmd="wg__quickrs__config__get__network__defaults__peer__scripts"
                ;;
            wg__quickrs__config__get__network__defaults__peer__dns,addresses)
                cmd="wg__quickrs__config__get__network__defaults__peer__dns__addresses"
                ;;
            wg__quickrs__config__get__network__defaults__peer__dns,enabled)
                cmd="wg__quickrs__config__get__network__defaults__peer__dns__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__peer__dns,help)
                cmd="wg__quickrs__config__get__network__defaults__peer__dns__help"
                ;;
            wg__quickrs__config__get__network__defaults__peer__dns__help,addresses)
                cmd="wg__quickrs__config__get__network__defaults__peer__dns__help__addresses"
                ;;
            wg__quickrs__config__get__network__defaults__peer__dns__help,enabled)
                cmd="wg__quickrs__config__get__network__defaults__peer__dns__help__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__peer__dns__help,help)
                cmd="wg__quickrs__config__get__network__defaults__peer__dns__help__help"
                ;;
            wg__quickrs__config__get__network__defaults__peer__help,dns)
                cmd="wg__quickrs__config__get__network__defaults__peer__help__dns"
                ;;
            wg__quickrs__config__get__network__defaults__peer__help,help)
                cmd="wg__quickrs__config__get__network__defaults__peer__help__help"
                ;;
            wg__quickrs__config__get__network__defaults__peer__help,icon)
                cmd="wg__quickrs__config__get__network__defaults__peer__help__icon"
                ;;
            wg__quickrs__config__get__network__defaults__peer__help,kind)
                cmd="wg__quickrs__config__get__network__defaults__peer__help__kind"
                ;;
            wg__quickrs__config__get__network__defaults__peer__help,mtu)
                cmd="wg__quickrs__config__get__network__defaults__peer__help__mtu"
                ;;
            wg__quickrs__config__get__network__defaults__peer__help,scripts)
                cmd="wg__quickrs__config__get__network__defaults__peer__help__scripts"
                ;;
            wg__quickrs__config__get__network__defaults__peer__help__dns,addresses)
                cmd="wg__quickrs__config__get__network__defaults__peer__help__dns__addresses"
                ;;
            wg__quickrs__config__get__network__defaults__peer__help__dns,enabled)
                cmd="wg__quickrs__config__get__network__defaults__peer__help__dns__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__peer__help__icon,enabled)
                cmd="wg__quickrs__config__get__network__defaults__peer__help__icon__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__peer__help__icon,src)
                cmd="wg__quickrs__config__get__network__defaults__peer__help__icon__src"
                ;;
            wg__quickrs__config__get__network__defaults__peer__help__mtu,enabled)
                cmd="wg__quickrs__config__get__network__defaults__peer__help__mtu__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__peer__help__mtu,value)
                cmd="wg__quickrs__config__get__network__defaults__peer__help__mtu__value"
                ;;
            wg__quickrs__config__get__network__defaults__peer__icon,enabled)
                cmd="wg__quickrs__config__get__network__defaults__peer__icon__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__peer__icon,help)
                cmd="wg__quickrs__config__get__network__defaults__peer__icon__help"
                ;;
            wg__quickrs__config__get__network__defaults__peer__icon,src)
                cmd="wg__quickrs__config__get__network__defaults__peer__icon__src"
                ;;
            wg__quickrs__config__get__network__defaults__peer__icon__help,enabled)
                cmd="wg__quickrs__config__get__network__defaults__peer__icon__help__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__peer__icon__help,help)
                cmd="wg__quickrs__config__get__network__defaults__peer__icon__help__help"
                ;;
            wg__quickrs__config__get__network__defaults__peer__icon__help,src)
                cmd="wg__quickrs__config__get__network__defaults__peer__icon__help__src"
                ;;
            wg__quickrs__config__get__network__defaults__peer__mtu,enabled)
                cmd="wg__quickrs__config__get__network__defaults__peer__mtu__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__peer__mtu,help)
                cmd="wg__quickrs__config__get__network__defaults__peer__mtu__help"
                ;;
            wg__quickrs__config__get__network__defaults__peer__mtu,value)
                cmd="wg__quickrs__config__get__network__defaults__peer__mtu__value"
                ;;
            wg__quickrs__config__get__network__defaults__peer__mtu__help,enabled)
                cmd="wg__quickrs__config__get__network__defaults__peer__mtu__help__enabled"
                ;;
            wg__quickrs__config__get__network__defaults__peer__mtu__help,help)
                cmd="wg__quickrs__config__get__network__defaults__peer__mtu__help__help"
                ;;
            wg__quickrs__config__get__network__defaults__peer__mtu__help,value)
                cmd="wg__quickrs__config__get__network__defaults__peer__mtu__help__value"
                ;;
            wg__quickrs__config__get__network__help,connections)
                cmd="wg__quickrs__config__get__network__help__connections"
                ;;
            wg__quickrs__config__get__network__help,defaults)
                cmd="wg__quickrs__config__get__network__help__defaults"
                ;;
            wg__quickrs__config__get__network__help,help)
                cmd="wg__quickrs__config__get__network__help__help"
                ;;
            wg__quickrs__config__get__network__help,name)
                cmd="wg__quickrs__config__get__network__help__name"
                ;;
            wg__quickrs__config__get__network__help,peers)
                cmd="wg__quickrs__config__get__network__help__peers"
                ;;
            wg__quickrs__config__get__network__help,reservations)
                cmd="wg__quickrs__config__get__network__help__reservations"
                ;;
            wg__quickrs__config__get__network__help,subnet)
                cmd="wg__quickrs__config__get__network__help__subnet"
                ;;
            wg__quickrs__config__get__network__help,this-peer)
                cmd="wg__quickrs__config__get__network__help__this__peer"
                ;;
            wg__quickrs__config__get__network__help,updated-at)
                cmd="wg__quickrs__config__get__network__help__updated__at"
                ;;
            wg__quickrs__config__get__network__help__connections,allowed-ips-a-to-b)
                cmd="wg__quickrs__config__get__network__help__connections__allowed__ips__a__to__b"
                ;;
            wg__quickrs__config__get__network__help__connections,allowed-ips-b-to-a)
                cmd="wg__quickrs__config__get__network__help__connections__allowed__ips__b__to__a"
                ;;
            wg__quickrs__config__get__network__help__connections,enabled)
                cmd="wg__quickrs__config__get__network__help__connections__enabled"
                ;;
            wg__quickrs__config__get__network__help__connections,persistent-keepalive)
                cmd="wg__quickrs__config__get__network__help__connections__persistent__keepalive"
                ;;
            wg__quickrs__config__get__network__help__connections,pre-shared-key)
                cmd="wg__quickrs__config__get__network__help__connections__pre__shared__key"
                ;;
            wg__quickrs__config__get__network__help__connections__persistent__keepalive,enabled)
                cmd="wg__quickrs__config__get__network__help__connections__persistent__keepalive__enabled"
                ;;
            wg__quickrs__config__get__network__help__connections__persistent__keepalive,period)
                cmd="wg__quickrs__config__get__network__help__connections__persistent__keepalive__period"
                ;;
            wg__quickrs__config__get__network__help__defaults,connection)
                cmd="wg__quickrs__config__get__network__help__defaults__connection"
                ;;
            wg__quickrs__config__get__network__help__defaults,peer)
                cmd="wg__quickrs__config__get__network__help__defaults__peer"
                ;;
            wg__quickrs__config__get__network__help__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__get__network__help__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__get__network__help__defaults__connection__persistent__keepalive,enabled)
                cmd="wg__quickrs__config__get__network__help__defaults__connection__persistent__keepalive__enabled"
                ;;
            wg__quickrs__config__get__network__help__defaults__connection__persistent__keepalive,period)
                cmd="wg__quickrs__config__get__network__help__defaults__connection__persistent__keepalive__period"
                ;;
            wg__quickrs__config__get__network__help__defaults__peer,dns)
                cmd="wg__quickrs__config__get__network__help__defaults__peer__dns"
                ;;
            wg__quickrs__config__get__network__help__defaults__peer,icon)
                cmd="wg__quickrs__config__get__network__help__defaults__peer__icon"
                ;;
            wg__quickrs__config__get__network__help__defaults__peer,kind)
                cmd="wg__quickrs__config__get__network__help__defaults__peer__kind"
                ;;
            wg__quickrs__config__get__network__help__defaults__peer,mtu)
                cmd="wg__quickrs__config__get__network__help__defaults__peer__mtu"
                ;;
            wg__quickrs__config__get__network__help__defaults__peer,scripts)
                cmd="wg__quickrs__config__get__network__help__defaults__peer__scripts"
                ;;
            wg__quickrs__config__get__network__help__defaults__peer__dns,addresses)
                cmd="wg__quickrs__config__get__network__help__defaults__peer__dns__addresses"
                ;;
            wg__quickrs__config__get__network__help__defaults__peer__dns,enabled)
                cmd="wg__quickrs__config__get__network__help__defaults__peer__dns__enabled"
                ;;
            wg__quickrs__config__get__network__help__defaults__peer__icon,enabled)
                cmd="wg__quickrs__config__get__network__help__defaults__peer__icon__enabled"
                ;;
            wg__quickrs__config__get__network__help__defaults__peer__icon,src)
                cmd="wg__quickrs__config__get__network__help__defaults__peer__icon__src"
                ;;
            wg__quickrs__config__get__network__help__defaults__peer__mtu,enabled)
                cmd="wg__quickrs__config__get__network__help__defaults__peer__mtu__enabled"
                ;;
            wg__quickrs__config__get__network__help__defaults__peer__mtu,value)
                cmd="wg__quickrs__config__get__network__help__defaults__peer__mtu__value"
                ;;
            wg__quickrs__config__get__network__help__peers,address)
                cmd="wg__quickrs__config__get__network__help__peers__address"
                ;;
            wg__quickrs__config__get__network__help__peers,created-at)
                cmd="wg__quickrs__config__get__network__help__peers__created__at"
                ;;
            wg__quickrs__config__get__network__help__peers,dns)
                cmd="wg__quickrs__config__get__network__help__peers__dns"
                ;;
            wg__quickrs__config__get__network__help__peers,endpoint)
                cmd="wg__quickrs__config__get__network__help__peers__endpoint"
                ;;
            wg__quickrs__config__get__network__help__peers,icon)
                cmd="wg__quickrs__config__get__network__help__peers__icon"
                ;;
            wg__quickrs__config__get__network__help__peers,kind)
                cmd="wg__quickrs__config__get__network__help__peers__kind"
                ;;
            wg__quickrs__config__get__network__help__peers,mtu)
                cmd="wg__quickrs__config__get__network__help__peers__mtu"
                ;;
            wg__quickrs__config__get__network__help__peers,name)
                cmd="wg__quickrs__config__get__network__help__peers__name"
                ;;
            wg__quickrs__config__get__network__help__peers,private-key)
                cmd="wg__quickrs__config__get__network__help__peers__private__key"
                ;;
            wg__quickrs__config__get__network__help__peers,scripts)
                cmd="wg__quickrs__config__get__network__help__peers__scripts"
                ;;
            wg__quickrs__config__get__network__help__peers,updated-at)
                cmd="wg__quickrs__config__get__network__help__peers__updated__at"
                ;;
            wg__quickrs__config__get__network__help__peers__dns,addresses)
                cmd="wg__quickrs__config__get__network__help__peers__dns__addresses"
                ;;
            wg__quickrs__config__get__network__help__peers__dns,enabled)
                cmd="wg__quickrs__config__get__network__help__peers__dns__enabled"
                ;;
            wg__quickrs__config__get__network__help__peers__endpoint,address)
                cmd="wg__quickrs__config__get__network__help__peers__endpoint__address"
                ;;
            wg__quickrs__config__get__network__help__peers__endpoint,enabled)
                cmd="wg__quickrs__config__get__network__help__peers__endpoint__enabled"
                ;;
            wg__quickrs__config__get__network__help__peers__icon,enabled)
                cmd="wg__quickrs__config__get__network__help__peers__icon__enabled"
                ;;
            wg__quickrs__config__get__network__help__peers__icon,src)
                cmd="wg__quickrs__config__get__network__help__peers__icon__src"
                ;;
            wg__quickrs__config__get__network__help__peers__mtu,enabled)
                cmd="wg__quickrs__config__get__network__help__peers__mtu__enabled"
                ;;
            wg__quickrs__config__get__network__help__peers__mtu,value)
                cmd="wg__quickrs__config__get__network__help__peers__mtu__value"
                ;;
            wg__quickrs__config__get__network__help__reservations,peer-id)
                cmd="wg__quickrs__config__get__network__help__reservations__peer__id"
                ;;
            wg__quickrs__config__get__network__help__reservations,valid-until)
                cmd="wg__quickrs__config__get__network__help__reservations__valid__until"
                ;;
            wg__quickrs__config__get__network__peers,address)
                cmd="wg__quickrs__config__get__network__peers__address"
                ;;
            wg__quickrs__config__get__network__peers,created-at)
                cmd="wg__quickrs__config__get__network__peers__created__at"
                ;;
            wg__quickrs__config__get__network__peers,dns)
                cmd="wg__quickrs__config__get__network__peers__dns"
                ;;
            wg__quickrs__config__get__network__peers,endpoint)
                cmd="wg__quickrs__config__get__network__peers__endpoint"
                ;;
            wg__quickrs__config__get__network__peers,help)
                cmd="wg__quickrs__config__get__network__peers__help"
                ;;
            wg__quickrs__config__get__network__peers,icon)
                cmd="wg__quickrs__config__get__network__peers__icon"
                ;;
            wg__quickrs__config__get__network__peers,kind)
                cmd="wg__quickrs__config__get__network__peers__kind"
                ;;
            wg__quickrs__config__get__network__peers,mtu)
                cmd="wg__quickrs__config__get__network__peers__mtu"
                ;;
            wg__quickrs__config__get__network__peers,name)
                cmd="wg__quickrs__config__get__network__peers__name"
                ;;
            wg__quickrs__config__get__network__peers,private-key)
                cmd="wg__quickrs__config__get__network__peers__private__key"
                ;;
            wg__quickrs__config__get__network__peers,scripts)
                cmd="wg__quickrs__config__get__network__peers__scripts"
                ;;
            wg__quickrs__config__get__network__peers,updated-at)
                cmd="wg__quickrs__config__get__network__peers__updated__at"
                ;;
            wg__quickrs__config__get__network__peers__dns,addresses)
                cmd="wg__quickrs__config__get__network__peers__dns__addresses"
                ;;
            wg__quickrs__config__get__network__peers__dns,enabled)
                cmd="wg__quickrs__config__get__network__peers__dns__enabled"
                ;;
            wg__quickrs__config__get__network__peers__dns,help)
                cmd="wg__quickrs__config__get__network__peers__dns__help"
                ;;
            wg__quickrs__config__get__network__peers__dns__help,addresses)
                cmd="wg__quickrs__config__get__network__peers__dns__help__addresses"
                ;;
            wg__quickrs__config__get__network__peers__dns__help,enabled)
                cmd="wg__quickrs__config__get__network__peers__dns__help__enabled"
                ;;
            wg__quickrs__config__get__network__peers__dns__help,help)
                cmd="wg__quickrs__config__get__network__peers__dns__help__help"
                ;;
            wg__quickrs__config__get__network__peers__endpoint,address)
                cmd="wg__quickrs__config__get__network__peers__endpoint__address"
                ;;
            wg__quickrs__config__get__network__peers__endpoint,enabled)
                cmd="wg__quickrs__config__get__network__peers__endpoint__enabled"
                ;;
            wg__quickrs__config__get__network__peers__endpoint,help)
                cmd="wg__quickrs__config__get__network__peers__endpoint__help"
                ;;
            wg__quickrs__config__get__network__peers__endpoint__help,address)
                cmd="wg__quickrs__config__get__network__peers__endpoint__help__address"
                ;;
            wg__quickrs__config__get__network__peers__endpoint__help,enabled)
                cmd="wg__quickrs__config__get__network__peers__endpoint__help__enabled"
                ;;
            wg__quickrs__config__get__network__peers__endpoint__help,help)
                cmd="wg__quickrs__config__get__network__peers__endpoint__help__help"
                ;;
            wg__quickrs__config__get__network__peers__help,address)
                cmd="wg__quickrs__config__get__network__peers__help__address"
                ;;
            wg__quickrs__config__get__network__peers__help,created-at)
                cmd="wg__quickrs__config__get__network__peers__help__created__at"
                ;;
            wg__quickrs__config__get__network__peers__help,dns)
                cmd="wg__quickrs__config__get__network__peers__help__dns"
                ;;
            wg__quickrs__config__get__network__peers__help,endpoint)
                cmd="wg__quickrs__config__get__network__peers__help__endpoint"
                ;;
            wg__quickrs__config__get__network__peers__help,help)
                cmd="wg__quickrs__config__get__network__peers__help__help"
                ;;
            wg__quickrs__config__get__network__peers__help,icon)
                cmd="wg__quickrs__config__get__network__peers__help__icon"
                ;;
            wg__quickrs__config__get__network__peers__help,kind)
                cmd="wg__quickrs__config__get__network__peers__help__kind"
                ;;
            wg__quickrs__config__get__network__peers__help,mtu)
                cmd="wg__quickrs__config__get__network__peers__help__mtu"
                ;;
            wg__quickrs__config__get__network__peers__help,name)
                cmd="wg__quickrs__config__get__network__peers__help__name"
                ;;
            wg__quickrs__config__get__network__peers__help,private-key)
                cmd="wg__quickrs__config__get__network__peers__help__private__key"
                ;;
            wg__quickrs__config__get__network__peers__help,scripts)
                cmd="wg__quickrs__config__get__network__peers__help__scripts"
                ;;
            wg__quickrs__config__get__network__peers__help,updated-at)
                cmd="wg__quickrs__config__get__network__peers__help__updated__at"
                ;;
            wg__quickrs__config__get__network__peers__help__dns,addresses)
                cmd="wg__quickrs__config__get__network__peers__help__dns__addresses"
                ;;
            wg__quickrs__config__get__network__peers__help__dns,enabled)
                cmd="wg__quickrs__config__get__network__peers__help__dns__enabled"
                ;;
            wg__quickrs__config__get__network__peers__help__endpoint,address)
                cmd="wg__quickrs__config__get__network__peers__help__endpoint__address"
                ;;
            wg__quickrs__config__get__network__peers__help__endpoint,enabled)
                cmd="wg__quickrs__config__get__network__peers__help__endpoint__enabled"
                ;;
            wg__quickrs__config__get__network__peers__help__icon,enabled)
                cmd="wg__quickrs__config__get__network__peers__help__icon__enabled"
                ;;
            wg__quickrs__config__get__network__peers__help__icon,src)
                cmd="wg__quickrs__config__get__network__peers__help__icon__src"
                ;;
            wg__quickrs__config__get__network__peers__help__mtu,enabled)
                cmd="wg__quickrs__config__get__network__peers__help__mtu__enabled"
                ;;
            wg__quickrs__config__get__network__peers__help__mtu,value)
                cmd="wg__quickrs__config__get__network__peers__help__mtu__value"
                ;;
            wg__quickrs__config__get__network__peers__icon,enabled)
                cmd="wg__quickrs__config__get__network__peers__icon__enabled"
                ;;
            wg__quickrs__config__get__network__peers__icon,help)
                cmd="wg__quickrs__config__get__network__peers__icon__help"
                ;;
            wg__quickrs__config__get__network__peers__icon,src)
                cmd="wg__quickrs__config__get__network__peers__icon__src"
                ;;
            wg__quickrs__config__get__network__peers__icon__help,enabled)
                cmd="wg__quickrs__config__get__network__peers__icon__help__enabled"
                ;;
            wg__quickrs__config__get__network__peers__icon__help,help)
                cmd="wg__quickrs__config__get__network__peers__icon__help__help"
                ;;
            wg__quickrs__config__get__network__peers__icon__help,src)
                cmd="wg__quickrs__config__get__network__peers__icon__help__src"
                ;;
            wg__quickrs__config__get__network__peers__mtu,enabled)
                cmd="wg__quickrs__config__get__network__peers__mtu__enabled"
                ;;
            wg__quickrs__config__get__network__peers__mtu,help)
                cmd="wg__quickrs__config__get__network__peers__mtu__help"
                ;;
            wg__quickrs__config__get__network__peers__mtu,value)
                cmd="wg__quickrs__config__get__network__peers__mtu__value"
                ;;
            wg__quickrs__config__get__network__peers__mtu__help,enabled)
                cmd="wg__quickrs__config__get__network__peers__mtu__help__enabled"
                ;;
            wg__quickrs__config__get__network__peers__mtu__help,help)
                cmd="wg__quickrs__config__get__network__peers__mtu__help__help"
                ;;
            wg__quickrs__config__get__network__peers__mtu__help,value)
                cmd="wg__quickrs__config__get__network__peers__mtu__help__value"
                ;;
            wg__quickrs__config__get__network__reservations,help)
                cmd="wg__quickrs__config__get__network__reservations__help"
                ;;
            wg__quickrs__config__get__network__reservations,peer-id)
                cmd="wg__quickrs__config__get__network__reservations__peer__id"
                ;;
            wg__quickrs__config__get__network__reservations,valid-until)
                cmd="wg__quickrs__config__get__network__reservations__valid__until"
                ;;
            wg__quickrs__config__get__network__reservations__help,help)
                cmd="wg__quickrs__config__get__network__reservations__help__help"
                ;;
            wg__quickrs__config__get__network__reservations__help,peer-id)
                cmd="wg__quickrs__config__get__network__reservations__help__peer__id"
                ;;
            wg__quickrs__config__get__network__reservations__help,valid-until)
                cmd="wg__quickrs__config__get__network__reservations__help__valid__until"
                ;;
            wg__quickrs__config__help,add)
                cmd="wg__quickrs__config__help__add"
                ;;
            wg__quickrs__config__help,disable)
                cmd="wg__quickrs__config__help__disable"
                ;;
            wg__quickrs__config__help,enable)
                cmd="wg__quickrs__config__help__enable"
                ;;
            wg__quickrs__config__help,get)
                cmd="wg__quickrs__config__help__get"
                ;;
            wg__quickrs__config__help,help)
                cmd="wg__quickrs__config__help__help"
                ;;
            wg__quickrs__config__help,list)
                cmd="wg__quickrs__config__help__list"
                ;;
            wg__quickrs__config__help,remove)
                cmd="wg__quickrs__config__help__remove"
                ;;
            wg__quickrs__config__help,reset)
                cmd="wg__quickrs__config__help__reset"
                ;;
            wg__quickrs__config__help,set)
                cmd="wg__quickrs__config__help__set"
                ;;
            wg__quickrs__config__help__add,connection)
                cmd="wg__quickrs__config__help__add__connection"
                ;;
            wg__quickrs__config__help__add,peer)
                cmd="wg__quickrs__config__help__add__peer"
                ;;
            wg__quickrs__config__help__disable,agent)
                cmd="wg__quickrs__config__help__disable__agent"
                ;;
            wg__quickrs__config__help__disable,network)
                cmd="wg__quickrs__config__help__disable__network"
                ;;
            wg__quickrs__config__help__disable__agent,firewall)
                cmd="wg__quickrs__config__help__disable__agent__firewall"
                ;;
            wg__quickrs__config__help__disable__agent,vpn)
                cmd="wg__quickrs__config__help__disable__agent__vpn"
                ;;
            wg__quickrs__config__help__disable__agent,web)
                cmd="wg__quickrs__config__help__disable__agent__web"
                ;;
            wg__quickrs__config__help__disable__agent__web,http)
                cmd="wg__quickrs__config__help__disable__agent__web__http"
                ;;
            wg__quickrs__config__help__disable__agent__web,https)
                cmd="wg__quickrs__config__help__disable__agent__web__https"
                ;;
            wg__quickrs__config__help__disable__agent__web,password)
                cmd="wg__quickrs__config__help__disable__agent__web__password"
                ;;
            wg__quickrs__config__help__disable__network,connection)
                cmd="wg__quickrs__config__help__disable__network__connection"
                ;;
            wg__quickrs__config__help__disable__network,defaults)
                cmd="wg__quickrs__config__help__disable__network__defaults"
                ;;
            wg__quickrs__config__help__disable__network,peer)
                cmd="wg__quickrs__config__help__disable__network__peer"
                ;;
            wg__quickrs__config__help__disable__network__defaults,connection)
                cmd="wg__quickrs__config__help__disable__network__defaults__connection"
                ;;
            wg__quickrs__config__help__disable__network__defaults,peer)
                cmd="wg__quickrs__config__help__disable__network__defaults__peer"
                ;;
            wg__quickrs__config__help__disable__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__help__disable__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__help__disable__network__defaults__peer,dns)
                cmd="wg__quickrs__config__help__disable__network__defaults__peer__dns"
                ;;
            wg__quickrs__config__help__disable__network__defaults__peer,icon)
                cmd="wg__quickrs__config__help__disable__network__defaults__peer__icon"
                ;;
            wg__quickrs__config__help__disable__network__defaults__peer,mtu)
                cmd="wg__quickrs__config__help__disable__network__defaults__peer__mtu"
                ;;
            wg__quickrs__config__help__disable__network__peer,dns)
                cmd="wg__quickrs__config__help__disable__network__peer__dns"
                ;;
            wg__quickrs__config__help__disable__network__peer,endpoint)
                cmd="wg__quickrs__config__help__disable__network__peer__endpoint"
                ;;
            wg__quickrs__config__help__disable__network__peer,icon)
                cmd="wg__quickrs__config__help__disable__network__peer__icon"
                ;;
            wg__quickrs__config__help__disable__network__peer,mtu)
                cmd="wg__quickrs__config__help__disable__network__peer__mtu"
                ;;
            wg__quickrs__config__help__enable,agent)
                cmd="wg__quickrs__config__help__enable__agent"
                ;;
            wg__quickrs__config__help__enable,network)
                cmd="wg__quickrs__config__help__enable__network"
                ;;
            wg__quickrs__config__help__enable__agent,firewall)
                cmd="wg__quickrs__config__help__enable__agent__firewall"
                ;;
            wg__quickrs__config__help__enable__agent,vpn)
                cmd="wg__quickrs__config__help__enable__agent__vpn"
                ;;
            wg__quickrs__config__help__enable__agent,web)
                cmd="wg__quickrs__config__help__enable__agent__web"
                ;;
            wg__quickrs__config__help__enable__agent__web,http)
                cmd="wg__quickrs__config__help__enable__agent__web__http"
                ;;
            wg__quickrs__config__help__enable__agent__web,https)
                cmd="wg__quickrs__config__help__enable__agent__web__https"
                ;;
            wg__quickrs__config__help__enable__agent__web,password)
                cmd="wg__quickrs__config__help__enable__agent__web__password"
                ;;
            wg__quickrs__config__help__enable__network,connection)
                cmd="wg__quickrs__config__help__enable__network__connection"
                ;;
            wg__quickrs__config__help__enable__network,defaults)
                cmd="wg__quickrs__config__help__enable__network__defaults"
                ;;
            wg__quickrs__config__help__enable__network,peer)
                cmd="wg__quickrs__config__help__enable__network__peer"
                ;;
            wg__quickrs__config__help__enable__network__defaults,connection)
                cmd="wg__quickrs__config__help__enable__network__defaults__connection"
                ;;
            wg__quickrs__config__help__enable__network__defaults,peer)
                cmd="wg__quickrs__config__help__enable__network__defaults__peer"
                ;;
            wg__quickrs__config__help__enable__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__help__enable__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__help__enable__network__defaults__peer,dns)
                cmd="wg__quickrs__config__help__enable__network__defaults__peer__dns"
                ;;
            wg__quickrs__config__help__enable__network__defaults__peer,icon)
                cmd="wg__quickrs__config__help__enable__network__defaults__peer__icon"
                ;;
            wg__quickrs__config__help__enable__network__defaults__peer,mtu)
                cmd="wg__quickrs__config__help__enable__network__defaults__peer__mtu"
                ;;
            wg__quickrs__config__help__enable__network__peer,dns)
                cmd="wg__quickrs__config__help__enable__network__peer__dns"
                ;;
            wg__quickrs__config__help__enable__network__peer,endpoint)
                cmd="wg__quickrs__config__help__enable__network__peer__endpoint"
                ;;
            wg__quickrs__config__help__enable__network__peer,icon)
                cmd="wg__quickrs__config__help__enable__network__peer__icon"
                ;;
            wg__quickrs__config__help__enable__network__peer,mtu)
                cmd="wg__quickrs__config__help__enable__network__peer__mtu"
                ;;
            wg__quickrs__config__help__get,agent)
                cmd="wg__quickrs__config__help__get__agent"
                ;;
            wg__quickrs__config__help__get,network)
                cmd="wg__quickrs__config__help__get__network"
                ;;
            wg__quickrs__config__help__get__agent,firewall)
                cmd="wg__quickrs__config__help__get__agent__firewall"
                ;;
            wg__quickrs__config__help__get__agent,vpn)
                cmd="wg__quickrs__config__help__get__agent__vpn"
                ;;
            wg__quickrs__config__help__get__agent,web)
                cmd="wg__quickrs__config__help__get__agent__web"
                ;;
            wg__quickrs__config__help__get__agent__firewall,enabled)
                cmd="wg__quickrs__config__help__get__agent__firewall__enabled"
                ;;
            wg__quickrs__config__help__get__agent__firewall,gateway)
                cmd="wg__quickrs__config__help__get__agent__firewall__gateway"
                ;;
            wg__quickrs__config__help__get__agent__firewall,utility)
                cmd="wg__quickrs__config__help__get__agent__firewall__utility"
                ;;
            wg__quickrs__config__help__get__agent__vpn,enabled)
                cmd="wg__quickrs__config__help__get__agent__vpn__enabled"
                ;;
            wg__quickrs__config__help__get__agent__vpn,port)
                cmd="wg__quickrs__config__help__get__agent__vpn__port"
                ;;
            wg__quickrs__config__help__get__agent__web,address)
                cmd="wg__quickrs__config__help__get__agent__web__address"
                ;;
            wg__quickrs__config__help__get__agent__web,http)
                cmd="wg__quickrs__config__help__get__agent__web__http"
                ;;
            wg__quickrs__config__help__get__agent__web,https)
                cmd="wg__quickrs__config__help__get__agent__web__https"
                ;;
            wg__quickrs__config__help__get__agent__web,password)
                cmd="wg__quickrs__config__help__get__agent__web__password"
                ;;
            wg__quickrs__config__help__get__agent__web__http,enabled)
                cmd="wg__quickrs__config__help__get__agent__web__http__enabled"
                ;;
            wg__quickrs__config__help__get__agent__web__http,port)
                cmd="wg__quickrs__config__help__get__agent__web__http__port"
                ;;
            wg__quickrs__config__help__get__agent__web__https,enabled)
                cmd="wg__quickrs__config__help__get__agent__web__https__enabled"
                ;;
            wg__quickrs__config__help__get__agent__web__https,port)
                cmd="wg__quickrs__config__help__get__agent__web__https__port"
                ;;
            wg__quickrs__config__help__get__agent__web__https,tls-cert)
                cmd="wg__quickrs__config__help__get__agent__web__https__tls__cert"
                ;;
            wg__quickrs__config__help__get__agent__web__https,tls-key)
                cmd="wg__quickrs__config__help__get__agent__web__https__tls__key"
                ;;
            wg__quickrs__config__help__get__agent__web__password,enabled)
                cmd="wg__quickrs__config__help__get__agent__web__password__enabled"
                ;;
            wg__quickrs__config__help__get__agent__web__password,hash)
                cmd="wg__quickrs__config__help__get__agent__web__password__hash"
                ;;
            wg__quickrs__config__help__get__network,connections)
                cmd="wg__quickrs__config__help__get__network__connections"
                ;;
            wg__quickrs__config__help__get__network,defaults)
                cmd="wg__quickrs__config__help__get__network__defaults"
                ;;
            wg__quickrs__config__help__get__network,name)
                cmd="wg__quickrs__config__help__get__network__name"
                ;;
            wg__quickrs__config__help__get__network,peers)
                cmd="wg__quickrs__config__help__get__network__peers"
                ;;
            wg__quickrs__config__help__get__network,reservations)
                cmd="wg__quickrs__config__help__get__network__reservations"
                ;;
            wg__quickrs__config__help__get__network,subnet)
                cmd="wg__quickrs__config__help__get__network__subnet"
                ;;
            wg__quickrs__config__help__get__network,this-peer)
                cmd="wg__quickrs__config__help__get__network__this__peer"
                ;;
            wg__quickrs__config__help__get__network,updated-at)
                cmd="wg__quickrs__config__help__get__network__updated__at"
                ;;
            wg__quickrs__config__help__get__network__connections,allowed-ips-a-to-b)
                cmd="wg__quickrs__config__help__get__network__connections__allowed__ips__a__to__b"
                ;;
            wg__quickrs__config__help__get__network__connections,allowed-ips-b-to-a)
                cmd="wg__quickrs__config__help__get__network__connections__allowed__ips__b__to__a"
                ;;
            wg__quickrs__config__help__get__network__connections,enabled)
                cmd="wg__quickrs__config__help__get__network__connections__enabled"
                ;;
            wg__quickrs__config__help__get__network__connections,persistent-keepalive)
                cmd="wg__quickrs__config__help__get__network__connections__persistent__keepalive"
                ;;
            wg__quickrs__config__help__get__network__connections,pre-shared-key)
                cmd="wg__quickrs__config__help__get__network__connections__pre__shared__key"
                ;;
            wg__quickrs__config__help__get__network__connections__persistent__keepalive,enabled)
                cmd="wg__quickrs__config__help__get__network__connections__persistent__keepalive__enabled"
                ;;
            wg__quickrs__config__help__get__network__connections__persistent__keepalive,period)
                cmd="wg__quickrs__config__help__get__network__connections__persistent__keepalive__period"
                ;;
            wg__quickrs__config__help__get__network__defaults,connection)
                cmd="wg__quickrs__config__help__get__network__defaults__connection"
                ;;
            wg__quickrs__config__help__get__network__defaults,peer)
                cmd="wg__quickrs__config__help__get__network__defaults__peer"
                ;;
            wg__quickrs__config__help__get__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__help__get__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__help__get__network__defaults__connection__persistent__keepalive,enabled)
                cmd="wg__quickrs__config__help__get__network__defaults__connection__persistent__keepalive__enabled"
                ;;
            wg__quickrs__config__help__get__network__defaults__connection__persistent__keepalive,period)
                cmd="wg__quickrs__config__help__get__network__defaults__connection__persistent__keepalive__period"
                ;;
            wg__quickrs__config__help__get__network__defaults__peer,dns)
                cmd="wg__quickrs__config__help__get__network__defaults__peer__dns"
                ;;
            wg__quickrs__config__help__get__network__defaults__peer,icon)
                cmd="wg__quickrs__config__help__get__network__defaults__peer__icon"
                ;;
            wg__quickrs__config__help__get__network__defaults__peer,kind)
                cmd="wg__quickrs__config__help__get__network__defaults__peer__kind"
                ;;
            wg__quickrs__config__help__get__network__defaults__peer,mtu)
                cmd="wg__quickrs__config__help__get__network__defaults__peer__mtu"
                ;;
            wg__quickrs__config__help__get__network__defaults__peer,scripts)
                cmd="wg__quickrs__config__help__get__network__defaults__peer__scripts"
                ;;
            wg__quickrs__config__help__get__network__defaults__peer__dns,addresses)
                cmd="wg__quickrs__config__help__get__network__defaults__peer__dns__addresses"
                ;;
            wg__quickrs__config__help__get__network__defaults__peer__dns,enabled)
                cmd="wg__quickrs__config__help__get__network__defaults__peer__dns__enabled"
                ;;
            wg__quickrs__config__help__get__network__defaults__peer__icon,enabled)
                cmd="wg__quickrs__config__help__get__network__defaults__peer__icon__enabled"
                ;;
            wg__quickrs__config__help__get__network__defaults__peer__icon,src)
                cmd="wg__quickrs__config__help__get__network__defaults__peer__icon__src"
                ;;
            wg__quickrs__config__help__get__network__defaults__peer__mtu,enabled)
                cmd="wg__quickrs__config__help__get__network__defaults__peer__mtu__enabled"
                ;;
            wg__quickrs__config__help__get__network__defaults__peer__mtu,value)
                cmd="wg__quickrs__config__help__get__network__defaults__peer__mtu__value"
                ;;
            wg__quickrs__config__help__get__network__peers,address)
                cmd="wg__quickrs__config__help__get__network__peers__address"
                ;;
            wg__quickrs__config__help__get__network__peers,created-at)
                cmd="wg__quickrs__config__help__get__network__peers__created__at"
                ;;
            wg__quickrs__config__help__get__network__peers,dns)
                cmd="wg__quickrs__config__help__get__network__peers__dns"
                ;;
            wg__quickrs__config__help__get__network__peers,endpoint)
                cmd="wg__quickrs__config__help__get__network__peers__endpoint"
                ;;
            wg__quickrs__config__help__get__network__peers,icon)
                cmd="wg__quickrs__config__help__get__network__peers__icon"
                ;;
            wg__quickrs__config__help__get__network__peers,kind)
                cmd="wg__quickrs__config__help__get__network__peers__kind"
                ;;
            wg__quickrs__config__help__get__network__peers,mtu)
                cmd="wg__quickrs__config__help__get__network__peers__mtu"
                ;;
            wg__quickrs__config__help__get__network__peers,name)
                cmd="wg__quickrs__config__help__get__network__peers__name"
                ;;
            wg__quickrs__config__help__get__network__peers,private-key)
                cmd="wg__quickrs__config__help__get__network__peers__private__key"
                ;;
            wg__quickrs__config__help__get__network__peers,scripts)
                cmd="wg__quickrs__config__help__get__network__peers__scripts"
                ;;
            wg__quickrs__config__help__get__network__peers,updated-at)
                cmd="wg__quickrs__config__help__get__network__peers__updated__at"
                ;;
            wg__quickrs__config__help__get__network__peers__dns,addresses)
                cmd="wg__quickrs__config__help__get__network__peers__dns__addresses"
                ;;
            wg__quickrs__config__help__get__network__peers__dns,enabled)
                cmd="wg__quickrs__config__help__get__network__peers__dns__enabled"
                ;;
            wg__quickrs__config__help__get__network__peers__endpoint,address)
                cmd="wg__quickrs__config__help__get__network__peers__endpoint__address"
                ;;
            wg__quickrs__config__help__get__network__peers__endpoint,enabled)
                cmd="wg__quickrs__config__help__get__network__peers__endpoint__enabled"
                ;;
            wg__quickrs__config__help__get__network__peers__icon,enabled)
                cmd="wg__quickrs__config__help__get__network__peers__icon__enabled"
                ;;
            wg__quickrs__config__help__get__network__peers__icon,src)
                cmd="wg__quickrs__config__help__get__network__peers__icon__src"
                ;;
            wg__quickrs__config__help__get__network__peers__mtu,enabled)
                cmd="wg__quickrs__config__help__get__network__peers__mtu__enabled"
                ;;
            wg__quickrs__config__help__get__network__peers__mtu,value)
                cmd="wg__quickrs__config__help__get__network__peers__mtu__value"
                ;;
            wg__quickrs__config__help__get__network__reservations,peer-id)
                cmd="wg__quickrs__config__help__get__network__reservations__peer__id"
                ;;
            wg__quickrs__config__help__get__network__reservations,valid-until)
                cmd="wg__quickrs__config__help__get__network__reservations__valid__until"
                ;;
            wg__quickrs__config__help__list,connections)
                cmd="wg__quickrs__config__help__list__connections"
                ;;
            wg__quickrs__config__help__list,peers)
                cmd="wg__quickrs__config__help__list__peers"
                ;;
            wg__quickrs__config__help__list,reservations)
                cmd="wg__quickrs__config__help__list__reservations"
                ;;
            wg__quickrs__config__help__remove,connection)
                cmd="wg__quickrs__config__help__remove__connection"
                ;;
            wg__quickrs__config__help__remove,peer)
                cmd="wg__quickrs__config__help__remove__peer"
                ;;
            wg__quickrs__config__help__remove,reservation)
                cmd="wg__quickrs__config__help__remove__reservation"
                ;;
            wg__quickrs__config__help__reset,agent)
                cmd="wg__quickrs__config__help__reset__agent"
                ;;
            wg__quickrs__config__help__reset,network)
                cmd="wg__quickrs__config__help__reset__network"
                ;;
            wg__quickrs__config__help__reset__agent,web)
                cmd="wg__quickrs__config__help__reset__agent__web"
                ;;
            wg__quickrs__config__help__reset__agent__web,password)
                cmd="wg__quickrs__config__help__reset__agent__web__password"
                ;;
            wg__quickrs__config__help__reset__network,connection)
                cmd="wg__quickrs__config__help__reset__network__connection"
                ;;
            wg__quickrs__config__help__reset__network,peer)
                cmd="wg__quickrs__config__help__reset__network__peer"
                ;;
            wg__quickrs__config__help__reset__network__connection,pre-shared-key)
                cmd="wg__quickrs__config__help__reset__network__connection__pre__shared__key"
                ;;
            wg__quickrs__config__help__reset__network__peer,private-key)
                cmd="wg__quickrs__config__help__reset__network__peer__private__key"
                ;;
            wg__quickrs__config__help__set,agent)
                cmd="wg__quickrs__config__help__set__agent"
                ;;
            wg__quickrs__config__help__set,network)
                cmd="wg__quickrs__config__help__set__network"
                ;;
            wg__quickrs__config__help__set__agent,firewall)
                cmd="wg__quickrs__config__help__set__agent__firewall"
                ;;
            wg__quickrs__config__help__set__agent,vpn)
                cmd="wg__quickrs__config__help__set__agent__vpn"
                ;;
            wg__quickrs__config__help__set__agent,web)
                cmd="wg__quickrs__config__help__set__agent__web"
                ;;
            wg__quickrs__config__help__set__agent__firewall,gateway)
                cmd="wg__quickrs__config__help__set__agent__firewall__gateway"
                ;;
            wg__quickrs__config__help__set__agent__firewall,utility)
                cmd="wg__quickrs__config__help__set__agent__firewall__utility"
                ;;
            wg__quickrs__config__help__set__agent__vpn,port)
                cmd="wg__quickrs__config__help__set__agent__vpn__port"
                ;;
            wg__quickrs__config__help__set__agent__web,address)
                cmd="wg__quickrs__config__help__set__agent__web__address"
                ;;
            wg__quickrs__config__help__set__agent__web,http)
                cmd="wg__quickrs__config__help__set__agent__web__http"
                ;;
            wg__quickrs__config__help__set__agent__web,https)
                cmd="wg__quickrs__config__help__set__agent__web__https"
                ;;
            wg__quickrs__config__help__set__agent__web__http,port)
                cmd="wg__quickrs__config__help__set__agent__web__http__port"
                ;;
            wg__quickrs__config__help__set__agent__web__https,port)
                cmd="wg__quickrs__config__help__set__agent__web__https__port"
                ;;
            wg__quickrs__config__help__set__agent__web__https,tls-cert)
                cmd="wg__quickrs__config__help__set__agent__web__https__tls__cert"
                ;;
            wg__quickrs__config__help__set__agent__web__https,tls-key)
                cmd="wg__quickrs__config__help__set__agent__web__https__tls__key"
                ;;
            wg__quickrs__config__help__set__network,connection)
                cmd="wg__quickrs__config__help__set__network__connection"
                ;;
            wg__quickrs__config__help__set__network,defaults)
                cmd="wg__quickrs__config__help__set__network__defaults"
                ;;
            wg__quickrs__config__help__set__network,name)
                cmd="wg__quickrs__config__help__set__network__name"
                ;;
            wg__quickrs__config__help__set__network,peer)
                cmd="wg__quickrs__config__help__set__network__peer"
                ;;
            wg__quickrs__config__help__set__network,subnet)
                cmd="wg__quickrs__config__help__set__network__subnet"
                ;;
            wg__quickrs__config__help__set__network__connection,allowed-ips-a-to-b)
                cmd="wg__quickrs__config__help__set__network__connection__allowed__ips__a__to__b"
                ;;
            wg__quickrs__config__help__set__network__connection,allowed-ips-b-to-a)
                cmd="wg__quickrs__config__help__set__network__connection__allowed__ips__b__to__a"
                ;;
            wg__quickrs__config__help__set__network__connection,persistent-keepalive)
                cmd="wg__quickrs__config__help__set__network__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__help__set__network__defaults,connection)
                cmd="wg__quickrs__config__help__set__network__defaults__connection"
                ;;
            wg__quickrs__config__help__set__network__defaults,peer)
                cmd="wg__quickrs__config__help__set__network__defaults__peer"
                ;;
            wg__quickrs__config__help__set__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__help__set__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__help__set__network__defaults__peer,dns)
                cmd="wg__quickrs__config__help__set__network__defaults__peer__dns"
                ;;
            wg__quickrs__config__help__set__network__defaults__peer,icon)
                cmd="wg__quickrs__config__help__set__network__defaults__peer__icon"
                ;;
            wg__quickrs__config__help__set__network__defaults__peer,kind)
                cmd="wg__quickrs__config__help__set__network__defaults__peer__kind"
                ;;
            wg__quickrs__config__help__set__network__defaults__peer,mtu)
                cmd="wg__quickrs__config__help__set__network__defaults__peer__mtu"
                ;;
            wg__quickrs__config__help__set__network__peer,address)
                cmd="wg__quickrs__config__help__set__network__peer__address"
                ;;
            wg__quickrs__config__help__set__network__peer,dns)
                cmd="wg__quickrs__config__help__set__network__peer__dns"
                ;;
            wg__quickrs__config__help__set__network__peer,endpoint)
                cmd="wg__quickrs__config__help__set__network__peer__endpoint"
                ;;
            wg__quickrs__config__help__set__network__peer,icon)
                cmd="wg__quickrs__config__help__set__network__peer__icon"
                ;;
            wg__quickrs__config__help__set__network__peer,kind)
                cmd="wg__quickrs__config__help__set__network__peer__kind"
                ;;
            wg__quickrs__config__help__set__network__peer,mtu)
                cmd="wg__quickrs__config__help__set__network__peer__mtu"
                ;;
            wg__quickrs__config__help__set__network__peer,name)
                cmd="wg__quickrs__config__help__set__network__peer__name"
                ;;
            wg__quickrs__config__list,connections)
                cmd="wg__quickrs__config__list__connections"
                ;;
            wg__quickrs__config__list,help)
                cmd="wg__quickrs__config__list__help"
                ;;
            wg__quickrs__config__list,peers)
                cmd="wg__quickrs__config__list__peers"
                ;;
            wg__quickrs__config__list,reservations)
                cmd="wg__quickrs__config__list__reservations"
                ;;
            wg__quickrs__config__list__help,connections)
                cmd="wg__quickrs__config__list__help__connections"
                ;;
            wg__quickrs__config__list__help,help)
                cmd="wg__quickrs__config__list__help__help"
                ;;
            wg__quickrs__config__list__help,peers)
                cmd="wg__quickrs__config__list__help__peers"
                ;;
            wg__quickrs__config__list__help,reservations)
                cmd="wg__quickrs__config__list__help__reservations"
                ;;
            wg__quickrs__config__remove,connection)
                cmd="wg__quickrs__config__remove__connection"
                ;;
            wg__quickrs__config__remove,help)
                cmd="wg__quickrs__config__remove__help"
                ;;
            wg__quickrs__config__remove,peer)
                cmd="wg__quickrs__config__remove__peer"
                ;;
            wg__quickrs__config__remove,reservation)
                cmd="wg__quickrs__config__remove__reservation"
                ;;
            wg__quickrs__config__remove__help,connection)
                cmd="wg__quickrs__config__remove__help__connection"
                ;;
            wg__quickrs__config__remove__help,help)
                cmd="wg__quickrs__config__remove__help__help"
                ;;
            wg__quickrs__config__remove__help,peer)
                cmd="wg__quickrs__config__remove__help__peer"
                ;;
            wg__quickrs__config__remove__help,reservation)
                cmd="wg__quickrs__config__remove__help__reservation"
                ;;
            wg__quickrs__config__reset,agent)
                cmd="wg__quickrs__config__reset__agent"
                ;;
            wg__quickrs__config__reset,help)
                cmd="wg__quickrs__config__reset__help"
                ;;
            wg__quickrs__config__reset,network)
                cmd="wg__quickrs__config__reset__network"
                ;;
            wg__quickrs__config__reset__agent,help)
                cmd="wg__quickrs__config__reset__agent__help"
                ;;
            wg__quickrs__config__reset__agent,web)
                cmd="wg__quickrs__config__reset__agent__web"
                ;;
            wg__quickrs__config__reset__agent__help,help)
                cmd="wg__quickrs__config__reset__agent__help__help"
                ;;
            wg__quickrs__config__reset__agent__help,web)
                cmd="wg__quickrs__config__reset__agent__help__web"
                ;;
            wg__quickrs__config__reset__agent__help__web,password)
                cmd="wg__quickrs__config__reset__agent__help__web__password"
                ;;
            wg__quickrs__config__reset__agent__web,help)
                cmd="wg__quickrs__config__reset__agent__web__help"
                ;;
            wg__quickrs__config__reset__agent__web,password)
                cmd="wg__quickrs__config__reset__agent__web__password"
                ;;
            wg__quickrs__config__reset__agent__web__help,help)
                cmd="wg__quickrs__config__reset__agent__web__help__help"
                ;;
            wg__quickrs__config__reset__agent__web__help,password)
                cmd="wg__quickrs__config__reset__agent__web__help__password"
                ;;
            wg__quickrs__config__reset__help,agent)
                cmd="wg__quickrs__config__reset__help__agent"
                ;;
            wg__quickrs__config__reset__help,help)
                cmd="wg__quickrs__config__reset__help__help"
                ;;
            wg__quickrs__config__reset__help,network)
                cmd="wg__quickrs__config__reset__help__network"
                ;;
            wg__quickrs__config__reset__help__agent,web)
                cmd="wg__quickrs__config__reset__help__agent__web"
                ;;
            wg__quickrs__config__reset__help__agent__web,password)
                cmd="wg__quickrs__config__reset__help__agent__web__password"
                ;;
            wg__quickrs__config__reset__help__network,connection)
                cmd="wg__quickrs__config__reset__help__network__connection"
                ;;
            wg__quickrs__config__reset__help__network,peer)
                cmd="wg__quickrs__config__reset__help__network__peer"
                ;;
            wg__quickrs__config__reset__help__network__connection,pre-shared-key)
                cmd="wg__quickrs__config__reset__help__network__connection__pre__shared__key"
                ;;
            wg__quickrs__config__reset__help__network__peer,private-key)
                cmd="wg__quickrs__config__reset__help__network__peer__private__key"
                ;;
            wg__quickrs__config__reset__network,connection)
                cmd="wg__quickrs__config__reset__network__connection"
                ;;
            wg__quickrs__config__reset__network,help)
                cmd="wg__quickrs__config__reset__network__help"
                ;;
            wg__quickrs__config__reset__network,peer)
                cmd="wg__quickrs__config__reset__network__peer"
                ;;
            wg__quickrs__config__reset__network__connection,help)
                cmd="wg__quickrs__config__reset__network__connection__help"
                ;;
            wg__quickrs__config__reset__network__connection,pre-shared-key)
                cmd="wg__quickrs__config__reset__network__connection__pre__shared__key"
                ;;
            wg__quickrs__config__reset__network__connection__help,help)
                cmd="wg__quickrs__config__reset__network__connection__help__help"
                ;;
            wg__quickrs__config__reset__network__connection__help,pre-shared-key)
                cmd="wg__quickrs__config__reset__network__connection__help__pre__shared__key"
                ;;
            wg__quickrs__config__reset__network__help,connection)
                cmd="wg__quickrs__config__reset__network__help__connection"
                ;;
            wg__quickrs__config__reset__network__help,help)
                cmd="wg__quickrs__config__reset__network__help__help"
                ;;
            wg__quickrs__config__reset__network__help,peer)
                cmd="wg__quickrs__config__reset__network__help__peer"
                ;;
            wg__quickrs__config__reset__network__help__connection,pre-shared-key)
                cmd="wg__quickrs__config__reset__network__help__connection__pre__shared__key"
                ;;
            wg__quickrs__config__reset__network__help__peer,private-key)
                cmd="wg__quickrs__config__reset__network__help__peer__private__key"
                ;;
            wg__quickrs__config__reset__network__peer,help)
                cmd="wg__quickrs__config__reset__network__peer__help"
                ;;
            wg__quickrs__config__reset__network__peer,private-key)
                cmd="wg__quickrs__config__reset__network__peer__private__key"
                ;;
            wg__quickrs__config__reset__network__peer__help,help)
                cmd="wg__quickrs__config__reset__network__peer__help__help"
                ;;
            wg__quickrs__config__reset__network__peer__help,private-key)
                cmd="wg__quickrs__config__reset__network__peer__help__private__key"
                ;;
            wg__quickrs__config__set,agent)
                cmd="wg__quickrs__config__set__agent"
                ;;
            wg__quickrs__config__set,help)
                cmd="wg__quickrs__config__set__help"
                ;;
            wg__quickrs__config__set,network)
                cmd="wg__quickrs__config__set__network"
                ;;
            wg__quickrs__config__set__agent,firewall)
                cmd="wg__quickrs__config__set__agent__firewall"
                ;;
            wg__quickrs__config__set__agent,help)
                cmd="wg__quickrs__config__set__agent__help"
                ;;
            wg__quickrs__config__set__agent,vpn)
                cmd="wg__quickrs__config__set__agent__vpn"
                ;;
            wg__quickrs__config__set__agent,web)
                cmd="wg__quickrs__config__set__agent__web"
                ;;
            wg__quickrs__config__set__agent__firewall,gateway)
                cmd="wg__quickrs__config__set__agent__firewall__gateway"
                ;;
            wg__quickrs__config__set__agent__firewall,help)
                cmd="wg__quickrs__config__set__agent__firewall__help"
                ;;
            wg__quickrs__config__set__agent__firewall,utility)
                cmd="wg__quickrs__config__set__agent__firewall__utility"
                ;;
            wg__quickrs__config__set__agent__firewall__help,gateway)
                cmd="wg__quickrs__config__set__agent__firewall__help__gateway"
                ;;
            wg__quickrs__config__set__agent__firewall__help,help)
                cmd="wg__quickrs__config__set__agent__firewall__help__help"
                ;;
            wg__quickrs__config__set__agent__firewall__help,utility)
                cmd="wg__quickrs__config__set__agent__firewall__help__utility"
                ;;
            wg__quickrs__config__set__agent__help,firewall)
                cmd="wg__quickrs__config__set__agent__help__firewall"
                ;;
            wg__quickrs__config__set__agent__help,help)
                cmd="wg__quickrs__config__set__agent__help__help"
                ;;
            wg__quickrs__config__set__agent__help,vpn)
                cmd="wg__quickrs__config__set__agent__help__vpn"
                ;;
            wg__quickrs__config__set__agent__help,web)
                cmd="wg__quickrs__config__set__agent__help__web"
                ;;
            wg__quickrs__config__set__agent__help__firewall,gateway)
                cmd="wg__quickrs__config__set__agent__help__firewall__gateway"
                ;;
            wg__quickrs__config__set__agent__help__firewall,utility)
                cmd="wg__quickrs__config__set__agent__help__firewall__utility"
                ;;
            wg__quickrs__config__set__agent__help__vpn,port)
                cmd="wg__quickrs__config__set__agent__help__vpn__port"
                ;;
            wg__quickrs__config__set__agent__help__web,address)
                cmd="wg__quickrs__config__set__agent__help__web__address"
                ;;
            wg__quickrs__config__set__agent__help__web,http)
                cmd="wg__quickrs__config__set__agent__help__web__http"
                ;;
            wg__quickrs__config__set__agent__help__web,https)
                cmd="wg__quickrs__config__set__agent__help__web__https"
                ;;
            wg__quickrs__config__set__agent__help__web__http,port)
                cmd="wg__quickrs__config__set__agent__help__web__http__port"
                ;;
            wg__quickrs__config__set__agent__help__web__https,port)
                cmd="wg__quickrs__config__set__agent__help__web__https__port"
                ;;
            wg__quickrs__config__set__agent__help__web__https,tls-cert)
                cmd="wg__quickrs__config__set__agent__help__web__https__tls__cert"
                ;;
            wg__quickrs__config__set__agent__help__web__https,tls-key)
                cmd="wg__quickrs__config__set__agent__help__web__https__tls__key"
                ;;
            wg__quickrs__config__set__agent__vpn,help)
                cmd="wg__quickrs__config__set__agent__vpn__help"
                ;;
            wg__quickrs__config__set__agent__vpn,port)
                cmd="wg__quickrs__config__set__agent__vpn__port"
                ;;
            wg__quickrs__config__set__agent__vpn__help,help)
                cmd="wg__quickrs__config__set__agent__vpn__help__help"
                ;;
            wg__quickrs__config__set__agent__vpn__help,port)
                cmd="wg__quickrs__config__set__agent__vpn__help__port"
                ;;
            wg__quickrs__config__set__agent__web,address)
                cmd="wg__quickrs__config__set__agent__web__address"
                ;;
            wg__quickrs__config__set__agent__web,help)
                cmd="wg__quickrs__config__set__agent__web__help"
                ;;
            wg__quickrs__config__set__agent__web,http)
                cmd="wg__quickrs__config__set__agent__web__http"
                ;;
            wg__quickrs__config__set__agent__web,https)
                cmd="wg__quickrs__config__set__agent__web__https"
                ;;
            wg__quickrs__config__set__agent__web__help,address)
                cmd="wg__quickrs__config__set__agent__web__help__address"
                ;;
            wg__quickrs__config__set__agent__web__help,help)
                cmd="wg__quickrs__config__set__agent__web__help__help"
                ;;
            wg__quickrs__config__set__agent__web__help,http)
                cmd="wg__quickrs__config__set__agent__web__help__http"
                ;;
            wg__quickrs__config__set__agent__web__help,https)
                cmd="wg__quickrs__config__set__agent__web__help__https"
                ;;
            wg__quickrs__config__set__agent__web__help__http,port)
                cmd="wg__quickrs__config__set__agent__web__help__http__port"
                ;;
            wg__quickrs__config__set__agent__web__help__https,port)
                cmd="wg__quickrs__config__set__agent__web__help__https__port"
                ;;
            wg__quickrs__config__set__agent__web__help__https,tls-cert)
                cmd="wg__quickrs__config__set__agent__web__help__https__tls__cert"
                ;;
            wg__quickrs__config__set__agent__web__help__https,tls-key)
                cmd="wg__quickrs__config__set__agent__web__help__https__tls__key"
                ;;
            wg__quickrs__config__set__agent__web__http,help)
                cmd="wg__quickrs__config__set__agent__web__http__help"
                ;;
            wg__quickrs__config__set__agent__web__http,port)
                cmd="wg__quickrs__config__set__agent__web__http__port"
                ;;
            wg__quickrs__config__set__agent__web__http__help,help)
                cmd="wg__quickrs__config__set__agent__web__http__help__help"
                ;;
            wg__quickrs__config__set__agent__web__http__help,port)
                cmd="wg__quickrs__config__set__agent__web__http__help__port"
                ;;
            wg__quickrs__config__set__agent__web__https,help)
                cmd="wg__quickrs__config__set__agent__web__https__help"
                ;;
            wg__quickrs__config__set__agent__web__https,port)
                cmd="wg__quickrs__config__set__agent__web__https__port"
                ;;
            wg__quickrs__config__set__agent__web__https,tls-cert)
                cmd="wg__quickrs__config__set__agent__web__https__tls__cert"
                ;;
            wg__quickrs__config__set__agent__web__https,tls-key)
                cmd="wg__quickrs__config__set__agent__web__https__tls__key"
                ;;
            wg__quickrs__config__set__agent__web__https__help,help)
                cmd="wg__quickrs__config__set__agent__web__https__help__help"
                ;;
            wg__quickrs__config__set__agent__web__https__help,port)
                cmd="wg__quickrs__config__set__agent__web__https__help__port"
                ;;
            wg__quickrs__config__set__agent__web__https__help,tls-cert)
                cmd="wg__quickrs__config__set__agent__web__https__help__tls__cert"
                ;;
            wg__quickrs__config__set__agent__web__https__help,tls-key)
                cmd="wg__quickrs__config__set__agent__web__https__help__tls__key"
                ;;
            wg__quickrs__config__set__help,agent)
                cmd="wg__quickrs__config__set__help__agent"
                ;;
            wg__quickrs__config__set__help,help)
                cmd="wg__quickrs__config__set__help__help"
                ;;
            wg__quickrs__config__set__help,network)
                cmd="wg__quickrs__config__set__help__network"
                ;;
            wg__quickrs__config__set__help__agent,firewall)
                cmd="wg__quickrs__config__set__help__agent__firewall"
                ;;
            wg__quickrs__config__set__help__agent,vpn)
                cmd="wg__quickrs__config__set__help__agent__vpn"
                ;;
            wg__quickrs__config__set__help__agent,web)
                cmd="wg__quickrs__config__set__help__agent__web"
                ;;
            wg__quickrs__config__set__help__agent__firewall,gateway)
                cmd="wg__quickrs__config__set__help__agent__firewall__gateway"
                ;;
            wg__quickrs__config__set__help__agent__firewall,utility)
                cmd="wg__quickrs__config__set__help__agent__firewall__utility"
                ;;
            wg__quickrs__config__set__help__agent__vpn,port)
                cmd="wg__quickrs__config__set__help__agent__vpn__port"
                ;;
            wg__quickrs__config__set__help__agent__web,address)
                cmd="wg__quickrs__config__set__help__agent__web__address"
                ;;
            wg__quickrs__config__set__help__agent__web,http)
                cmd="wg__quickrs__config__set__help__agent__web__http"
                ;;
            wg__quickrs__config__set__help__agent__web,https)
                cmd="wg__quickrs__config__set__help__agent__web__https"
                ;;
            wg__quickrs__config__set__help__agent__web__http,port)
                cmd="wg__quickrs__config__set__help__agent__web__http__port"
                ;;
            wg__quickrs__config__set__help__agent__web__https,port)
                cmd="wg__quickrs__config__set__help__agent__web__https__port"
                ;;
            wg__quickrs__config__set__help__agent__web__https,tls-cert)
                cmd="wg__quickrs__config__set__help__agent__web__https__tls__cert"
                ;;
            wg__quickrs__config__set__help__agent__web__https,tls-key)
                cmd="wg__quickrs__config__set__help__agent__web__https__tls__key"
                ;;
            wg__quickrs__config__set__help__network,connection)
                cmd="wg__quickrs__config__set__help__network__connection"
                ;;
            wg__quickrs__config__set__help__network,defaults)
                cmd="wg__quickrs__config__set__help__network__defaults"
                ;;
            wg__quickrs__config__set__help__network,name)
                cmd="wg__quickrs__config__set__help__network__name"
                ;;
            wg__quickrs__config__set__help__network,peer)
                cmd="wg__quickrs__config__set__help__network__peer"
                ;;
            wg__quickrs__config__set__help__network,subnet)
                cmd="wg__quickrs__config__set__help__network__subnet"
                ;;
            wg__quickrs__config__set__help__network__connection,allowed-ips-a-to-b)
                cmd="wg__quickrs__config__set__help__network__connection__allowed__ips__a__to__b"
                ;;
            wg__quickrs__config__set__help__network__connection,allowed-ips-b-to-a)
                cmd="wg__quickrs__config__set__help__network__connection__allowed__ips__b__to__a"
                ;;
            wg__quickrs__config__set__help__network__connection,persistent-keepalive)
                cmd="wg__quickrs__config__set__help__network__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__set__help__network__defaults,connection)
                cmd="wg__quickrs__config__set__help__network__defaults__connection"
                ;;
            wg__quickrs__config__set__help__network__defaults,peer)
                cmd="wg__quickrs__config__set__help__network__defaults__peer"
                ;;
            wg__quickrs__config__set__help__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__set__help__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__set__help__network__defaults__peer,dns)
                cmd="wg__quickrs__config__set__help__network__defaults__peer__dns"
                ;;
            wg__quickrs__config__set__help__network__defaults__peer,icon)
                cmd="wg__quickrs__config__set__help__network__defaults__peer__icon"
                ;;
            wg__quickrs__config__set__help__network__defaults__peer,kind)
                cmd="wg__quickrs__config__set__help__network__defaults__peer__kind"
                ;;
            wg__quickrs__config__set__help__network__defaults__peer,mtu)
                cmd="wg__quickrs__config__set__help__network__defaults__peer__mtu"
                ;;
            wg__quickrs__config__set__help__network__peer,address)
                cmd="wg__quickrs__config__set__help__network__peer__address"
                ;;
            wg__quickrs__config__set__help__network__peer,dns)
                cmd="wg__quickrs__config__set__help__network__peer__dns"
                ;;
            wg__quickrs__config__set__help__network__peer,endpoint)
                cmd="wg__quickrs__config__set__help__network__peer__endpoint"
                ;;
            wg__quickrs__config__set__help__network__peer,icon)
                cmd="wg__quickrs__config__set__help__network__peer__icon"
                ;;
            wg__quickrs__config__set__help__network__peer,kind)
                cmd="wg__quickrs__config__set__help__network__peer__kind"
                ;;
            wg__quickrs__config__set__help__network__peer,mtu)
                cmd="wg__quickrs__config__set__help__network__peer__mtu"
                ;;
            wg__quickrs__config__set__help__network__peer,name)
                cmd="wg__quickrs__config__set__help__network__peer__name"
                ;;
            wg__quickrs__config__set__network,connection)
                cmd="wg__quickrs__config__set__network__connection"
                ;;
            wg__quickrs__config__set__network,defaults)
                cmd="wg__quickrs__config__set__network__defaults"
                ;;
            wg__quickrs__config__set__network,help)
                cmd="wg__quickrs__config__set__network__help"
                ;;
            wg__quickrs__config__set__network,name)
                cmd="wg__quickrs__config__set__network__name"
                ;;
            wg__quickrs__config__set__network,peer)
                cmd="wg__quickrs__config__set__network__peer"
                ;;
            wg__quickrs__config__set__network,subnet)
                cmd="wg__quickrs__config__set__network__subnet"
                ;;
            wg__quickrs__config__set__network__connection,allowed-ips-a-to-b)
                cmd="wg__quickrs__config__set__network__connection__allowed__ips__a__to__b"
                ;;
            wg__quickrs__config__set__network__connection,allowed-ips-b-to-a)
                cmd="wg__quickrs__config__set__network__connection__allowed__ips__b__to__a"
                ;;
            wg__quickrs__config__set__network__connection,help)
                cmd="wg__quickrs__config__set__network__connection__help"
                ;;
            wg__quickrs__config__set__network__connection,persistent-keepalive)
                cmd="wg__quickrs__config__set__network__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__set__network__connection__help,allowed-ips-a-to-b)
                cmd="wg__quickrs__config__set__network__connection__help__allowed__ips__a__to__b"
                ;;
            wg__quickrs__config__set__network__connection__help,allowed-ips-b-to-a)
                cmd="wg__quickrs__config__set__network__connection__help__allowed__ips__b__to__a"
                ;;
            wg__quickrs__config__set__network__connection__help,help)
                cmd="wg__quickrs__config__set__network__connection__help__help"
                ;;
            wg__quickrs__config__set__network__connection__help,persistent-keepalive)
                cmd="wg__quickrs__config__set__network__connection__help__persistent__keepalive"
                ;;
            wg__quickrs__config__set__network__defaults,connection)
                cmd="wg__quickrs__config__set__network__defaults__connection"
                ;;
            wg__quickrs__config__set__network__defaults,help)
                cmd="wg__quickrs__config__set__network__defaults__help"
                ;;
            wg__quickrs__config__set__network__defaults,peer)
                cmd="wg__quickrs__config__set__network__defaults__peer"
                ;;
            wg__quickrs__config__set__network__defaults__connection,help)
                cmd="wg__quickrs__config__set__network__defaults__connection__help"
                ;;
            wg__quickrs__config__set__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__set__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__set__network__defaults__connection__help,help)
                cmd="wg__quickrs__config__set__network__defaults__connection__help__help"
                ;;
            wg__quickrs__config__set__network__defaults__connection__help,persistent-keepalive)
                cmd="wg__quickrs__config__set__network__defaults__connection__help__persistent__keepalive"
                ;;
            wg__quickrs__config__set__network__defaults__help,connection)
                cmd="wg__quickrs__config__set__network__defaults__help__connection"
                ;;
            wg__quickrs__config__set__network__defaults__help,help)
                cmd="wg__quickrs__config__set__network__defaults__help__help"
                ;;
            wg__quickrs__config__set__network__defaults__help,peer)
                cmd="wg__quickrs__config__set__network__defaults__help__peer"
                ;;
            wg__quickrs__config__set__network__defaults__help__connection,persistent-keepalive)
                cmd="wg__quickrs__config__set__network__defaults__help__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__set__network__defaults__help__peer,dns)
                cmd="wg__quickrs__config__set__network__defaults__help__peer__dns"
                ;;
            wg__quickrs__config__set__network__defaults__help__peer,icon)
                cmd="wg__quickrs__config__set__network__defaults__help__peer__icon"
                ;;
            wg__quickrs__config__set__network__defaults__help__peer,kind)
                cmd="wg__quickrs__config__set__network__defaults__help__peer__kind"
                ;;
            wg__quickrs__config__set__network__defaults__help__peer,mtu)
                cmd="wg__quickrs__config__set__network__defaults__help__peer__mtu"
                ;;
            wg__quickrs__config__set__network__defaults__peer,dns)
                cmd="wg__quickrs__config__set__network__defaults__peer__dns"
                ;;
            wg__quickrs__config__set__network__defaults__peer,help)
                cmd="wg__quickrs__config__set__network__defaults__peer__help"
                ;;
            wg__quickrs__config__set__network__defaults__peer,icon)
                cmd="wg__quickrs__config__set__network__defaults__peer__icon"
                ;;
            wg__quickrs__config__set__network__defaults__peer,kind)
                cmd="wg__quickrs__config__set__network__defaults__peer__kind"
                ;;
            wg__quickrs__config__set__network__defaults__peer,mtu)
                cmd="wg__quickrs__config__set__network__defaults__peer__mtu"
                ;;
            wg__quickrs__config__set__network__defaults__peer__help,dns)
                cmd="wg__quickrs__config__set__network__defaults__peer__help__dns"
                ;;
            wg__quickrs__config__set__network__defaults__peer__help,help)
                cmd="wg__quickrs__config__set__network__defaults__peer__help__help"
                ;;
            wg__quickrs__config__set__network__defaults__peer__help,icon)
                cmd="wg__quickrs__config__set__network__defaults__peer__help__icon"
                ;;
            wg__quickrs__config__set__network__defaults__peer__help,kind)
                cmd="wg__quickrs__config__set__network__defaults__peer__help__kind"
                ;;
            wg__quickrs__config__set__network__defaults__peer__help,mtu)
                cmd="wg__quickrs__config__set__network__defaults__peer__help__mtu"
                ;;
            wg__quickrs__config__set__network__help,connection)
                cmd="wg__quickrs__config__set__network__help__connection"
                ;;
            wg__quickrs__config__set__network__help,defaults)
                cmd="wg__quickrs__config__set__network__help__defaults"
                ;;
            wg__quickrs__config__set__network__help,help)
                cmd="wg__quickrs__config__set__network__help__help"
                ;;
            wg__quickrs__config__set__network__help,name)
                cmd="wg__quickrs__config__set__network__help__name"
                ;;
            wg__quickrs__config__set__network__help,peer)
                cmd="wg__quickrs__config__set__network__help__peer"
                ;;
            wg__quickrs__config__set__network__help,subnet)
                cmd="wg__quickrs__config__set__network__help__subnet"
                ;;
            wg__quickrs__config__set__network__help__connection,allowed-ips-a-to-b)
                cmd="wg__quickrs__config__set__network__help__connection__allowed__ips__a__to__b"
                ;;
            wg__quickrs__config__set__network__help__connection,allowed-ips-b-to-a)
                cmd="wg__quickrs__config__set__network__help__connection__allowed__ips__b__to__a"
                ;;
            wg__quickrs__config__set__network__help__connection,persistent-keepalive)
                cmd="wg__quickrs__config__set__network__help__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__set__network__help__defaults,connection)
                cmd="wg__quickrs__config__set__network__help__defaults__connection"
                ;;
            wg__quickrs__config__set__network__help__defaults,peer)
                cmd="wg__quickrs__config__set__network__help__defaults__peer"
                ;;
            wg__quickrs__config__set__network__help__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__config__set__network__help__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__config__set__network__help__defaults__peer,dns)
                cmd="wg__quickrs__config__set__network__help__defaults__peer__dns"
                ;;
            wg__quickrs__config__set__network__help__defaults__peer,icon)
                cmd="wg__quickrs__config__set__network__help__defaults__peer__icon"
                ;;
            wg__quickrs__config__set__network__help__defaults__peer,kind)
                cmd="wg__quickrs__config__set__network__help__defaults__peer__kind"
                ;;
            wg__quickrs__config__set__network__help__defaults__peer,mtu)
                cmd="wg__quickrs__config__set__network__help__defaults__peer__mtu"
                ;;
            wg__quickrs__config__set__network__help__peer,address)
                cmd="wg__quickrs__config__set__network__help__peer__address"
                ;;
            wg__quickrs__config__set__network__help__peer,dns)
                cmd="wg__quickrs__config__set__network__help__peer__dns"
                ;;
            wg__quickrs__config__set__network__help__peer,endpoint)
                cmd="wg__quickrs__config__set__network__help__peer__endpoint"
                ;;
            wg__quickrs__config__set__network__help__peer,icon)
                cmd="wg__quickrs__config__set__network__help__peer__icon"
                ;;
            wg__quickrs__config__set__network__help__peer,kind)
                cmd="wg__quickrs__config__set__network__help__peer__kind"
                ;;
            wg__quickrs__config__set__network__help__peer,mtu)
                cmd="wg__quickrs__config__set__network__help__peer__mtu"
                ;;
            wg__quickrs__config__set__network__help__peer,name)
                cmd="wg__quickrs__config__set__network__help__peer__name"
                ;;
            wg__quickrs__config__set__network__peer,address)
                cmd="wg__quickrs__config__set__network__peer__address"
                ;;
            wg__quickrs__config__set__network__peer,dns)
                cmd="wg__quickrs__config__set__network__peer__dns"
                ;;
            wg__quickrs__config__set__network__peer,endpoint)
                cmd="wg__quickrs__config__set__network__peer__endpoint"
                ;;
            wg__quickrs__config__set__network__peer,help)
                cmd="wg__quickrs__config__set__network__peer__help"
                ;;
            wg__quickrs__config__set__network__peer,icon)
                cmd="wg__quickrs__config__set__network__peer__icon"
                ;;
            wg__quickrs__config__set__network__peer,kind)
                cmd="wg__quickrs__config__set__network__peer__kind"
                ;;
            wg__quickrs__config__set__network__peer,mtu)
                cmd="wg__quickrs__config__set__network__peer__mtu"
                ;;
            wg__quickrs__config__set__network__peer,name)
                cmd="wg__quickrs__config__set__network__peer__name"
                ;;
            wg__quickrs__config__set__network__peer__help,address)
                cmd="wg__quickrs__config__set__network__peer__help__address"
                ;;
            wg__quickrs__config__set__network__peer__help,dns)
                cmd="wg__quickrs__config__set__network__peer__help__dns"
                ;;
            wg__quickrs__config__set__network__peer__help,endpoint)
                cmd="wg__quickrs__config__set__network__peer__help__endpoint"
                ;;
            wg__quickrs__config__set__network__peer__help,help)
                cmd="wg__quickrs__config__set__network__peer__help__help"
                ;;
            wg__quickrs__config__set__network__peer__help,icon)
                cmd="wg__quickrs__config__set__network__peer__help__icon"
                ;;
            wg__quickrs__config__set__network__peer__help,kind)
                cmd="wg__quickrs__config__set__network__peer__help__kind"
                ;;
            wg__quickrs__config__set__network__peer__help,mtu)
                cmd="wg__quickrs__config__set__network__peer__help__mtu"
                ;;
            wg__quickrs__config__set__network__peer__help,name)
                cmd="wg__quickrs__config__set__network__peer__help__name"
                ;;
            wg__quickrs__help,agent)
                cmd="wg__quickrs__help__agent"
                ;;
            wg__quickrs__help,config)
                cmd="wg__quickrs__help__config"
                ;;
            wg__quickrs__help,help)
                cmd="wg__quickrs__help__help"
                ;;
            wg__quickrs__help__agent,init)
                cmd="wg__quickrs__help__agent__init"
                ;;
            wg__quickrs__help__agent,run)
                cmd="wg__quickrs__help__agent__run"
                ;;
            wg__quickrs__help__config,add)
                cmd="wg__quickrs__help__config__add"
                ;;
            wg__quickrs__help__config,disable)
                cmd="wg__quickrs__help__config__disable"
                ;;
            wg__quickrs__help__config,enable)
                cmd="wg__quickrs__help__config__enable"
                ;;
            wg__quickrs__help__config,get)
                cmd="wg__quickrs__help__config__get"
                ;;
            wg__quickrs__help__config,list)
                cmd="wg__quickrs__help__config__list"
                ;;
            wg__quickrs__help__config,remove)
                cmd="wg__quickrs__help__config__remove"
                ;;
            wg__quickrs__help__config,reset)
                cmd="wg__quickrs__help__config__reset"
                ;;
            wg__quickrs__help__config,set)
                cmd="wg__quickrs__help__config__set"
                ;;
            wg__quickrs__help__config__add,connection)
                cmd="wg__quickrs__help__config__add__connection"
                ;;
            wg__quickrs__help__config__add,peer)
                cmd="wg__quickrs__help__config__add__peer"
                ;;
            wg__quickrs__help__config__disable,agent)
                cmd="wg__quickrs__help__config__disable__agent"
                ;;
            wg__quickrs__help__config__disable,network)
                cmd="wg__quickrs__help__config__disable__network"
                ;;
            wg__quickrs__help__config__disable__agent,firewall)
                cmd="wg__quickrs__help__config__disable__agent__firewall"
                ;;
            wg__quickrs__help__config__disable__agent,vpn)
                cmd="wg__quickrs__help__config__disable__agent__vpn"
                ;;
            wg__quickrs__help__config__disable__agent,web)
                cmd="wg__quickrs__help__config__disable__agent__web"
                ;;
            wg__quickrs__help__config__disable__agent__web,http)
                cmd="wg__quickrs__help__config__disable__agent__web__http"
                ;;
            wg__quickrs__help__config__disable__agent__web,https)
                cmd="wg__quickrs__help__config__disable__agent__web__https"
                ;;
            wg__quickrs__help__config__disable__agent__web,password)
                cmd="wg__quickrs__help__config__disable__agent__web__password"
                ;;
            wg__quickrs__help__config__disable__network,connection)
                cmd="wg__quickrs__help__config__disable__network__connection"
                ;;
            wg__quickrs__help__config__disable__network,defaults)
                cmd="wg__quickrs__help__config__disable__network__defaults"
                ;;
            wg__quickrs__help__config__disable__network,peer)
                cmd="wg__quickrs__help__config__disable__network__peer"
                ;;
            wg__quickrs__help__config__disable__network__defaults,connection)
                cmd="wg__quickrs__help__config__disable__network__defaults__connection"
                ;;
            wg__quickrs__help__config__disable__network__defaults,peer)
                cmd="wg__quickrs__help__config__disable__network__defaults__peer"
                ;;
            wg__quickrs__help__config__disable__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__help__config__disable__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__help__config__disable__network__defaults__peer,dns)
                cmd="wg__quickrs__help__config__disable__network__defaults__peer__dns"
                ;;
            wg__quickrs__help__config__disable__network__defaults__peer,icon)
                cmd="wg__quickrs__help__config__disable__network__defaults__peer__icon"
                ;;
            wg__quickrs__help__config__disable__network__defaults__peer,mtu)
                cmd="wg__quickrs__help__config__disable__network__defaults__peer__mtu"
                ;;
            wg__quickrs__help__config__disable__network__peer,dns)
                cmd="wg__quickrs__help__config__disable__network__peer__dns"
                ;;
            wg__quickrs__help__config__disable__network__peer,endpoint)
                cmd="wg__quickrs__help__config__disable__network__peer__endpoint"
                ;;
            wg__quickrs__help__config__disable__network__peer,icon)
                cmd="wg__quickrs__help__config__disable__network__peer__icon"
                ;;
            wg__quickrs__help__config__disable__network__peer,mtu)
                cmd="wg__quickrs__help__config__disable__network__peer__mtu"
                ;;
            wg__quickrs__help__config__enable,agent)
                cmd="wg__quickrs__help__config__enable__agent"
                ;;
            wg__quickrs__help__config__enable,network)
                cmd="wg__quickrs__help__config__enable__network"
                ;;
            wg__quickrs__help__config__enable__agent,firewall)
                cmd="wg__quickrs__help__config__enable__agent__firewall"
                ;;
            wg__quickrs__help__config__enable__agent,vpn)
                cmd="wg__quickrs__help__config__enable__agent__vpn"
                ;;
            wg__quickrs__help__config__enable__agent,web)
                cmd="wg__quickrs__help__config__enable__agent__web"
                ;;
            wg__quickrs__help__config__enable__agent__web,http)
                cmd="wg__quickrs__help__config__enable__agent__web__http"
                ;;
            wg__quickrs__help__config__enable__agent__web,https)
                cmd="wg__quickrs__help__config__enable__agent__web__https"
                ;;
            wg__quickrs__help__config__enable__agent__web,password)
                cmd="wg__quickrs__help__config__enable__agent__web__password"
                ;;
            wg__quickrs__help__config__enable__network,connection)
                cmd="wg__quickrs__help__config__enable__network__connection"
                ;;
            wg__quickrs__help__config__enable__network,defaults)
                cmd="wg__quickrs__help__config__enable__network__defaults"
                ;;
            wg__quickrs__help__config__enable__network,peer)
                cmd="wg__quickrs__help__config__enable__network__peer"
                ;;
            wg__quickrs__help__config__enable__network__defaults,connection)
                cmd="wg__quickrs__help__config__enable__network__defaults__connection"
                ;;
            wg__quickrs__help__config__enable__network__defaults,peer)
                cmd="wg__quickrs__help__config__enable__network__defaults__peer"
                ;;
            wg__quickrs__help__config__enable__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__help__config__enable__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__help__config__enable__network__defaults__peer,dns)
                cmd="wg__quickrs__help__config__enable__network__defaults__peer__dns"
                ;;
            wg__quickrs__help__config__enable__network__defaults__peer,icon)
                cmd="wg__quickrs__help__config__enable__network__defaults__peer__icon"
                ;;
            wg__quickrs__help__config__enable__network__defaults__peer,mtu)
                cmd="wg__quickrs__help__config__enable__network__defaults__peer__mtu"
                ;;
            wg__quickrs__help__config__enable__network__peer,dns)
                cmd="wg__quickrs__help__config__enable__network__peer__dns"
                ;;
            wg__quickrs__help__config__enable__network__peer,endpoint)
                cmd="wg__quickrs__help__config__enable__network__peer__endpoint"
                ;;
            wg__quickrs__help__config__enable__network__peer,icon)
                cmd="wg__quickrs__help__config__enable__network__peer__icon"
                ;;
            wg__quickrs__help__config__enable__network__peer,mtu)
                cmd="wg__quickrs__help__config__enable__network__peer__mtu"
                ;;
            wg__quickrs__help__config__get,agent)
                cmd="wg__quickrs__help__config__get__agent"
                ;;
            wg__quickrs__help__config__get,network)
                cmd="wg__quickrs__help__config__get__network"
                ;;
            wg__quickrs__help__config__get__agent,firewall)
                cmd="wg__quickrs__help__config__get__agent__firewall"
                ;;
            wg__quickrs__help__config__get__agent,vpn)
                cmd="wg__quickrs__help__config__get__agent__vpn"
                ;;
            wg__quickrs__help__config__get__agent,web)
                cmd="wg__quickrs__help__config__get__agent__web"
                ;;
            wg__quickrs__help__config__get__agent__firewall,enabled)
                cmd="wg__quickrs__help__config__get__agent__firewall__enabled"
                ;;
            wg__quickrs__help__config__get__agent__firewall,gateway)
                cmd="wg__quickrs__help__config__get__agent__firewall__gateway"
                ;;
            wg__quickrs__help__config__get__agent__firewall,utility)
                cmd="wg__quickrs__help__config__get__agent__firewall__utility"
                ;;
            wg__quickrs__help__config__get__agent__vpn,enabled)
                cmd="wg__quickrs__help__config__get__agent__vpn__enabled"
                ;;
            wg__quickrs__help__config__get__agent__vpn,port)
                cmd="wg__quickrs__help__config__get__agent__vpn__port"
                ;;
            wg__quickrs__help__config__get__agent__web,address)
                cmd="wg__quickrs__help__config__get__agent__web__address"
                ;;
            wg__quickrs__help__config__get__agent__web,http)
                cmd="wg__quickrs__help__config__get__agent__web__http"
                ;;
            wg__quickrs__help__config__get__agent__web,https)
                cmd="wg__quickrs__help__config__get__agent__web__https"
                ;;
            wg__quickrs__help__config__get__agent__web,password)
                cmd="wg__quickrs__help__config__get__agent__web__password"
                ;;
            wg__quickrs__help__config__get__agent__web__http,enabled)
                cmd="wg__quickrs__help__config__get__agent__web__http__enabled"
                ;;
            wg__quickrs__help__config__get__agent__web__http,port)
                cmd="wg__quickrs__help__config__get__agent__web__http__port"
                ;;
            wg__quickrs__help__config__get__agent__web__https,enabled)
                cmd="wg__quickrs__help__config__get__agent__web__https__enabled"
                ;;
            wg__quickrs__help__config__get__agent__web__https,port)
                cmd="wg__quickrs__help__config__get__agent__web__https__port"
                ;;
            wg__quickrs__help__config__get__agent__web__https,tls-cert)
                cmd="wg__quickrs__help__config__get__agent__web__https__tls__cert"
                ;;
            wg__quickrs__help__config__get__agent__web__https,tls-key)
                cmd="wg__quickrs__help__config__get__agent__web__https__tls__key"
                ;;
            wg__quickrs__help__config__get__agent__web__password,enabled)
                cmd="wg__quickrs__help__config__get__agent__web__password__enabled"
                ;;
            wg__quickrs__help__config__get__agent__web__password,hash)
                cmd="wg__quickrs__help__config__get__agent__web__password__hash"
                ;;
            wg__quickrs__help__config__get__network,connections)
                cmd="wg__quickrs__help__config__get__network__connections"
                ;;
            wg__quickrs__help__config__get__network,defaults)
                cmd="wg__quickrs__help__config__get__network__defaults"
                ;;
            wg__quickrs__help__config__get__network,name)
                cmd="wg__quickrs__help__config__get__network__name"
                ;;
            wg__quickrs__help__config__get__network,peers)
                cmd="wg__quickrs__help__config__get__network__peers"
                ;;
            wg__quickrs__help__config__get__network,reservations)
                cmd="wg__quickrs__help__config__get__network__reservations"
                ;;
            wg__quickrs__help__config__get__network,subnet)
                cmd="wg__quickrs__help__config__get__network__subnet"
                ;;
            wg__quickrs__help__config__get__network,this-peer)
                cmd="wg__quickrs__help__config__get__network__this__peer"
                ;;
            wg__quickrs__help__config__get__network,updated-at)
                cmd="wg__quickrs__help__config__get__network__updated__at"
                ;;
            wg__quickrs__help__config__get__network__connections,allowed-ips-a-to-b)
                cmd="wg__quickrs__help__config__get__network__connections__allowed__ips__a__to__b"
                ;;
            wg__quickrs__help__config__get__network__connections,allowed-ips-b-to-a)
                cmd="wg__quickrs__help__config__get__network__connections__allowed__ips__b__to__a"
                ;;
            wg__quickrs__help__config__get__network__connections,enabled)
                cmd="wg__quickrs__help__config__get__network__connections__enabled"
                ;;
            wg__quickrs__help__config__get__network__connections,persistent-keepalive)
                cmd="wg__quickrs__help__config__get__network__connections__persistent__keepalive"
                ;;
            wg__quickrs__help__config__get__network__connections,pre-shared-key)
                cmd="wg__quickrs__help__config__get__network__connections__pre__shared__key"
                ;;
            wg__quickrs__help__config__get__network__connections__persistent__keepalive,enabled)
                cmd="wg__quickrs__help__config__get__network__connections__persistent__keepalive__enabled"
                ;;
            wg__quickrs__help__config__get__network__connections__persistent__keepalive,period)
                cmd="wg__quickrs__help__config__get__network__connections__persistent__keepalive__period"
                ;;
            wg__quickrs__help__config__get__network__defaults,connection)
                cmd="wg__quickrs__help__config__get__network__defaults__connection"
                ;;
            wg__quickrs__help__config__get__network__defaults,peer)
                cmd="wg__quickrs__help__config__get__network__defaults__peer"
                ;;
            wg__quickrs__help__config__get__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__help__config__get__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__help__config__get__network__defaults__connection__persistent__keepalive,enabled)
                cmd="wg__quickrs__help__config__get__network__defaults__connection__persistent__keepalive__enabled"
                ;;
            wg__quickrs__help__config__get__network__defaults__connection__persistent__keepalive,period)
                cmd="wg__quickrs__help__config__get__network__defaults__connection__persistent__keepalive__period"
                ;;
            wg__quickrs__help__config__get__network__defaults__peer,dns)
                cmd="wg__quickrs__help__config__get__network__defaults__peer__dns"
                ;;
            wg__quickrs__help__config__get__network__defaults__peer,icon)
                cmd="wg__quickrs__help__config__get__network__defaults__peer__icon"
                ;;
            wg__quickrs__help__config__get__network__defaults__peer,kind)
                cmd="wg__quickrs__help__config__get__network__defaults__peer__kind"
                ;;
            wg__quickrs__help__config__get__network__defaults__peer,mtu)
                cmd="wg__quickrs__help__config__get__network__defaults__peer__mtu"
                ;;
            wg__quickrs__help__config__get__network__defaults__peer,scripts)
                cmd="wg__quickrs__help__config__get__network__defaults__peer__scripts"
                ;;
            wg__quickrs__help__config__get__network__defaults__peer__dns,addresses)
                cmd="wg__quickrs__help__config__get__network__defaults__peer__dns__addresses"
                ;;
            wg__quickrs__help__config__get__network__defaults__peer__dns,enabled)
                cmd="wg__quickrs__help__config__get__network__defaults__peer__dns__enabled"
                ;;
            wg__quickrs__help__config__get__network__defaults__peer__icon,enabled)
                cmd="wg__quickrs__help__config__get__network__defaults__peer__icon__enabled"
                ;;
            wg__quickrs__help__config__get__network__defaults__peer__icon,src)
                cmd="wg__quickrs__help__config__get__network__defaults__peer__icon__src"
                ;;
            wg__quickrs__help__config__get__network__defaults__peer__mtu,enabled)
                cmd="wg__quickrs__help__config__get__network__defaults__peer__mtu__enabled"
                ;;
            wg__quickrs__help__config__get__network__defaults__peer__mtu,value)
                cmd="wg__quickrs__help__config__get__network__defaults__peer__mtu__value"
                ;;
            wg__quickrs__help__config__get__network__peers,address)
                cmd="wg__quickrs__help__config__get__network__peers__address"
                ;;
            wg__quickrs__help__config__get__network__peers,created-at)
                cmd="wg__quickrs__help__config__get__network__peers__created__at"
                ;;
            wg__quickrs__help__config__get__network__peers,dns)
                cmd="wg__quickrs__help__config__get__network__peers__dns"
                ;;
            wg__quickrs__help__config__get__network__peers,endpoint)
                cmd="wg__quickrs__help__config__get__network__peers__endpoint"
                ;;
            wg__quickrs__help__config__get__network__peers,icon)
                cmd="wg__quickrs__help__config__get__network__peers__icon"
                ;;
            wg__quickrs__help__config__get__network__peers,kind)
                cmd="wg__quickrs__help__config__get__network__peers__kind"
                ;;
            wg__quickrs__help__config__get__network__peers,mtu)
                cmd="wg__quickrs__help__config__get__network__peers__mtu"
                ;;
            wg__quickrs__help__config__get__network__peers,name)
                cmd="wg__quickrs__help__config__get__network__peers__name"
                ;;
            wg__quickrs__help__config__get__network__peers,private-key)
                cmd="wg__quickrs__help__config__get__network__peers__private__key"
                ;;
            wg__quickrs__help__config__get__network__peers,scripts)
                cmd="wg__quickrs__help__config__get__network__peers__scripts"
                ;;
            wg__quickrs__help__config__get__network__peers,updated-at)
                cmd="wg__quickrs__help__config__get__network__peers__updated__at"
                ;;
            wg__quickrs__help__config__get__network__peers__dns,addresses)
                cmd="wg__quickrs__help__config__get__network__peers__dns__addresses"
                ;;
            wg__quickrs__help__config__get__network__peers__dns,enabled)
                cmd="wg__quickrs__help__config__get__network__peers__dns__enabled"
                ;;
            wg__quickrs__help__config__get__network__peers__endpoint,address)
                cmd="wg__quickrs__help__config__get__network__peers__endpoint__address"
                ;;
            wg__quickrs__help__config__get__network__peers__endpoint,enabled)
                cmd="wg__quickrs__help__config__get__network__peers__endpoint__enabled"
                ;;
            wg__quickrs__help__config__get__network__peers__icon,enabled)
                cmd="wg__quickrs__help__config__get__network__peers__icon__enabled"
                ;;
            wg__quickrs__help__config__get__network__peers__icon,src)
                cmd="wg__quickrs__help__config__get__network__peers__icon__src"
                ;;
            wg__quickrs__help__config__get__network__peers__mtu,enabled)
                cmd="wg__quickrs__help__config__get__network__peers__mtu__enabled"
                ;;
            wg__quickrs__help__config__get__network__peers__mtu,value)
                cmd="wg__quickrs__help__config__get__network__peers__mtu__value"
                ;;
            wg__quickrs__help__config__get__network__reservations,peer-id)
                cmd="wg__quickrs__help__config__get__network__reservations__peer__id"
                ;;
            wg__quickrs__help__config__get__network__reservations,valid-until)
                cmd="wg__quickrs__help__config__get__network__reservations__valid__until"
                ;;
            wg__quickrs__help__config__list,connections)
                cmd="wg__quickrs__help__config__list__connections"
                ;;
            wg__quickrs__help__config__list,peers)
                cmd="wg__quickrs__help__config__list__peers"
                ;;
            wg__quickrs__help__config__list,reservations)
                cmd="wg__quickrs__help__config__list__reservations"
                ;;
            wg__quickrs__help__config__remove,connection)
                cmd="wg__quickrs__help__config__remove__connection"
                ;;
            wg__quickrs__help__config__remove,peer)
                cmd="wg__quickrs__help__config__remove__peer"
                ;;
            wg__quickrs__help__config__remove,reservation)
                cmd="wg__quickrs__help__config__remove__reservation"
                ;;
            wg__quickrs__help__config__reset,agent)
                cmd="wg__quickrs__help__config__reset__agent"
                ;;
            wg__quickrs__help__config__reset,network)
                cmd="wg__quickrs__help__config__reset__network"
                ;;
            wg__quickrs__help__config__reset__agent,web)
                cmd="wg__quickrs__help__config__reset__agent__web"
                ;;
            wg__quickrs__help__config__reset__agent__web,password)
                cmd="wg__quickrs__help__config__reset__agent__web__password"
                ;;
            wg__quickrs__help__config__reset__network,connection)
                cmd="wg__quickrs__help__config__reset__network__connection"
                ;;
            wg__quickrs__help__config__reset__network,peer)
                cmd="wg__quickrs__help__config__reset__network__peer"
                ;;
            wg__quickrs__help__config__reset__network__connection,pre-shared-key)
                cmd="wg__quickrs__help__config__reset__network__connection__pre__shared__key"
                ;;
            wg__quickrs__help__config__reset__network__peer,private-key)
                cmd="wg__quickrs__help__config__reset__network__peer__private__key"
                ;;
            wg__quickrs__help__config__set,agent)
                cmd="wg__quickrs__help__config__set__agent"
                ;;
            wg__quickrs__help__config__set,network)
                cmd="wg__quickrs__help__config__set__network"
                ;;
            wg__quickrs__help__config__set__agent,firewall)
                cmd="wg__quickrs__help__config__set__agent__firewall"
                ;;
            wg__quickrs__help__config__set__agent,vpn)
                cmd="wg__quickrs__help__config__set__agent__vpn"
                ;;
            wg__quickrs__help__config__set__agent,web)
                cmd="wg__quickrs__help__config__set__agent__web"
                ;;
            wg__quickrs__help__config__set__agent__firewall,gateway)
                cmd="wg__quickrs__help__config__set__agent__firewall__gateway"
                ;;
            wg__quickrs__help__config__set__agent__firewall,utility)
                cmd="wg__quickrs__help__config__set__agent__firewall__utility"
                ;;
            wg__quickrs__help__config__set__agent__vpn,port)
                cmd="wg__quickrs__help__config__set__agent__vpn__port"
                ;;
            wg__quickrs__help__config__set__agent__web,address)
                cmd="wg__quickrs__help__config__set__agent__web__address"
                ;;
            wg__quickrs__help__config__set__agent__web,http)
                cmd="wg__quickrs__help__config__set__agent__web__http"
                ;;
            wg__quickrs__help__config__set__agent__web,https)
                cmd="wg__quickrs__help__config__set__agent__web__https"
                ;;
            wg__quickrs__help__config__set__agent__web__http,port)
                cmd="wg__quickrs__help__config__set__agent__web__http__port"
                ;;
            wg__quickrs__help__config__set__agent__web__https,port)
                cmd="wg__quickrs__help__config__set__agent__web__https__port"
                ;;
            wg__quickrs__help__config__set__agent__web__https,tls-cert)
                cmd="wg__quickrs__help__config__set__agent__web__https__tls__cert"
                ;;
            wg__quickrs__help__config__set__agent__web__https,tls-key)
                cmd="wg__quickrs__help__config__set__agent__web__https__tls__key"
                ;;
            wg__quickrs__help__config__set__network,connection)
                cmd="wg__quickrs__help__config__set__network__connection"
                ;;
            wg__quickrs__help__config__set__network,defaults)
                cmd="wg__quickrs__help__config__set__network__defaults"
                ;;
            wg__quickrs__help__config__set__network,name)
                cmd="wg__quickrs__help__config__set__network__name"
                ;;
            wg__quickrs__help__config__set__network,peer)
                cmd="wg__quickrs__help__config__set__network__peer"
                ;;
            wg__quickrs__help__config__set__network,subnet)
                cmd="wg__quickrs__help__config__set__network__subnet"
                ;;
            wg__quickrs__help__config__set__network__connection,allowed-ips-a-to-b)
                cmd="wg__quickrs__help__config__set__network__connection__allowed__ips__a__to__b"
                ;;
            wg__quickrs__help__config__set__network__connection,allowed-ips-b-to-a)
                cmd="wg__quickrs__help__config__set__network__connection__allowed__ips__b__to__a"
                ;;
            wg__quickrs__help__config__set__network__connection,persistent-keepalive)
                cmd="wg__quickrs__help__config__set__network__connection__persistent__keepalive"
                ;;
            wg__quickrs__help__config__set__network__defaults,connection)
                cmd="wg__quickrs__help__config__set__network__defaults__connection"
                ;;
            wg__quickrs__help__config__set__network__defaults,peer)
                cmd="wg__quickrs__help__config__set__network__defaults__peer"
                ;;
            wg__quickrs__help__config__set__network__defaults__connection,persistent-keepalive)
                cmd="wg__quickrs__help__config__set__network__defaults__connection__persistent__keepalive"
                ;;
            wg__quickrs__help__config__set__network__defaults__peer,dns)
                cmd="wg__quickrs__help__config__set__network__defaults__peer__dns"
                ;;
            wg__quickrs__help__config__set__network__defaults__peer,icon)
                cmd="wg__quickrs__help__config__set__network__defaults__peer__icon"
                ;;
            wg__quickrs__help__config__set__network__defaults__peer,kind)
                cmd="wg__quickrs__help__config__set__network__defaults__peer__kind"
                ;;
            wg__quickrs__help__config__set__network__defaults__peer,mtu)
                cmd="wg__quickrs__help__config__set__network__defaults__peer__mtu"
                ;;
            wg__quickrs__help__config__set__network__peer,address)
                cmd="wg__quickrs__help__config__set__network__peer__address"
                ;;
            wg__quickrs__help__config__set__network__peer,dns)
                cmd="wg__quickrs__help__config__set__network__peer__dns"
                ;;
            wg__quickrs__help__config__set__network__peer,endpoint)
                cmd="wg__quickrs__help__config__set__network__peer__endpoint"
                ;;
            wg__quickrs__help__config__set__network__peer,icon)
                cmd="wg__quickrs__help__config__set__network__peer__icon"
                ;;
            wg__quickrs__help__config__set__network__peer,kind)
                cmd="wg__quickrs__help__config__set__network__peer__kind"
                ;;
            wg__quickrs__help__config__set__network__peer,mtu)
                cmd="wg__quickrs__help__config__set__network__peer__mtu"
                ;;
            wg__quickrs__help__config__set__network__peer,name)
                cmd="wg__quickrs__help__config__set__network__peer__name"
                ;;
            *)
                ;;
        esac
    done

    case "${cmd}" in
        wg__quickrs)
            opts="-v -h --verbose --wg-quickrs-config-folder --help agent config help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --wg-quickrs-config-folder)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__agent)
            opts="-h --help init run help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__agent__help)
            opts="init run help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__agent__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__agent__help__init)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__agent__help__run)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__agent__init)
            opts="-h --network-name --network-subnet --agent-web-address --agent-web-http-enabled --agent-web-http-port --agent-web-https-enabled --agent-web-https-port --agent-web-https-tls-cert --agent-web-https-tls-key --agent-web-password-enabled --agent-web-password --agent-vpn-enabled --agent-vpn-port --agent-firewall-enabled --agent-firewall-utility --agent-firewall-gateway --agent-peer-name --agent-peer-vpn-internal-address --agent-peer-vpn-endpoint --agent-peer-kind --agent-peer-icon-enabled --agent-peer-icon-src --agent-peer-dns-enabled --agent-peer-dns-addresses --agent-peer-mtu-enabled --agent-peer-mtu-value --agent-peer-script-pre-up-enabled --agent-peer-script-pre-up-line --agent-peer-script-post-up-enabled --agent-peer-script-post-up-line --agent-peer-script-pre-down-enabled --agent-peer-script-pre-down-line --agent-peer-script-post-down-enabled --agent-peer-script-post-down-line --default-peer-kind --default-peer-icon-enabled --default-peer-icon-src --default-peer-dns-enabled --default-peer-dns-addresses --default-peer-mtu-enabled --default-peer-mtu-value --default-peer-script-pre-up-enabled --default-peer-script-pre-up-line --default-peer-script-post-up-enabled --default-peer-script-post-up-line --default-peer-script-pre-down-enabled --default-peer-script-pre-down-line --default-peer-script-post-down-enabled --default-peer-script-post-down-line --default-connection-persistent-keepalive-enabled --default-connection-persistent-keepalive-period --no-prompt --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --network-name)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --network-subnet)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-web-address)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-web-http-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --agent-web-http-port)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-web-https-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --agent-web-https-port)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-web-https-tls-cert)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-web-https-tls-key)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-web-password-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --agent-web-password)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-vpn-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --agent-vpn-port)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-firewall-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --agent-firewall-utility)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-firewall-gateway)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-peer-name)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-peer-vpn-internal-address)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-peer-vpn-endpoint)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-peer-kind)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-peer-icon-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --agent-peer-icon-src)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-peer-dns-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --agent-peer-dns-addresses)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-peer-mtu-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --agent-peer-mtu-value)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-peer-script-pre-up-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --agent-peer-script-pre-up-line)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-peer-script-post-up-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --agent-peer-script-post-up-line)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-peer-script-pre-down-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --agent-peer-script-pre-down-line)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --agent-peer-script-post-down-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --agent-peer-script-post-down-line)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --default-peer-kind)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --default-peer-icon-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --default-peer-icon-src)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --default-peer-dns-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --default-peer-dns-addresses)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --default-peer-mtu-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --default-peer-mtu-value)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --default-peer-script-pre-up-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --default-peer-script-pre-up-line)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --default-peer-script-post-up-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --default-peer-script-post-up-line)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --default-peer-script-pre-down-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --default-peer-script-pre-down-line)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --default-peer-script-post-down-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --default-peer-script-post-down-line)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --default-connection-persistent-keepalive-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --default-connection-persistent-keepalive-period)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --no-prompt)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__agent__run)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config)
            opts="-h --help enable disable set reset get list remove add help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__add)
            opts="-h --help peer connection help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__add__connection)
            opts="-h --no-prompt --first-peer --second-peer --persistent-keepalive-enabled --persistent-keepalive-period --allowed-ips-first-to-second --allowed-ips-second-to-first --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --no-prompt)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --first-peer)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --second-peer)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --persistent-keepalive-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --persistent-keepalive-period)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --allowed-ips-first-to-second)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --allowed-ips-second-to-first)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__add__help)
            opts="peer connection help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__add__help__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__add__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__add__help__peer)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__add__peer)
            opts="-h --no-prompt --name --address --endpoint-enabled --endpoint-address --kind --icon-enabled --icon-src --dns-enabled --dns-addresses --mtu-enabled --mtu-value --script-pre-up-enabled --script-pre-up-line --script-post-up-enabled --script-post-up-line --script-pre-down-enabled --script-pre-down-line --script-post-down-enabled --script-post-down-line --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --no-prompt)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --name)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --address)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --endpoint-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --endpoint-address)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --kind)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --icon-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --icon-src)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --dns-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --dns-addresses)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mtu-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --mtu-value)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --script-pre-up-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --script-pre-up-line)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --script-post-up-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --script-post-up-line)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --script-pre-down-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --script-pre-down-line)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --script-post-down-enabled)
                    COMPREPLY=($(compgen -W "true false" -- "${cur}"))
                    return 0
                    ;;
                --script-post-down-line)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable)
            opts="-h --help agent network help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent)
            opts="-h --help web vpn firewall help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__firewall)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__help)
            opts="web vpn firewall help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__help__firewall)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__help__vpn)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__help__web)
            opts="http https password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__help__web__http)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__help__web__https)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__help__web__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__vpn)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__web)
            opts="-h --help http https password help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__web__help)
            opts="http https password help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__web__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__web__help__http)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__web__help__https)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__web__help__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__web__http)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__web__https)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__agent__web__password)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help)
            opts="agent network help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__agent)
            opts="web vpn firewall"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__agent__firewall)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__agent__vpn)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__agent__web)
            opts="http https password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__agent__web__http)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__agent__web__https)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__agent__web__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network)
            opts="peer connection defaults"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__defaults__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__defaults__peer)
            opts="icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__defaults__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__defaults__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__defaults__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__peer)
            opts="endpoint icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__peer__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__help__network__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network)
            opts="-h --help peer connection defaults help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__connection)
            opts="-h --help <ID>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults)
            opts="-h --help peer connection help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__connection)
            opts="-h --help persistent-keepalive help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__connection__help)
            opts="persistent-keepalive help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__connection__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__connection__help__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__connection__persistent__keepalive)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__help)
            opts="peer connection help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__help__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__help__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__help__peer)
            opts="icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__help__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__help__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__help__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__peer)
            opts="-h --help icon dns mtu help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__peer__dns)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__peer__help)
            opts="icon dns mtu help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__peer__help__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__peer__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__peer__help__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__peer__help__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__peer__icon)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__defaults__peer__mtu)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help)
            opts="peer connection defaults help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__defaults__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__defaults__peer)
            opts="icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__defaults__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__defaults__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__defaults__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__peer)
            opts="endpoint icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__peer__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__help__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__peer)
            opts="-h --help <ID> endpoint icon dns mtu help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__peer__dns)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__peer__endpoint)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__peer__help)
            opts="endpoint icon dns mtu help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__peer__help__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__peer__help__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__peer__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__peer__help__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__peer__help__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__peer__icon)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__disable__network__peer__mtu)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable)
            opts="-h --help agent network help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent)
            opts="-h --help web vpn firewall help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__firewall)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__help)
            opts="web vpn firewall help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__help__firewall)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__help__vpn)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__help__web)
            opts="http https password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__help__web__http)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__help__web__https)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__help__web__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__vpn)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__web)
            opts="-h --help http https password help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__web__help)
            opts="http https password help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__web__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__web__help__http)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__web__help__https)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__web__help__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__web__http)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__web__https)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__agent__web__password)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help)
            opts="agent network help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__agent)
            opts="web vpn firewall"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__agent__firewall)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__agent__vpn)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__agent__web)
            opts="http https password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__agent__web__http)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__agent__web__https)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__agent__web__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network)
            opts="peer connection defaults"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__defaults__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__defaults__peer)
            opts="icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__defaults__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__defaults__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__defaults__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__peer)
            opts="endpoint icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__peer__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__help__network__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network)
            opts="-h --help peer connection defaults help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__connection)
            opts="-h --help <ID>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults)
            opts="-h --help peer connection help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__connection)
            opts="-h --help persistent-keepalive help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__connection__help)
            opts="persistent-keepalive help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__connection__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__connection__help__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__connection__persistent__keepalive)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__help)
            opts="peer connection help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__help__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__help__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__help__peer)
            opts="icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__help__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__help__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__help__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__peer)
            opts="-h --help icon dns mtu help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__peer__dns)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__peer__help)
            opts="icon dns mtu help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__peer__help__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__peer__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__peer__help__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__peer__help__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__peer__icon)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__defaults__peer__mtu)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help)
            opts="peer connection defaults help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__defaults__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__defaults__peer)
            opts="icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__defaults__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__defaults__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__defaults__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__peer)
            opts="endpoint icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__peer__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__help__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__peer)
            opts="-h --help <ID> endpoint icon dns mtu help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__peer__dns)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__peer__endpoint)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__peer__help)
            opts="endpoint icon dns mtu help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__peer__help__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__peer__help__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__peer__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__peer__help__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__peer__help__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__peer__icon)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__enable__network__peer__mtu)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get)
            opts="-h --help agent network help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent)
            opts="-h --help web vpn firewall help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__firewall)
            opts="-h --help enabled utility gateway help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__firewall__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__firewall__gateway)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__firewall__help)
            opts="enabled utility gateway help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__firewall__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__firewall__help__gateway)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__firewall__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__firewall__help__utility)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__firewall__utility)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help)
            opts="web vpn firewall help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__firewall)
            opts="enabled utility gateway"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__firewall__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__firewall__gateway)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__firewall__utility)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__vpn)
            opts="enabled port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__vpn__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__vpn__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web)
            opts="address http https password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web__http)
            opts="enabled port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web__http__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web__http__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web__https)
            opts="enabled port tls-cert tls-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web__https__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web__https__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web__https__tls__cert)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web__https__tls__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web__password)
            opts="enabled hash"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web__password__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__help__web__password__hash)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__vpn)
            opts="-h --help enabled port help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__vpn__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__vpn__help)
            opts="enabled port help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__vpn__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__vpn__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__vpn__help__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__vpn__port)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web)
            opts="-h --help address http https password help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__address)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help)
            opts="address http https password help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__http)
            opts="enabled port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__http__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__http__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__https)
            opts="enabled port tls-cert tls-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__https__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__https__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__https__tls__cert)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__https__tls__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__password)
            opts="enabled hash"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__password__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__help__password__hash)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__http)
            opts="-h --help enabled port help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__http__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__http__help)
            opts="enabled port help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__http__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__http__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__http__help__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__http__port)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__https)
            opts="-h --help enabled port tls-cert tls-key help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__https__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__https__help)
            opts="enabled port tls-cert tls-key help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__https__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__https__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__https__help__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__https__help__tls__cert)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__https__help__tls__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__https__port)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__https__tls__cert)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__https__tls__key)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__password)
            opts="-h --help enabled hash help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__password__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__password__hash)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__password__help)
            opts="enabled hash help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__password__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__password__help__hash)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__agent__web__password__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help)
            opts="agent network help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent)
            opts="web vpn firewall"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__firewall)
            opts="enabled utility gateway"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__firewall__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__firewall__gateway)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__firewall__utility)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__vpn)
            opts="enabled port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__vpn__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__vpn__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web)
            opts="address http https password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web__http)
            opts="enabled port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web__http__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web__http__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web__https)
            opts="enabled port tls-cert tls-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web__https__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web__https__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web__https__tls__cert)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web__https__tls__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web__password)
            opts="enabled hash"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web__password__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__agent__web__password__hash)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network)
            opts="name subnet this-peer peers connections defaults reservations updated-at"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__connections)
            opts="enabled pre-shared-key persistent-keepalive allowed-ips-a-to-b allowed-ips-b-to-a"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__connections__allowed__ips__a__to__b)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__connections__allowed__ips__b__to__a)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__connections__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__connections__persistent__keepalive)
            opts="enabled period"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__connections__persistent__keepalive__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__connections__persistent__keepalive__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__connections__pre__shared__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__connection__persistent__keepalive)
            opts="enabled period"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__connection__persistent__keepalive__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__connection__persistent__keepalive__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__peer)
            opts="kind icon dns mtu scripts"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__peer__dns)
            opts="enabled addresses"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__peer__dns__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__peer__dns__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__peer__icon)
            opts="enabled src"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__peer__icon__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__peer__icon__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__peer__mtu)
            opts="enabled value"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__peer__mtu__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__peer__mtu__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__defaults__peer__scripts)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers)
            opts="name address endpoint kind icon dns mtu scripts private-key created-at updated-at"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__created__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__dns)
            opts="enabled addresses"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__dns__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__dns__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__endpoint)
            opts="enabled address"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__endpoint__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__endpoint__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__icon)
            opts="enabled src"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__icon__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__icon__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__mtu)
            opts="enabled value"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__mtu__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__mtu__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__private__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__scripts)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__peers__updated__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__reservations)
            opts="peer-id valid-until"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__reservations__peer__id)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__reservations__valid__until)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__subnet)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__this__peer)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__help__network__updated__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network)
            opts="-h --help name subnet this-peer peers connections defaults reservations updated-at help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections)
            opts="-h --help [ID] enabled pre-shared-key persistent-keepalive allowed-ips-a-to-b allowed-ips-b-to-a help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__allowed__ips__a__to__b)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__allowed__ips__b__to__a)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__help)
            opts="enabled pre-shared-key persistent-keepalive allowed-ips-a-to-b allowed-ips-b-to-a help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__help__allowed__ips__a__to__b)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__help__allowed__ips__b__to__a)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__help__persistent__keepalive)
            opts="enabled period"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__help__persistent__keepalive__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__help__persistent__keepalive__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__help__pre__shared__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__persistent__keepalive)
            opts="-h --help enabled period help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__persistent__keepalive__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__persistent__keepalive__help)
            opts="enabled period help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__persistent__keepalive__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__persistent__keepalive__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__persistent__keepalive__help__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__persistent__keepalive__period)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__connections__pre__shared__key)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults)
            opts="-h --help peer connection help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection)
            opts="-h --help persistent-keepalive help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection__help)
            opts="persistent-keepalive help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection__help__persistent__keepalive)
            opts="enabled period"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection__help__persistent__keepalive__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection__help__persistent__keepalive__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection__persistent__keepalive)
            opts="-h --help enabled period help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__help)
            opts="enabled period help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__help__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__connection__persistent__keepalive__period)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help)
            opts="peer connection help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__connection__persistent__keepalive)
            opts="enabled period"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__connection__persistent__keepalive__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__connection__persistent__keepalive__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__peer)
            opts="kind icon dns mtu scripts"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__peer__dns)
            opts="enabled addresses"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__peer__dns__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__peer__dns__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__peer__icon)
            opts="enabled src"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__peer__icon__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__peer__icon__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__peer__mtu)
            opts="enabled value"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__peer__mtu__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__peer__mtu__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__help__peer__scripts)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer)
            opts="-h --help kind icon dns mtu scripts help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__dns)
            opts="-h --help enabled addresses help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__dns__addresses)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__dns__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__dns__help)
            opts="enabled addresses help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__dns__help__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__dns__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__dns__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help)
            opts="kind icon dns mtu scripts help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help__dns)
            opts="enabled addresses"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help__dns__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help__dns__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help__icon)
            opts="enabled src"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help__icon__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help__icon__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help__mtu)
            opts="enabled value"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help__mtu__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help__mtu__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__help__scripts)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__icon)
            opts="-h --help enabled src help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__icon__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__icon__help)
            opts="enabled src help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__icon__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__icon__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__icon__help__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__icon__src)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__kind)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__mtu)
            opts="-h --help enabled value help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__mtu__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__mtu__help)
            opts="enabled value help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__mtu__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__mtu__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__mtu__help__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__mtu__value)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__defaults__peer__scripts)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help)
            opts="name subnet this-peer peers connections defaults reservations updated-at help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__connections)
            opts="enabled pre-shared-key persistent-keepalive allowed-ips-a-to-b allowed-ips-b-to-a"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__connections__allowed__ips__a__to__b)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__connections__allowed__ips__b__to__a)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__connections__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__connections__persistent__keepalive)
            opts="enabled period"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__connections__persistent__keepalive__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__connections__persistent__keepalive__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__connections__pre__shared__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__connection__persistent__keepalive)
            opts="enabled period"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__connection__persistent__keepalive__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__connection__persistent__keepalive__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__peer)
            opts="kind icon dns mtu scripts"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__peer__dns)
            opts="enabled addresses"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__peer__dns__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__peer__dns__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__peer__icon)
            opts="enabled src"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__peer__icon__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__peer__icon__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__peer__mtu)
            opts="enabled value"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__peer__mtu__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__peer__mtu__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__defaults__peer__scripts)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers)
            opts="name address endpoint kind icon dns mtu scripts private-key created-at updated-at"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__created__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__dns)
            opts="enabled addresses"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__dns__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__dns__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__endpoint)
            opts="enabled address"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__endpoint__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__endpoint__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__icon)
            opts="enabled src"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__icon__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__icon__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__mtu)
            opts="enabled value"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__mtu__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__mtu__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__private__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__scripts)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__peers__updated__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__reservations)
            opts="peer-id valid-until"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__reservations__peer__id)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__reservations__valid__until)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__subnet)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__this__peer)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__help__updated__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__name)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers)
            opts="-h --help [ID] name address endpoint kind icon dns mtu scripts private-key created-at updated-at help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__address)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__created__at)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__dns)
            opts="-h --help enabled addresses help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__dns__addresses)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__dns__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__dns__help)
            opts="enabled addresses help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__dns__help__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__dns__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__dns__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__endpoint)
            opts="-h --help enabled address help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__endpoint__address)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__endpoint__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__endpoint__help)
            opts="enabled address help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__endpoint__help__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__endpoint__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__endpoint__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help)
            opts="name address endpoint kind icon dns mtu scripts private-key created-at updated-at help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__created__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__dns)
            opts="enabled addresses"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__dns__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__dns__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__endpoint)
            opts="enabled address"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__endpoint__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__endpoint__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__icon)
            opts="enabled src"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__icon__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__icon__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__mtu)
            opts="enabled value"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__mtu__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__mtu__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__private__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__scripts)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__help__updated__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__icon)
            opts="-h --help enabled src help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__icon__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__icon__help)
            opts="enabled src help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__icon__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__icon__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__icon__help__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__icon__src)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__kind)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__mtu)
            opts="-h --help enabled value help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__mtu__enabled)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__mtu__help)
            opts="enabled value help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__mtu__help__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__mtu__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__mtu__help__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__mtu__value)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__name)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__private__key)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__scripts)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__peers__updated__at)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__reservations)
            opts="-h --help [IP] peer-id valid-until help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__reservations__help)
            opts="peer-id valid-until help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__reservations__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__reservations__help__peer__id)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__reservations__help__valid__until)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__reservations__peer__id)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__reservations__valid__until)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__subnet)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__this__peer)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__get__network__updated__at)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help)
            opts="enable disable set reset get list remove add help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__add)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__add__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__add__peer)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable)
            opts="agent network"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__agent)
            opts="web vpn firewall"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__agent__firewall)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__agent__vpn)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__agent__web)
            opts="http https password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__agent__web__http)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__agent__web__https)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__agent__web__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network)
            opts="peer connection defaults"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__defaults__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__defaults__peer)
            opts="icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__defaults__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__defaults__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__defaults__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__peer)
            opts="endpoint icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__peer__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__disable__network__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable)
            opts="agent network"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__agent)
            opts="web vpn firewall"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__agent__firewall)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__agent__vpn)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__agent__web)
            opts="http https password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__agent__web__http)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__agent__web__https)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__agent__web__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network)
            opts="peer connection defaults"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__defaults__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__defaults__peer)
            opts="icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__defaults__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__defaults__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__defaults__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__peer)
            opts="endpoint icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__peer__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__enable__network__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get)
            opts="agent network"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent)
            opts="web vpn firewall"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__firewall)
            opts="enabled utility gateway"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__firewall__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__firewall__gateway)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__firewall__utility)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__vpn)
            opts="enabled port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__vpn__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__vpn__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web)
            opts="address http https password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web__http)
            opts="enabled port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web__http__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web__http__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web__https)
            opts="enabled port tls-cert tls-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web__https__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web__https__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web__https__tls__cert)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web__https__tls__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web__password)
            opts="enabled hash"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web__password__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__agent__web__password__hash)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network)
            opts="name subnet this-peer peers connections defaults reservations updated-at"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__connections)
            opts="enabled pre-shared-key persistent-keepalive allowed-ips-a-to-b allowed-ips-b-to-a"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__connections__allowed__ips__a__to__b)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__connections__allowed__ips__b__to__a)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__connections__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__connections__persistent__keepalive)
            opts="enabled period"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__connections__persistent__keepalive__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__connections__persistent__keepalive__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__connections__pre__shared__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__connection__persistent__keepalive)
            opts="enabled period"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__connection__persistent__keepalive__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__connection__persistent__keepalive__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__peer)
            opts="kind icon dns mtu scripts"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__peer__dns)
            opts="enabled addresses"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__peer__dns__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__peer__dns__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__peer__icon)
            opts="enabled src"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__peer__icon__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__peer__icon__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__peer__mtu)
            opts="enabled value"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__peer__mtu__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__peer__mtu__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__defaults__peer__scripts)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers)
            opts="name address endpoint kind icon dns mtu scripts private-key created-at updated-at"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__created__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__dns)
            opts="enabled addresses"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__dns__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__dns__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__endpoint)
            opts="enabled address"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__endpoint__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__endpoint__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__icon)
            opts="enabled src"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__icon__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__icon__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__mtu)
            opts="enabled value"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__mtu__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__mtu__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__private__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__scripts)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__peers__updated__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__reservations)
            opts="peer-id valid-until"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__reservations__peer__id)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__reservations__valid__until)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__subnet)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__this__peer)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__get__network__updated__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__list)
            opts="peers connections reservations"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__list__connections)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__list__peers)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__list__reservations)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__remove)
            opts="peer connection reservation"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__remove__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__remove__peer)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__remove__reservation)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__reset)
            opts="agent network"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__reset__agent)
            opts="web"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__reset__agent__web)
            opts="password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__reset__agent__web__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__reset__network)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__reset__network__connection)
            opts="pre-shared-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__reset__network__connection__pre__shared__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__reset__network__peer)
            opts="private-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__reset__network__peer__private__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set)
            opts="agent network"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent)
            opts="web vpn firewall"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__firewall)
            opts="utility gateway"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__firewall__gateway)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__firewall__utility)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__vpn)
            opts="port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__vpn__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__web)
            opts="address http https"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__web__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__web__http)
            opts="port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__web__http__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__web__https)
            opts="port tls-cert tls-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__web__https__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__web__https__tls__cert)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__agent__web__https__tls__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network)
            opts="name subnet peer connection defaults"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__connection)
            opts="allowed-ips-a-to-b allowed-ips-b-to-a persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__connection__allowed__ips__a__to__b)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__connection__allowed__ips__b__to__a)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__defaults__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__defaults__peer)
            opts="kind icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__defaults__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__defaults__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__defaults__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__defaults__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__peer)
            opts="name address endpoint kind icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__peer__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__peer__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__peer__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__help__set__network__subnet)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__list)
            opts="-h --help peers connections reservations help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__list__connections)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__list__help)
            opts="peers connections reservations help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__list__help__connections)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__list__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__list__help__peers)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__list__help__reservations)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__list__peers)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__list__reservations)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__remove)
            opts="-h --help peer connection reservation help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__remove__connection)
            opts="-h --help <ID>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__remove__help)
            opts="peer connection reservation help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__remove__help__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__remove__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__remove__help__peer)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__remove__help__reservation)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__remove__peer)
            opts="-h --help <ID>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__remove__reservation)
            opts="-h --help <ADDRESS>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset)
            opts="-h --help agent network help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__agent)
            opts="-h --help web help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__agent__help)
            opts="web help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__agent__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__agent__help__web)
            opts="password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__agent__help__web__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__agent__web)
            opts="-h --help password help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__agent__web__help)
            opts="password help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__agent__web__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__agent__web__help__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__agent__web__password)
            opts="-h --password --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --password)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__help)
            opts="agent network help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__help__agent)
            opts="web"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__help__agent__web)
            opts="password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__help__agent__web__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__help__network)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__help__network__connection)
            opts="pre-shared-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__help__network__connection__pre__shared__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__help__network__peer)
            opts="private-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__help__network__peer__private__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network)
            opts="-h --help peer connection help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__connection)
            opts="-h --help <ID> pre-shared-key help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__connection__help)
            opts="pre-shared-key help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__connection__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__connection__help__pre__shared__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__connection__pre__shared__key)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__help)
            opts="peer connection help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__help__connection)
            opts="pre-shared-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__help__connection__pre__shared__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__help__peer)
            opts="private-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__help__peer__private__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__peer)
            opts="-h --help <ID> private-key help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__peer__help)
            opts="private-key help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__peer__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__peer__help__private__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__reset__network__peer__private__key)
            opts="-h --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set)
            opts="-h --help agent network help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent)
            opts="-h --help web vpn firewall help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__firewall)
            opts="-h --help utility gateway help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__firewall__gateway)
            opts="-h --help <VALUE>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__firewall__help)
            opts="utility gateway help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__firewall__help__gateway)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__firewall__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__firewall__help__utility)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__firewall__utility)
            opts="-h --help <VALUE>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help)
            opts="web vpn firewall help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__firewall)
            opts="utility gateway"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__firewall__gateway)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__firewall__utility)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__vpn)
            opts="port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__vpn__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__web)
            opts="address http https"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__web__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__web__http)
            opts="port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__web__http__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__web__https)
            opts="port tls-cert tls-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__web__https__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__web__https__tls__cert)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__help__web__https__tls__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__vpn)
            opts="-h --help port help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__vpn__help)
            opts="port help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__vpn__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__vpn__help__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__vpn__port)
            opts="-h --help <VALUE>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web)
            opts="-h --help address http https help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__address)
            opts="-h --help <VALUE>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__help)
            opts="address http https help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__help__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__help__http)
            opts="port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__help__http__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__help__https)
            opts="port tls-cert tls-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__help__https__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__help__https__tls__cert)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__help__https__tls__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__http)
            opts="-h --help port help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__http__help)
            opts="port help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__http__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__http__help__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__http__port)
            opts="-h --help <VALUE>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__https)
            opts="-h --help port tls-cert tls-key help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__https__help)
            opts="port tls-cert tls-key help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__https__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__https__help__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__https__help__tls__cert)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__https__help__tls__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__https__port)
            opts="-h --help <VALUE>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__https__tls__cert)
            opts="-h --help <VALUE>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__agent__web__https__tls__key)
            opts="-h --help <VALUE>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help)
            opts="agent network help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent)
            opts="web vpn firewall"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__firewall)
            opts="utility gateway"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__firewall__gateway)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__firewall__utility)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__vpn)
            opts="port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__vpn__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__web)
            opts="address http https"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__web__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__web__http)
            opts="port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__web__http__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__web__https)
            opts="port tls-cert tls-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__web__https__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__web__https__tls__cert)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__agent__web__https__tls__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network)
            opts="name subnet peer connection defaults"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__connection)
            opts="allowed-ips-a-to-b allowed-ips-b-to-a persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__connection__allowed__ips__a__to__b)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__connection__allowed__ips__b__to__a)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__defaults__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__defaults__peer)
            opts="kind icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__defaults__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__defaults__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__defaults__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__defaults__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__peer)
            opts="name address endpoint kind icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__peer__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__peer__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__peer__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__help__network__subnet)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network)
            opts="-h --help name subnet peer connection defaults help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__connection)
            opts="-h --help <ID> allowed-ips-a-to-b allowed-ips-b-to-a persistent-keepalive help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__connection__allowed__ips__a__to__b)
            opts="-h --help <IPS>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__connection__allowed__ips__b__to__a)
            opts="-h --help <IPS>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__connection__help)
            opts="allowed-ips-a-to-b allowed-ips-b-to-a persistent-keepalive help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__connection__help__allowed__ips__a__to__b)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__connection__help__allowed__ips__b__to__a)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__connection__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__connection__help__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__connection__persistent__keepalive)
            opts="-h --help <PERIOD>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults)
            opts="-h --help peer connection help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__connection)
            opts="-h --help persistent-keepalive help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__connection__help)
            opts="persistent-keepalive help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__connection__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__connection__help__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__connection__persistent__keepalive)
            opts="-h --help <PERIOD>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__help)
            opts="peer connection help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__help__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__help__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__help__peer)
            opts="kind icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__help__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__help__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__help__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__help__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__peer)
            opts="-h --help kind icon dns mtu help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__peer__dns)
            opts="-h --help <ADDRESSES>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__peer__help)
            opts="kind icon dns mtu help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__peer__help__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__peer__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__peer__help__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__peer__help__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__peer__help__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__peer__icon)
            opts="-h --help <SRC>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__peer__kind)
            opts="-h --help <KIND>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__defaults__peer__mtu)
            opts="-h --help <VALUE>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help)
            opts="name subnet peer connection defaults help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__connection)
            opts="allowed-ips-a-to-b allowed-ips-b-to-a persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__connection__allowed__ips__a__to__b)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__connection__allowed__ips__b__to__a)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__defaults__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__defaults__peer)
            opts="kind icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__defaults__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__defaults__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__defaults__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__defaults__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__peer)
            opts="name address endpoint kind icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__peer__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__peer__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__peer__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__help__subnet)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__name)
            opts="-h --help <NAME>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer)
            opts="-h --help <ID> name address endpoint kind icon dns mtu help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__address)
            opts="-h --help <ADDRESS>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__dns)
            opts="-h --help <ADDRESSES>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__endpoint)
            opts="-h --help <ENDPOINT>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__help)
            opts="name address endpoint kind icon dns mtu help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__help__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__help__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__help__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__help__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__help__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__help__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__help__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__icon)
            opts="-h --help <SRC>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__kind)
            opts="-h --help <KIND>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__mtu)
            opts="-h --help <VALUE>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__peer__name)
            opts="-h --help <NAME>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__config__set__network__subnet)
            opts="-h --help <SUBNET>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help)
            opts="agent config help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__agent)
            opts="init run"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__agent__init)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__agent__run)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config)
            opts="enable disable set reset get list remove add"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__add)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__add__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__add__peer)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable)
            opts="agent network"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__agent)
            opts="web vpn firewall"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__agent__firewall)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__agent__vpn)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__agent__web)
            opts="http https password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__agent__web__http)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__agent__web__https)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__agent__web__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network)
            opts="peer connection defaults"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__defaults__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__defaults__peer)
            opts="icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__defaults__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__defaults__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__defaults__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__peer)
            opts="endpoint icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__peer__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__disable__network__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable)
            opts="agent network"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__agent)
            opts="web vpn firewall"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__agent__firewall)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__agent__vpn)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__agent__web)
            opts="http https password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__agent__web__http)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__agent__web__https)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__agent__web__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network)
            opts="peer connection defaults"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__defaults__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__defaults__peer)
            opts="icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__defaults__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__defaults__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__defaults__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__peer)
            opts="endpoint icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__peer__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__enable__network__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get)
            opts="agent network"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent)
            opts="web vpn firewall"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__firewall)
            opts="enabled utility gateway"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__firewall__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__firewall__gateway)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__firewall__utility)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__vpn)
            opts="enabled port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__vpn__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__vpn__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web)
            opts="address http https password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web__http)
            opts="enabled port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web__http__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web__http__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web__https)
            opts="enabled port tls-cert tls-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web__https__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web__https__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web__https__tls__cert)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web__https__tls__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web__password)
            opts="enabled hash"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web__password__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__agent__web__password__hash)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network)
            opts="name subnet this-peer peers connections defaults reservations updated-at"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__connections)
            opts="enabled pre-shared-key persistent-keepalive allowed-ips-a-to-b allowed-ips-b-to-a"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__connections__allowed__ips__a__to__b)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__connections__allowed__ips__b__to__a)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__connections__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__connections__persistent__keepalive)
            opts="enabled period"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__connections__persistent__keepalive__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__connections__persistent__keepalive__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__connections__pre__shared__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__connection__persistent__keepalive)
            opts="enabled period"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__connection__persistent__keepalive__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__connection__persistent__keepalive__period)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__peer)
            opts="kind icon dns mtu scripts"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__peer__dns)
            opts="enabled addresses"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__peer__dns__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__peer__dns__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__peer__icon)
            opts="enabled src"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__peer__icon__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__peer__icon__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__peer__mtu)
            opts="enabled value"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__peer__mtu__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__peer__mtu__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 9 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__defaults__peer__scripts)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers)
            opts="name address endpoint kind icon dns mtu scripts private-key created-at updated-at"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__created__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__dns)
            opts="enabled addresses"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__dns__addresses)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__dns__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__endpoint)
            opts="enabled address"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__endpoint__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__endpoint__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__icon)
            opts="enabled src"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__icon__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__icon__src)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__mtu)
            opts="enabled value"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__mtu__enabled)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__mtu__value)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__private__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__scripts)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__peers__updated__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__reservations)
            opts="peer-id valid-until"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__reservations__peer__id)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__reservations__valid__until)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__subnet)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__this__peer)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__get__network__updated__at)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__list)
            opts="peers connections reservations"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__list__connections)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__list__peers)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__list__reservations)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__remove)
            opts="peer connection reservation"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__remove__connection)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__remove__peer)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__remove__reservation)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__reset)
            opts="agent network"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__reset__agent)
            opts="web"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__reset__agent__web)
            opts="password"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__reset__agent__web__password)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__reset__network)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__reset__network__connection)
            opts="pre-shared-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__reset__network__connection__pre__shared__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__reset__network__peer)
            opts="private-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__reset__network__peer__private__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set)
            opts="agent network"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent)
            opts="web vpn firewall"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__firewall)
            opts="utility gateway"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__firewall__gateway)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__firewall__utility)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__vpn)
            opts="port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__vpn__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__web)
            opts="address http https"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__web__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__web__http)
            opts="port"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__web__http__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__web__https)
            opts="port tls-cert tls-key"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__web__https__port)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__web__https__tls__cert)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__agent__web__https__tls__key)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network)
            opts="name subnet peer connection defaults"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 5 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__connection)
            opts="allowed-ips-a-to-b allowed-ips-b-to-a persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__connection__allowed__ips__a__to__b)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__connection__allowed__ips__b__to__a)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__defaults)
            opts="peer connection"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__defaults__connection)
            opts="persistent-keepalive"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__defaults__connection__persistent__keepalive)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__defaults__peer)
            opts="kind icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__defaults__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__defaults__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__defaults__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__defaults__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 8 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__peer)
            opts="name address endpoint kind icon dns mtu"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__peer__address)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__peer__dns)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__peer__endpoint)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__peer__icon)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__peer__kind)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__peer__mtu)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__peer__name)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 7 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__config__set__network__subnet)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 6 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        wg__quickrs__help__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
    esac
}

if [[ "${BASH_VERSINFO[0]}" -eq 4 && "${BASH_VERSINFO[1]}" -ge 4 || "${BASH_VERSINFO[0]}" -gt 4 ]]; then
    complete -F _wg-quickrs -o nosort -o bashdefault -o default wg-quickrs
else
    complete -F _wg-quickrs -o bashdefault -o default wg-quickrs
fi
